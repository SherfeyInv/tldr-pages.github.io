# ubuntu-bug

> 這是 `apport-bug` 命令的一個別名。
> 更多資訊：<https://manned.org/ubuntu-bug>.

- 原命令的文件在：

`tldr apport-bug`
