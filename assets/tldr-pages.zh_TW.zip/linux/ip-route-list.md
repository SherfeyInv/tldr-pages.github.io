# ip route list

> 這是  `ip route show`.命令的一個別名。

- 原命令的文件在：

`tldr ip route show`
