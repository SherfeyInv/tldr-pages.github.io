# batcat

> 這是 `bat` 命令的一個別名。

- 原命令的文件在：

`tldr bat`
