# gsha224sum

> 這是 `-p linux sha224sum` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux sha224sum`
