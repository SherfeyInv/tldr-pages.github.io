# gwhois

> 這是 `-p linux whois` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux whois`
