# genv

> 這是 `-p linux env` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux env`
