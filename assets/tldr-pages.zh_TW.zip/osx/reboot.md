# reboot

> 重啟系統。
> 更多資訊：<https://keith.github.io/xcode-man-pages/reboot.8.html>.

- 立即重新啟動：

`sudo reboot`

- 立即強制重新啟動（應避免使用此選項）：

`sudo reboot -q`
