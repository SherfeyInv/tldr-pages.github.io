# ver

> 顯示當前 Windows 或 MS-DOS 的版本號。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- 顯示當前系統版本號：

`ver`
