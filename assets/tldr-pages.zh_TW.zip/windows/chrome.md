# chrome

> 這是 `chromium` 命令的一個別名。
> 更多資訊：<https://chrome.google.com>.

- 原命令的文件在：

`tldr chromium`
