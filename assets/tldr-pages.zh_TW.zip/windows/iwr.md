# iwr

> 這是 `invoke-webrequest` 命令的一個別名。

- 原命令的文件在：

`tldr invoke-webrequest`
