# cuninst

> 這是 `choco uninstall` 命令的一個別名。

- 原命令的文件在：

`tldr choco uninstall`
