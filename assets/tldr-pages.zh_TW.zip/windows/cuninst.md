# cuninst

> 這是 `choco uninstall` 命令的一個別名。
> 更多資訊：<https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- 原命令的文件在：

`tldr choco uninstall`
