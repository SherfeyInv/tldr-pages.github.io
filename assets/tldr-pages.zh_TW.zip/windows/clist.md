# clist

> 這是 `choco list` 命令的一個別名。
> 更多資訊：<https://docs.chocolatey.org/en-us/choco/commands/list>.

- 原命令的文件在：

`tldr choco list`
