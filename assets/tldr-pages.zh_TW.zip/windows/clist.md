# clist

> 這是 `choco list` 命令的一個別名。

- 原命令的文件在：

`tldr choco list`
