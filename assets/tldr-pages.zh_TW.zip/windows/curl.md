# curl

> 這是 `curl -p common` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- 原命令的文件在：

`tldr curl -p common`
