# gh cs

> 這是 `gh codespace`.命令的一個別名。
> 更多資訊：<https://cli.github.com/manual/gh_codespace>.

- 原命令的文件在：

`tldr gh codespace`
