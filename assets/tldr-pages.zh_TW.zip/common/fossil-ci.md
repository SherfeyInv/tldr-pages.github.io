# fossil ci

> 這是 `fossil commit`.命令的一個別名。
> 更多資訊：<https://fossil-scm.org/home/help/commit>.

- 原命令的文件在：

`tldr fossil commit`
