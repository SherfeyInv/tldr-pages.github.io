# fossil new

> 這是  `fossil init`.命令的一個別名。
> 更多資訊：<https://fossil-scm.org/home/help/new>.

- 原命令的文件在：

`tldr fossil-init`
