# tlmgr arch

> 這是 `tlmgr platform` 命令的一個別名。

- 原命令的文件在：

`tldr tlmgr platform`
