# llvm-objdump

> 這是 `objdump` 命令的一個別名。

- 原命令的文件在：

`tldr objdump`
