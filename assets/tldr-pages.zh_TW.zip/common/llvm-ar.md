# llvm-ar

> 這是 `ar` 命令的一個別名。

- 原命令的文件在：

`tldr ar`
