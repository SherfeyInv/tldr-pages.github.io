# mscore

> 這是 `musescore` 命令的一個別名。
> 更多資訊：<https://musescore.org/handbook/command-line-options>.

- 原命令的文件在：

`tldr musescore`
