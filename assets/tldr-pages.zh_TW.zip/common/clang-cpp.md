# clang-cpp

> 這是 `clang++` 命令的一個別名。

- 原命令的文件在：

`tldr clang++`
