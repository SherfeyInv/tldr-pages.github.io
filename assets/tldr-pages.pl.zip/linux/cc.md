# cc

> To polecenie jest aliasem dla `gcc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gcc`
