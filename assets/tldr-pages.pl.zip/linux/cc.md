# cc

> To polecenie jest aliasem dla `gcc`.
> Więcej informacji: <https://gcc.gnu.org>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gcc`
