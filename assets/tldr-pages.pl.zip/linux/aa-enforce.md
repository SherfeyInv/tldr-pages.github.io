# aa-enforce

> Ustaw profil AppArmor w tryb wymuszony.
> Zobacz także: `aa-complain`, `aa-disable`, `aa-status`.
> Więcej informacji: <https://gitlab.com/apparmor/apparmor/-/wikis/manpage_aa-enforce.8>.

- Włącz profil:

`sudo aa-enforce --dir {{ścieżka/do/profilu}}`

- Włącz profile:

`sudo aa-enforce {{ścieżka/do/profilu1 ścieżka/do/profilu2 ...}}`
