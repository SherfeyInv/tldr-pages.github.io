# sqfscat

> Połącz pliki z systemu plików squashfs i wypisz je na standardowe wyjście.
> Więcej informacji: <https://manned.org/sqfscat>.

- Wyświetl zawartość jednego lub więcej plików z systemu plików squashfs:

`sqfscat {{system_plików.squashfs}} {{plik1 plik2 ...}}`
