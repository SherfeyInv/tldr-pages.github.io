# ip6tables-restore

> To polecenie jest aliasem `iptables-restore` dla zapory sieciowej IPv6.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables-restore`
