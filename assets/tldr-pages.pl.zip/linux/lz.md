# lz

> Wyświetl wszystkie pliki wewnątrz skompresowanego archiwum `.tar.gz`.
> Więcej informacji: <https://manned.org/lz.1>.

- Wyświetl wszystkie pliki wewnątrz skompresowanego archiwum:

`lz {{ścieżka/do/pliku.tar.gz}}`
