# megadl

> To polecenie jest aliasem `megatools-dl`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr megatools-dl`
