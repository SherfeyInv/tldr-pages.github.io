# ifdown

> Wyłącza interfejsy sieciowe.
> Więcej informacji: <https://manned.org/ifdown>.

- Wyłączenie interfejsu eth0:

`ifdown {{eth0}}`

- Wyłączenie wszystkich interfejsów, które są włączone:

`ifdown -a`
