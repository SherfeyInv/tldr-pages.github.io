# cacafire

> Wyświetl animowany ogień ASCII.
> Więcej informacji: <https://packages.debian.org/sid/caca-utils>.

- Wyświetl ogień ASCII:

`cacafire`
