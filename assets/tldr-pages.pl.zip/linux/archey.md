# archey

> Proste narzędzie do stylowego wyświetlania informacji o systemie.
> Więcej informacji: <https://lclarkmichalek.github.io/archey3/>.

- Wyświetl informacje o systemie:

`archey`
