# qm resize

> To polecenie jest aliasem `qm disk resize`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr qm disk resize`
