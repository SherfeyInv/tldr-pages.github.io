# systemd-confext

> To polecenie jest aliasem `systemd-sysext`.
> Działa na tej samej zasadzie co `systemd-sysext`, ale zamiast działać na `/usr` i `/opt`, confext rozszerzy tylko `/etc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr systemd-sysext`
