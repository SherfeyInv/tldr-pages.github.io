# nmtui-hostname

> To polecenie jest aliasem `nmtui hostname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nmtui`
