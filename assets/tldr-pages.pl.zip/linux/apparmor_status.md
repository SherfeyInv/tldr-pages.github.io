# apparmor_status

> To polecenie jest aliasem `aa-status`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr aa-status`
