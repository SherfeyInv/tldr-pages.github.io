# ip route list

> To polecenie jest aliasem  `ip route show`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ip-route-show`
