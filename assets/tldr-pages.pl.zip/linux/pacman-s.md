# pacman -S

> To polecenie jest aliasem `pacman --sync`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman sync`
