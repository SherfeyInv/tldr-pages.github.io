# tailf

> To polecenie zostało zastąpione przez `tail -f`.
> Więcej informacji: <https://manned.org/tailf.1>.

- Zobacz dokumentację zalecanego zamiennika:

`tldr tail`
