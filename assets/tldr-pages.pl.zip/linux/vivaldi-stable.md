# vivaldi-stable

> To polecenie jest aliasem `chromium`.
> Więcej informacji: <https://vivaldi.com>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chromium`
