# ifup

> Narzędzie używane do włączania interfejsów sieciowych.
> Więcej informacji: <https://manned.org/ifup.8>.

- Włączenie interfejsu eth0:

`ifup {{eth0}}`

- Włączenie wszystkich interfejsów zdefiniowanych jako "auto" w `/etc/network/interfaces`:

`ifup -a`
