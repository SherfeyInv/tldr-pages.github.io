# caffeinate

> Zapobiegaj usypaniu pulpitu.
> Więcej informacji: <https://manned.org/caffeinate>.

- Zapobiegaj usypaniu pulpitu (użyj `Ctrl + C`, aby wyjść):

`caffeinate`
