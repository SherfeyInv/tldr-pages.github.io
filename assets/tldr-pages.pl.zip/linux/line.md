# line

> Wczytaj pojedynczą linię wejścia.
> Więcej informacji: <https://manned.org/line.1>.

- Wczytaj wejście:

`line`
