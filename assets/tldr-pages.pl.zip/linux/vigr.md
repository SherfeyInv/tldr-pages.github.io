# vigr

> Edytuje plik `group`.
> Więcej informacji: <https://manned.org/vigr>.

- Edycja pliku `group`:

`vigr`

- Wyświetlenie wersji:

`vigr --version`
