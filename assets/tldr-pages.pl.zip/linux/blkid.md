# blkid

> Wyświetla wszystkie rozpoznane partycje oraz ich Universally Unique Identifier (UUID).
> Więcej informacji: <https://manned.org/blkid>.

- Wyświetlenie wszystkich partycji:

`sudo blkid`

- Wyświetlenie wszystkich partycji w tabeli, wraz z bieżącymi punktami montowania:

`sudo blkid -o list`
