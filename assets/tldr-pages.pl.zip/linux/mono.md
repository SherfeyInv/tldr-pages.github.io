# mono

> Środowisko uruchomieniowe dla .NET Framework.
> Więcej informacji: <https://www.mono-project.com/docs/>.

- Uruchom program .NET assembly w trybie debugowania:

`mono --debug {{ścieżka/do/program.exe}}`

- Uruchom program .NET:

`mono {{ścieżka/do/program.exe}}`
