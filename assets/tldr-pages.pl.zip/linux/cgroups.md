# cgroups

> To polecenie jest aliasem `cgclassify`.
> Więcej informacji: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cgclassify`
