# amixer

> Mikser dla sterownika ALSA kart dźwiękowych.
> Więcej informacji: <https://manned.org/amixer>.

- Zwiększenie głównego poziomu głośności o 10%:

`amixer -D pulse sset Master {{10%+}}`

- Zmniejszenie głównego poziomu głośności o 10%:

`amixer -D pulse sset Master {{10%-}}`
