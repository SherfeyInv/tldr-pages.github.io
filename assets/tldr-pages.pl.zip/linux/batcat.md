# batcat

> To polecenie jest aliasem dla `bat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bat`
