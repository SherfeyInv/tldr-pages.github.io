# opera-stable

> To polecenie jest aliasem `chromium`.
> Więcej informacji: <https://opera.com>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chromium`
