# ubuntu-bug

> To polecenie jest aliasem `apport-bug`.
> Więcej informacji: <https://manned.org/ubuntu-bug>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr apport-bug`
