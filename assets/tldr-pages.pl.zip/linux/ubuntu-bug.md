# ubuntu-bug

> To polecenie jest aliasem `apport-bug`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr apport-bug`
