# vipw

> Edytuje plik password.
> Więcej informacji: <https://manned.org/vipw>.

- Edycja pliku password:

`vipw`

- Wyświetlenie bieżącej wersji `vipw`:

`vipw --version`
