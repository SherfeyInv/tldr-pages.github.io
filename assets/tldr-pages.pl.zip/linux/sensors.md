# sensors

> Zwraca informacje z sensorów.
> Więcej informacji: <https://manned.org/sensors>.

- Pokazanie bieżących odczytów z wszystkich chipów sensorów:

`sensors`

- Pokazanie temperatur w stopniach Fahrenheita:

`sensors --fahrenheit`
