# alternatives

> To polecenie jest aliasem dla `update-alternatives`.
> Więcej informacji: <https://manned.org/alternatives>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr update-alternatives`
