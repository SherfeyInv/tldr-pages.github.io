# alternatives

> To polecenie jest aliasem dla `update-alternatives`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr update-alternatives`
