# alternatives

> To polecenie jest aliasem `update-alternatives`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr update-alternatives`
