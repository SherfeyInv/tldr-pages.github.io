# dmesg

> Wypisz komunikaty jądra do `stdout`.
> Więcej informacji: <https://www.unix.com/man-page/sunos/1m/dmesg>.

- Wyświetl komunikaty jądra:

`dmesg`

- Pokaż ilość pamięci fizycznej dostępnej w systemie:

`dmesg | grep -i memory`

- Wyświetl komunikaty jądra po 1 stronie naraz:

`dmesg | less`
