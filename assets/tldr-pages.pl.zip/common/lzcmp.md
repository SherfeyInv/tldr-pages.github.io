# lzcmp

> To polecenie jest aliasem `xzcmp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzcmp`
