# gnmic sub

> To polecenie jest aliasem `gnmic subscribe`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gnmic subscribe`
