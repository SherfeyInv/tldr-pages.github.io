# astronomer

> Wykrywaj fałszywe gwiazdki z kont botów w projektach GitHub.
> Więcej informacji: <https://github.com/Ullaakut/astronomer>.

- Skanuj repozytorium:

`astronomer {{tldr-pages/tldr-node-client}}`

- Skanuj maksymalną liczbę gwiazdek w repozytorium:

`astronomer {{tldr-pages/tldr-node-client}} --stars {{50}}`

- Skanuj repozytorium, w tym raporty porównawcze:

`astronomer {{tldr-pages/tldr-node-client}} --verbose`
