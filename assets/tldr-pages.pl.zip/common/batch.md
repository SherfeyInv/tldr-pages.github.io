# batch

> To polecenie jest aliasem `at`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr at`
