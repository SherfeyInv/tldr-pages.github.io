# zstdmt

> To polecenie jest aliasem `zstd --threads 0` (które ustawia liczbę wątków pracy na liczbę fizycznych rdzeni procesora).

- Zobacz dokumentację oryginalnego polecenia:

`tldr zstd`
