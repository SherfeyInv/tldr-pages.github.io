# https

> To polecenie jest aliasem `http`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr http`
