# xzegrep

> To polecenie jest aliasem `xzgrep --extended-regexp`.
> Zobacz także: `egrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzgrep`
