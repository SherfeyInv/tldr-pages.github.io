# brave

> To polecenie jest aliasem `chromium`.
> Więcej informacji: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chromium`
