# crane cp

> To polecenie jest aliasem `crane copy`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr crane copy`
