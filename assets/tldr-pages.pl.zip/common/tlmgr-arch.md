# tlmgr arch

> To polecenie jest aliasem `tlmgr platform`.
> Więcej informacji: <https://www.tug.org/texlive/tlmgr.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr tlmgr platform`
