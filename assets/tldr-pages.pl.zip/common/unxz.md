# unxz

> To polecenie jest aliasem `xz --decompress`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
