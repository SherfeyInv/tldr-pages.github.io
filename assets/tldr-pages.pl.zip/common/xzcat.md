# xzcat

> To polecenie jest aliasem `xz`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
