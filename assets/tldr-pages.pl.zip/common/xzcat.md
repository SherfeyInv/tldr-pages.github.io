# xzcat

> To polecenie jest aliasem `xz --decompress --stdout`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
