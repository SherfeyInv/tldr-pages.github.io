# lzless

> To polecenie jest aliasem `xzless`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzless`
