# pnmtopnm

> To polecenie jest aliasem `pamtopnm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pamtopnm`
