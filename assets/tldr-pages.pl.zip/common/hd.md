# hd

> To polecenie jest aliasem `hexdump`.
> Więcej informacji: <https://manned.org/hd.1>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hexdump`
