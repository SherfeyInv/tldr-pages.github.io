# hd

> To polecenie jest aliasem `hexdump`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hexdump`
