# w

> Pokazuje kto jest zalogowany i co aktualnie robi.
> Wyświetla login, TTY, zdalny host, czas zalogowania, czas bezczynności i aktualny proces.
> Więcej informacji: <https://manned.org/w>.

- Pokazuje informacje o aktualnie zalogowanych użytkownikach:

`w`

- Pokazuje aktualnie zalogowanych użytkowników bez nagłówka:

`w -h`
