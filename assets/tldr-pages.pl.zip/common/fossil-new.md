# fossil new

> To polecenie jest aliasem  `fossil init`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil-init`
