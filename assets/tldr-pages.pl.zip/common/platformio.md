# platformio

> To polecenie jest aliasem `pio`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio`
