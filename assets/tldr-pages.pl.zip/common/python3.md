# python3

> To polecenie jest aliasem `python`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr python`
