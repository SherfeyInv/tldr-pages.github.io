# llvm-ar

> To polecenie jest aliasem `ar`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ar`
