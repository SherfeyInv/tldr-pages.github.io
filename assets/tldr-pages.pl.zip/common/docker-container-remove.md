# docker container remove

> To polecenie jest aliasem `docker rm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker rm`
