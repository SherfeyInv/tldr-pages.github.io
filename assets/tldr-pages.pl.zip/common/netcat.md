# netcat

> To polecenie jest aliasem `nc`.
> Więcej informacji: <https://manned.org/nc>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nc`
