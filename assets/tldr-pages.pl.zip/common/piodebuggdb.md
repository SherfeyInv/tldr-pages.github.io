# piodebuggdb

> To polecenie jest aliasem `pio debug --interface=gdb`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio debug`
