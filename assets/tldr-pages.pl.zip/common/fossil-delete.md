# fossil delete

> To polecenie jest aliasem `fossil rm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil rm`
