# lzcat

> To polecenie jest aliasem `xz`.
> Więcej informacji: <https://manned.org/lzcat>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
