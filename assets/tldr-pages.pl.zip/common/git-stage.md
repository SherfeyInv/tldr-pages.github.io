# git stage

> To polecenie jest aliasem `git add`.
> Więcej informacji: <https://git-scm.com/docs/git-stage>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr git add`
