# todoman

> To polecenie jest aliasem `todo`.
> Więcej informacji: <https://todoman.readthedocs.io/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr todo`
