# fossil ci

> To polecenie jest aliasem  `fossil commit`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil commit`
