# fossil ci

> To polecenie jest aliasem  `fossil commit`.
> Więcej informacji: <https://fossil-scm.org/home/help/commit>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil-commit`
