# npm restart

> To polecenie jest aliasem `npm run restart`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm run`
