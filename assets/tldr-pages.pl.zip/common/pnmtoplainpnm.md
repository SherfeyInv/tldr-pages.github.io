# pnmtoplainpnm

> To polecenie jest aliasem `pamtopnm -plain`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pamtopnm`
