# ntl

> To polecenie jest aliasem `netlify`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr netlify`
