# ntl

> To polecenie jest aliasem `netlify`.
> Więcej informacji: <https://cli.netlify.com>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr netlify`
