# lckdo

> To polecenie jest przestarzałe i zastąpione przez `flock`.
> Więcej informacji: <https://joeyh.name/code/moreutils/>.

- Zobacz dokumentację zalecanego zamiennika:

`tldr flock`
