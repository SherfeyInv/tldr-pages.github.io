# llvm-strings

> To polecenie jest aliasem `strings`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr strings`
