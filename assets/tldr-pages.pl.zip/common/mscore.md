# mscore

> To polecenie jest aliasem `musescore`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr musescore`
