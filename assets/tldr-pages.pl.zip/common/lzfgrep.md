# lzfgrep

> To polecenie jest aliasem `xzgrep --fixed-strings`.
> Zobacz także: `fgrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzgrep`
