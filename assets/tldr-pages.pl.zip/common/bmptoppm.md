# bmptoppm

> To polecenie zostało zastąpione przez `bmptopnm`.
> Więcej informacji: <https://netpbm.sourceforge.net/doc/bmptoppm.html>.

- Zobacz dokumentację aktualnego polecenia:

`tldr bmptopnm`
