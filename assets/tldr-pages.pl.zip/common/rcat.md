# rcat

> To polecenie jest aliasem `rc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rc`
