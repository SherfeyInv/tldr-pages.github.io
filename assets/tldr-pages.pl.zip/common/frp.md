# frp

> Fast Reverse Proxy: szybko konfiguruj tunele sieciowe w celu udostępnienia określonych usług w Internecie lub innych sieciach zewnętrznych.
> Więcej informacji: <https://github.com/fatedier/frp>.

- Zobacz dokumentację `frpc`, komponentu klienta `frp`:

`tldr frpc`

- Zobacz dokumentację `frps`, komponentu serwera `frp`:

`tldr frps`
