# pio init

> To polecenie jest aliasem `pio project init`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio project`
