# bundler

> To polecenie jest aliasem `bundle`.
> Więcej informacji: <https://bundler.io/man/bundle.1.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bundle`
