# lzmore

> To polecenie jest aliasem `xzmore`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzmore`
