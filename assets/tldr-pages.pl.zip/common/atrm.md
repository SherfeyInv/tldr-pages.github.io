# atrm

> Usuń zadania zaplanowane przez komendę `at` lub `batch`.
> Aby znaleźć numery zadań, użyj `atq`.
> Więcej informacji: <https://manned.org/atrm>.

- Usuń zadanie numer 10:

`atrm {{10}}`

- Usuń kilka zadań, oddzielonych spacjami:

`atrm {{15}} {{17}} {{22}}`
