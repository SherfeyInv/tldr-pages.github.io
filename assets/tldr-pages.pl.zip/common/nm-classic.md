# nm-classic

> To polecenie jest aliasem `nm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nm`
