# montage

> To polecenie jest aliasem `magick montage`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick montage`
