# unlzma

> To polecenie jest aliasem `xz`.
> Więcej informacji: <https://manned.org/unlzma>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
