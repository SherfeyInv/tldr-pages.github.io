# docker container top

> To polecenie jest aliasem `docker top`.
> Więcej informacji: <https://docs.docker.com/reference/cli/docker/container/top/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker top`
