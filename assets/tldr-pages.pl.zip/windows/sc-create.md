# sc create

> To polecenie jest aliasem `sc.exe create`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
