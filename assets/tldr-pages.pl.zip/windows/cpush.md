# cpush

> To polecenie jest aliasem `choco-push`.
> Więcej informacji: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco-push`
