# cpush

> To polecenie jest aliasem `choco-push`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco-push`
