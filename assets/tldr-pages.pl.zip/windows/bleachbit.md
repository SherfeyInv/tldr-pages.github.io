# bleachbit

> To polecenie jest aliasem `bleachbit_console`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bleachbit_console`
