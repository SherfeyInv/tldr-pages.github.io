# iwr

> To polecenie jest aliasem `invoke-webrequest`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr invoke-webrequest`
