# clist

> To polecenie jest aliasem `choco list`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco list`
