# clist

> To polecenie jest aliasem `choco list`.
> Więcej informacji: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco list`
