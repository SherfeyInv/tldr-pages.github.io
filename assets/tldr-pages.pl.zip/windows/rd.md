# rd

> To polecenie jest aliasem `rmdir` w Wierszu Poleceń i `Remove-Item` w PowerShell.

- Zobacz dokumentację oryginalnego polecenia Wiersza Poleceń:

`tldr rmdir`

- Zobacz dokumentację oryginalnego polecenia PowerShell:

`tldr remove-item`
