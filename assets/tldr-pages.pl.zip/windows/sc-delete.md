# sc delete

> To polecenie jest aliasem `sc.exe delete`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
