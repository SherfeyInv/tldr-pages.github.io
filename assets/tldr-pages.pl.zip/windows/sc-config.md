# sc config

> To polecenie jest aliasem `sc.exe config`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
