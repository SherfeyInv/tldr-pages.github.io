# choco feature

> Zarządzanie dostępnymi funkcjani Chocolatey.
> Więcej informacji: <https://chocolatey.org/docs/commands-feature>.

- Wyświetlanie listy dostępnych funkcji:

`choco feature list`

- Włączenie podanej funkcji:

`choco feature enable --name {{nazwa_funkcji}}`

- Wyłączenie podanej funkcji:

`choco feature disable --name {{nazwa_funkcji}}`
