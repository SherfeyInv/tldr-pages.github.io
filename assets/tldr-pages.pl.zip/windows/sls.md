# sls

> To polecenie jest aliasem `Select-String`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr select-string`
