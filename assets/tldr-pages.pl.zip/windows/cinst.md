# cinst

> To polecenie jest aliasem `choco install`.
> Więcej informacji: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco install`
