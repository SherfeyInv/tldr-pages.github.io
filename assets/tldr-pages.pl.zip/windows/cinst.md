# cinst

> To polecenie jest aliasem `choco install`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco install`
