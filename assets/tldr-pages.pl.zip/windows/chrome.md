# chrome

> To polecenie jest aliasem `chromium`.
> Więcej informacji: <https://chrome.google.com>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chromium`
