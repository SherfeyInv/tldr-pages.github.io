# ver

> Wyświetl aktualną wersję systemu DOS lub Windows.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- Wyświetl aktualną wersję systemu:

`ver`
