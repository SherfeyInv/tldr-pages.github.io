# cuninst

> To polecenie jest aliasem `choco uninstall`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco uninstall`
