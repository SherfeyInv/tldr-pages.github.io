# pwsh where

> To polecenie jest aliasem `Where-Object`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr Where-Object`
