# slmgr

> To polecenie jest aliasem `slmgr.vbs`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr slmgr.vbs`
