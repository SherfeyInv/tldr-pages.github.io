# sc query

> To polecenie jest aliasem `sc.exe query`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
