# bugreport

> Wyświetl raport o błędach Android.
> Ta komenda może być używana tylko poprzez `adb shell`.
> Więcej informacji: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Wyświetl pełny raport błędów dla urządzenia Android:

`bugreport`
