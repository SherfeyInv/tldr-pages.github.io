# cmd

> Menedżer usług Android.
> Więcej informacji: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- Pokaż wszystkie działające usługi:

`cmd -l`

- Uruchom konkretną usługę:

`cmd {{usługa}}`

- Uruchom usługę z określonymi argumentami:

`cmd {{usługa}} {{argument1 argument2 ...}}`
