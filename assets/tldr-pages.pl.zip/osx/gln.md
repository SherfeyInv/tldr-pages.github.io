# gln

> To polecenie jest aliasem `-p linux ln`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ln`
