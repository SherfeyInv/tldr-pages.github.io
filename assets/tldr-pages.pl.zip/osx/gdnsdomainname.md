# gdnsdomainname

> To polecenie jest aliasem `-p linux dnsdomainname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux dnsdomainname`
