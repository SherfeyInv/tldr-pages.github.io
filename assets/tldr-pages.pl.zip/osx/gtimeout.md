# gtimeout

> To polecenie jest aliasem `-p linux timeout`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux timeout`
