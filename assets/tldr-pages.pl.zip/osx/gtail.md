# gtail

> To polecenie jest aliasem `-p linux tail`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tail`
