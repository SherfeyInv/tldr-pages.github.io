# gfind

> To polecenie jest aliasem `-p linux find`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux find`
