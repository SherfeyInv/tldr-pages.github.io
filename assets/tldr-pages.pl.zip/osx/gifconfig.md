# gifconfig

> To polecenie jest aliasem `-p linux ifconfig`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ifconfig`
