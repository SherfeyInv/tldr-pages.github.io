# gnl

> To polecenie jest aliasem `-p linux nl`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux nl`
