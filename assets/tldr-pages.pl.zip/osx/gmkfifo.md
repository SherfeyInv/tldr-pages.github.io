# gmkfifo

> To polecenie jest aliasem `-p linux mkfifo`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux mkfifo`
