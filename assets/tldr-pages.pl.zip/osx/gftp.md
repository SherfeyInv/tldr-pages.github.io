# gftp

> To polecenie jest aliasem `-p linux ftp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ftp`
