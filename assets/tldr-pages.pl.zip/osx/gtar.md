# gtar

> To polecenie jest aliasem `-p linux tar`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tar`
