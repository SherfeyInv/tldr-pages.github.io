# gptx

> To polecenie jest aliasem `-p linux ptx`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ptx`
