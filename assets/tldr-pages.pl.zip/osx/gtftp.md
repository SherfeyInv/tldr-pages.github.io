# gtftp

> To polecenie jest aliasem `-p linux tftp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tftp`
