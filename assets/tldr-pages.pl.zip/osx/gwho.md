# gwho

> To polecenie jest aliasem `-p linux who`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux who`
