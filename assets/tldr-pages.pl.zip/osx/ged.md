# ged

> To polecenie jest aliasem `-p linux ed`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ed`
