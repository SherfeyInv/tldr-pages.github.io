# gunlink

> To polecenie jest aliasem `-p linux unlink`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux unlink`
