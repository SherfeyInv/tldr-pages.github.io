# gsync

> To polecenie jest aliasem `-p linux sync`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sync`
