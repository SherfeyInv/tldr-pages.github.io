# gyes

> To polecenie jest aliasem `-p linux yes`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux yes`
