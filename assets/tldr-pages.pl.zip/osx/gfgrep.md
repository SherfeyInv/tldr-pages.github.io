# gfgrep

> To polecenie jest aliasem `-p linux fgrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux fgrep`
