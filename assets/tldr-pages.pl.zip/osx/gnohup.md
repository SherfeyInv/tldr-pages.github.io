# gnohup

> To polecenie jest aliasem `-p linux nohup`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux nohup`
