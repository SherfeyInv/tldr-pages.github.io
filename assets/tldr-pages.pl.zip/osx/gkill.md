# gkill

> To polecenie jest aliasem `-p linux kill`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux kill`
