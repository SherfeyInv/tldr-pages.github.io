# gdirname

> To polecenie jest aliasem `-p linux dirname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux dirname`
