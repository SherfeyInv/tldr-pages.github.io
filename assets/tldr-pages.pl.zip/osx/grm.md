# grm

> To polecenie jest aliasem `-p linux rm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux rm`
