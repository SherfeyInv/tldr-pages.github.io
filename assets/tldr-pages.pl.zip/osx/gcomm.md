# gcomm

> To polecenie jest aliasem `-p linux comm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux comm`
