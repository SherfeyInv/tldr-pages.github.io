# gunexpand

> To polecenie jest aliasem `-p linux unexpand`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux unexpand`
