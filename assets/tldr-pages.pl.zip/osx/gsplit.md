# gsplit

> To polecenie jest aliasem `-p linux split`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux split`
