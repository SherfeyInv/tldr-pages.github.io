# greadlink

> To polecenie jest aliasem `-p linux readlink`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux readlink`
