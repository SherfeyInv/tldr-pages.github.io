# gcp

> To polecenie jest aliasem `-p linux cp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux cp`
