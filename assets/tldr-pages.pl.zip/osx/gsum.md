# gsum

> To polecenie jest aliasem `-p linux sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sum`
