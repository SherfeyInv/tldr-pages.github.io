# gb2sum

> To polecenie jest aliasem `-p linux b2sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux b2sum`
