# gtrue

> To polecenie jest aliasem `-p linux true`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux true`
