# gwhois

> To polecenie jest aliasem `-p linux whois`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux whois`
