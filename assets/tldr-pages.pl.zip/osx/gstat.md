# gstat

> To polecenie jest aliasem `-p linux stat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux stat`
