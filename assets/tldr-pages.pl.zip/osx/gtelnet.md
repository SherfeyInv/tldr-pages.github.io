# gtelnet

> To polecenie jest aliasem `-p linux telnet`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux telnet`
