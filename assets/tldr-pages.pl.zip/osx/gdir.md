# gdir

> To polecenie jest aliasem `-p linux dir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux dir`
