# god

> To polecenie jest aliasem `-p linux od`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux od`
