# gfold

> To polecenie jest aliasem `-p linux fold`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux fold`
