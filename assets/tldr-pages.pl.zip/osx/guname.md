# guname

> To polecenie jest aliasem `-p linux uname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux uname`
