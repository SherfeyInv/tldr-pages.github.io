# glogname

> To polecenie jest aliasem `-p linux logname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux logname`
