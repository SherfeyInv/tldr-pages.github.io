# glibtoolize

> To polecenie jest aliasem `-p linux libtoolize`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux libtoolize`
