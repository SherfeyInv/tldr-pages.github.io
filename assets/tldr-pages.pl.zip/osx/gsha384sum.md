# gsha384sum

> To polecenie jest aliasem `-p linux sha384sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sha384sum`
