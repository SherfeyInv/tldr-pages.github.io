# gstdbuf

> To polecenie jest aliasem `-p linux stdbuf`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux stdbuf`
