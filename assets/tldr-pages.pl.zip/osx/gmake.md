# gmake

> To polecenie jest aliasem `-p linux make`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux make`
