# grcp

> To polecenie jest aliasem `-p linux rcp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux rcp`
