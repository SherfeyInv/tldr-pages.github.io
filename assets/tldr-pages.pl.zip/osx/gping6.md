# gping6

> To polecenie jest aliasem `-p linux ping6`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ping6`
