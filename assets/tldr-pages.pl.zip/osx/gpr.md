# gpr

> To polecenie jest aliasem `-p linux pr`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux pr`
