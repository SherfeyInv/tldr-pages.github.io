# gdf

> To polecenie jest aliasem `-p linux df`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux df`
