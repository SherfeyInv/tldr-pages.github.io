# gbasename

> To polecenie jest aliasem `-p linux basename`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux basename`
