# gsha224sum

> To polecenie jest aliasem `-p linux sha224sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sha224sum`
