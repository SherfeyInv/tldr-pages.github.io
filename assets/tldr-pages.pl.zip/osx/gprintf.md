# gprintf

> To polecenie jest aliasem `-p linux printf`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux printf`
