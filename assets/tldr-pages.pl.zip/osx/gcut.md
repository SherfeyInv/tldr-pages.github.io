# gcut

> To polecenie jest aliasem `-p linux cut`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux cut`
