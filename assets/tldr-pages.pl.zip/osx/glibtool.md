# glibtool

> To polecenie jest aliasem `-p linux libtool`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux libtool`
