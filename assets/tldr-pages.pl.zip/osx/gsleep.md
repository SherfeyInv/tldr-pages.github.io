# gsleep

> To polecenie jest aliasem `-p linux sleep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sleep`
