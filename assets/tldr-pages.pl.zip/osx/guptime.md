# guptime

> To polecenie jest aliasem `-p linux uptime`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux uptime`
