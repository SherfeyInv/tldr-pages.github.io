# gtr

> To polecenie jest aliasem `-p linux tr`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tr`
