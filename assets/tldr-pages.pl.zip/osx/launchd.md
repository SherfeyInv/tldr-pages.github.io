# launchd

> To polecenie jest aliasem `launchctl`.
> Więcej informacji: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr launchctl`
