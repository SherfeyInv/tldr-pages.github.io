# grealpath

> To polecenie jest aliasem `-p linux realpath`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux realpath`
