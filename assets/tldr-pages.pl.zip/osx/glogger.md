# glogger

> To polecenie jest aliasem `-p linux logger`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux logger`
