# glocate

> To polecenie jest aliasem `-p linux locate`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux locate`
