# gsed

> To polecenie jest aliasem `-p linux sed`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sed`
