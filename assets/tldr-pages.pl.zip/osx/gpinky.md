# gpinky

> To polecenie jest aliasem `-p linux pinky`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux pinky`
