# ghostname

> To polecenie jest aliasem `-p linux hostname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux hostname`
