# guniq

> To polecenie jest aliasem `-p linux uniq`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux uniq`
