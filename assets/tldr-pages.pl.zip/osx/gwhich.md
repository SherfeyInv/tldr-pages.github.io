# gwhich

> To polecenie jest aliasem `-p linux which`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux which`
