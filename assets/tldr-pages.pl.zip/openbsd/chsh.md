# chsh

> Ta komenda jest aliasem `chpass`.

- Pokaż dokumentację oryginalnej komendy:

`tldr chpass`
