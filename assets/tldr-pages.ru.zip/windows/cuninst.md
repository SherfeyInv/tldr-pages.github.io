# cuninst

> Эта команда — псевдоним для `choco uninstall`.
> Больше информации: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Смотри документацию для оригинальной команды:

`tldr choco uninstall`
