# iwr

> Эта команда — псевдоним для `invoke-webrequest`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Смотри документацию для оригинальной команды:

`tldr invoke-webrequest`
