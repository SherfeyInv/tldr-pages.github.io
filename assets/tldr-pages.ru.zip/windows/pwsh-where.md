# pwsh where

> Эта команда — псевдоним для `Where-Object`.

- Смотри документацию для оригинальной команды:

`tldr Where-Object`
