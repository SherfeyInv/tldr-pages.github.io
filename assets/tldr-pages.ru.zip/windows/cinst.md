# cinst

> Эта команда — псевдоним для `choco install`.

- Смотри документацию для оригинальной команды:

`tldr choco install`
