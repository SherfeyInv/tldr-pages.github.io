# curl

> Эта команда — псевдоним для `curl -p common`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Смотри документацию для оригинальной команды:

`tldr curl -p common`
