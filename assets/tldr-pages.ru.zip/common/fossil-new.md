# fossil new

> Эта команда — псевдоним для `fossil init`.
> Больше информации: <https://fossil-scm.org/home/help/new>.

- Смотри документацию для оригинальной команды:

`tldr fossil init`
