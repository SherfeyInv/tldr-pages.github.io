# gnmic sub

> Эта команда — псевдоним для `gnmic subscribe`.
> Больше информации: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Смотри документацию для оригинальной команды:

`tldr gnmic subscribe`
