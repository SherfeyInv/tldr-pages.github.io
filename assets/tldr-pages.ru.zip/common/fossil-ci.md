# fossil ci

> Эта команда — псевдоним для  `fossil commit`.
> Больше информации: <https://fossil-scm.org/home/help/commit>.

- Смотри документацию для оригинальной команды:

`tldr fossil commit`
