# fossil delete

> Эта команда — псевдоним для `fossil rm`.

- Смотри документацию для оригинальной команды:

`tldr fossil rm`
