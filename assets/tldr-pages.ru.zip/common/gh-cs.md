# gh cs

> Эта команда — псевдоним для  `gh codespace`.
> Больше информации: <https://cli.github.com/manual/gh_codespace>.

- Смотри документацию для оригинальной команды:

`tldr gh-codespace`
