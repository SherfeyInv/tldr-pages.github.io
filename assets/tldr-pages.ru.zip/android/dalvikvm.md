# dalvikvm

> Виртуальная машина Android Java.
> Больше информации: <https://source.android.com/docs/core/runtime>.

- Запустить Java-программу:

`dalvikvm -classpath {{путь/к/файлу.jar}} {{classname}}`
