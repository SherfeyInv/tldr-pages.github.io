# lndir

> Create a shadow directory of symbolic links to another directory tree.
> More information: <https://manned.org/lndir>.

- Create a shadow directory in the current directory:

`lndir {{path/to/directory}}`
