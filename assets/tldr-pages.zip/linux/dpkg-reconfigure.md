# dpkg-reconfigure

> Reconfigure an already installed package.
> More information: <https://manned.org/dpkg-reconfigure.8>.

- Reconfigure one or more packages:

`dpkg-reconfigure {{package1 package2 ...}}`
