# source

> Execute commands from a file in the current shell.
> More information: <https://manned.org/source>.

- Evaluate contents of a given file:

`source {{path/to/file}}`

- Evaluate contents of a given file (alternatively replacing `source` with `.`):

`. {{path/to/file}}`
