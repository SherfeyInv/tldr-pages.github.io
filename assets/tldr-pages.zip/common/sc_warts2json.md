# sc_warts2json

> JSON dump of information contained in a `warts` file.
> More information: <https://www.caida.org/catalog/software/scamper/>.

- Convert `warts` files to JSON and output the result:

`sc_warts2json {{path/to/file1.warts path/to/file2.warts ...}}`
