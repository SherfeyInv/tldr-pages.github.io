# sunicontopnm

> Convert a Sun icon into a Netpbm image.
> More information: <https://netpbm.sourceforge.net/doc/sunicontopnm.html>.

- Convert a Sun icon into a Netpbm image:

`sunicontopnm {{path/to/input.ico}} > {{path/to/output.pbm}}`
