# idevicesyslog

> Relay syslog messages from a connected iOS device.
> More information: <https://manned.org/idevicesyslog>.

- Relay syslog messages from the connected device:

`idevicesyslog`

- Suppress kernel messages and print everything else:

`idevicesyslog --no-kernel`
