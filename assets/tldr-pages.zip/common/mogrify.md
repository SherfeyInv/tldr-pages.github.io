# mogrify

> This command is an alias of `magick mogrify`.

- View documentation for the original command:

`tldr magick mogrify`
