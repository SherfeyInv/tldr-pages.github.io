# icontopbm

> This command has been superseded by `sunicontopnm`.
> More information: <https://netpbm.sourceforge.net/doc/icontopbm.html>.

- View documentation for the current command:

`tldr sunicontopnm`
