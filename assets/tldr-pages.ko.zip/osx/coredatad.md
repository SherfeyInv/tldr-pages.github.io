# coredatad

> NSPersistentCloudKitContainer 클라이언트를 위한 CloudKit 작업을 예약합니다.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/coredatad.8.html>.

- 데몬 시작:

`coredatad`
