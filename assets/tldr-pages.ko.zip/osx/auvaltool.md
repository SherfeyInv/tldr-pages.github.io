# auvaltool

> Mac용 AudioUnit 검증 도구.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/auvaltool.1.html>.

- 모든 유형의 사용 가능한 AudioUnit 나열:

`auvaltool -a`

- 모든 유형의 사용 가능한 AudioUnit과 그 위치 나열:

`auvaltool -al`
