# watchlistd

> Apple TV 앱의 시청 목록을 관리합니다.
> 수동으로 실행하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/watchlistd.8.html>.

- 데몬 시작:

`watchlistd`
