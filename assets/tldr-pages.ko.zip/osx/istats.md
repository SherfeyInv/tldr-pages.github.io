# istats

> CPU 온도, 팬 속도, 배터리 상태 등의 다양한 통계를 표시합니다.
> 더 많은 정보: <https://github.com/Chris911/iStats>.

- 모든 통계 표시:

`istats`

- CPU 통계 모두 표시:

`istats cpu`

- 팬 통계 모두 표시:

`istats fan`

- 온도를 스캔하고 출력:

`istats scan`
