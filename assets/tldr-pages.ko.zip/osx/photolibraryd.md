# photolibraryd

> 모든 사진 라이브러리 요청을 처리합니다.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/photolibraryd.8.html>.

- 데몬 시작:

`photolibraryd`
