# applecamerad

> 카메라 관리자.
> 수동으로 호출하지 마십시오.
> 더 많은 정보: <https://www.theiphonewiki.com/wiki/Services>.

- 데몬 시작:

`applecamerad`
