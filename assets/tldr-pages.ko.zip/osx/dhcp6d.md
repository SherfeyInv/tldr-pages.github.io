# dhcp6d

> 비상태 DHCPv6 서버. 같이 보기: `InternetSharing`.
> 수동으로 실행하지 마십시오.
> 더 많은 정보: <https://www.manpagez.com/man/8/dhcp6d/>.

- 데몬 시작:

`dhcp6d`

- 사용자 지정 구성 사용:

`dhcp6d {{경로/대상/구성_파일}}`
