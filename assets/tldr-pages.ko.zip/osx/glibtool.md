# glibtool

> 이 명령어는 GNU `libtool`의 별칭입니다.

- 원본 명령어 보기:

`tldr -p linux libtool`
