# photoanalysisd

> 사진 라이브러리를 분석하여 추억, 사람 및 장면 또는 객체 기반 검색을 수행합니다.
> `photoanalysisd`는 수동으로 호출하면 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/photoanalysisd.8.html>.

- 데몬 시작:

`photoanalysisd`
