# avbdeviced

> 오디오 비디오 브리징(AVB) 장치를 관리하는 서비스.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/avbdeviced.1.html>.

- 데몬 시작:

`avbdeviced`
