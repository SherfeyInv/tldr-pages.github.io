# biomesyncd

> 동일한 계정에 등록된 기기 간 데이터를 동기화합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/biomesyncd.8.html>.

- 데몬 시작:

`biomesyncd`
