# xartstorageremoted

> xART 원격 저장소 데몬. 코프로세서로부터 저장/가져오기 요청을 수신합니다.
> 수동으로 실행하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/xartstorageremoted.8.html>.

- 데몬 시작:

`xartstorageremoted`
