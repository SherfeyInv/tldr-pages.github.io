# readlink

> 심볼릭 링크를 따라가고 심볼릭 링크 정보를 가져옵니다.
> 더 많은 정보: <https://www.gnu.org/software/coreutils/readlink>.

- 심볼릭 링크가 가리키는 절대 경로를 출력:

`readlink {{경로/대상/심볼릭_링크_파일}}`
