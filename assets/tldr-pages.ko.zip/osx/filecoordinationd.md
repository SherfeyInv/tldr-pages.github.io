# filecoordinationd

> 여러 프로세스가 파일에 접근하는 것을 조정합니다 (`NSFileCoordinator`, `NSFilePresenter`).
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/filecoordinationd.8.html>.

- 데몬 시작:

`filecoordinationd`
