# universalaccessd

> 유니버설 접근 서비스 가져오기.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/universalaccessd.8.html>.

- 데몬 시작:

`universalaccessd`
