# reboot

> 시스템을 재부팅합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/reboot.8.html>.

- 즉시 재부팅:

`sudo reboot`

- 정상적으로 종료하지 않고 즉시 재부팅:

`sudo reboot -q`
