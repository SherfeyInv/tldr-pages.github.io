# archey

> 시스템 정보를 스타일리시하게 표시합니다.
> 더 많은 정보: <https://github.com/joshfinnie/archey-osx>.

- 시스템 정보 표시:

`archey`

- 색상 없이 시스템 정보 표시:

`archey --nocolor`

- Homebrew 대신 MacPorts를 사용하여 시스템 정보 표시:

`archey --macports`

- IP 주소 확인 없이 시스템 정보 표시:

`archey --offline`
