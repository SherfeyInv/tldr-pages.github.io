# appsleepd

> 앱 절전 서비스를 시작합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/appsleepd.8.html>.

- 데몬 시작:

`appsleepd`
