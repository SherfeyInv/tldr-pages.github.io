# machine

> 머신 유형을 출력합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/machine.1.html>.

- CPU 아키텍처 출력:

`machine`
