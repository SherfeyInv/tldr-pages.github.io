# watchdogd

> Watchdog KEXT와 함께 작동하여 시스템의 건강 상태와 실행 여부를 보장합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/watchdogd.8.html>.

- 데몬 시작:

`watchdogd`
