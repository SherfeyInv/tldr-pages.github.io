# systemsoundserverd

> Core Audio 관련 데몬.
> 수동으로 실행해서는 안 됩니다.

- 데몬 시작:

`systemsoundserverd`
