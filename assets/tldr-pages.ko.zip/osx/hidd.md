# hidd

> HID 라이브러리 사용자 영역 데몬.
> 수동으로 호출하지 말아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/hidd.8.html>.

- 데몬 시작:

`hidd`
