# usernoted

> 알림 서비스를 제공합니다.
> 수동으로 실행해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/usernoted.8.html>.

- 데몬 시작:

`usernoted`
