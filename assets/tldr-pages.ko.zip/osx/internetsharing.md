# InternetSharing

> 인터넷 공유 설정.
> 수동으로 실행하지 않아야 합니다.
> 더 많은 정보: <https://www.manpagez.com/man/8/InternetSharing/>.

- 데몬 시작:

`InternetSharing`
