# cloudd

> CloudKit 기능을 지원합니다.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/cloudd.8.html>.

- 데몬 시작:

`cloudd`
