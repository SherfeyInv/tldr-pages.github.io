# securityd

> 보안 컨텍스트와 암호화 작업을 관리합니다.
> 키체인 접근을 위해 secd와 함께 작동합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/securityd.1.html>.

- 데몬 시작:

`securityd`
