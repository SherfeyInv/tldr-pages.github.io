# bird

> iCloud 및 iCloud Drive의 동기화 지원.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/bird.8.html>.

- 데몬 시작:

`bird`
