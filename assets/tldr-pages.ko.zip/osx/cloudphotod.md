# cloudphotod

> iCloud 사진을 동기화합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://www.manpagez.com/man/8/cloudphotosd/>.

- 데몬 시작:

`cloudphotod`
