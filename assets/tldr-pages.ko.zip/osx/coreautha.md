# coreautha

> `LocalAuthentication` 프레임워크를 제공하는 시스템 에이전트.
> 수동으로 호출해서는 안 됩니다. 같이 보기: `coreauthd`.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/coreautha.8.html>.

- 에이전트 시작:

`coreautha`
