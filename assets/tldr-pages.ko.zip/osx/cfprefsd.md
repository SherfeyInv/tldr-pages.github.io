# cfprefsd

> 환경설정 서비스(`CFPreferences`, `NSUserDefaults`) 시작.
> 수동으로 실행하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/cfprefsd.8.html>.

- 데몬 시작:

`cfprefsd`
