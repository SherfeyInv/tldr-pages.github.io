# apachectl

> macOS용 Apache HTTP Server 제어 인터페이스.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/apachectl.8.html>.

- `org.apache.httpd` launchd 작업 시작:

`apachectl start`

- launchd 작업 중지:

`apachectl stop`

- launchd 작업을 중지한 후 시작:

`apachectl restart`
