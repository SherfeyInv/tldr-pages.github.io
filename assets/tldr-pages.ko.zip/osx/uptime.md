# uptime

> 시스템이 얼마나 오래 실행 중인지 및 기타 정보를 표시합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/uptime.1.html>.

- 현재 시간, 시스템 가동 시간, 로그인한 사용자 수 및 기타 정보 출력:

`uptime`
