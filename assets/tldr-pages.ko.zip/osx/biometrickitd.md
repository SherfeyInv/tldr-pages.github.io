# biometrickitd

> 생체 인식 작업 지원을 받습니다.
> 수동으로 호출하지 마세요.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/biometrickitd.8.html>.

- 데몬 시작:

`biometrickitd`
