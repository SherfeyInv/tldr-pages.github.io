# uuidgen

> 새 UUID(범용 고유 식별자) 문자열 생성.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/uuidgen.1.html>.

- UUID 문자열 생성:

`uuidgen`
