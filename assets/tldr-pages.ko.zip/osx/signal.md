# signal

> 간소화된 소프트웨어 시그널 기능.
> 더 많은 정보: <https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man3/signal.3.html>.

- macOS에서 시그널에 대한 문서 보기:

`man signal`
