# timed

> 시스템 시간을 동기화하는 서비스(NTP 사용 등).
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/timed.8.html>.

- 데몬 시작:

`timed`
