# wifi-password

> Wi-Fi 비밀번호를 가져옵니다.
> 더 많은 정보: <https://github.com/rauchg/wifi-password>.

- 현재 로그인한 Wi-Fi의 비밀번호 가져오기:

`wifi-password`

- 특정 SSID의 Wi-Fi 비밀번호 가져오기:

`wifi-password {{ssid}}`

- 비밀번호만 출력:

`wifi-password -q`
