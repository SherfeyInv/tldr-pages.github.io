# warmd

> 시작 및 로그인 시 사용되는 캐시를 제어합니다.
> 수동으로 실행하지 마십시오.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/warmd.8.html>.

- 데몬 시작:

`warmd`
