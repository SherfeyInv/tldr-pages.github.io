# xsand

> Xsan 파일 시스템 관리 데몬. Xsan 파일 시스템에 대한 서비스를 제공합니다.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://developer.apple.com/support/downloads/Xsan-Management-Guide.pdf>.

- 데몬 시작:

`xsand`
