# translationd

> 번역 기능을 활성화합니다.
> 수동으로 호출하지 않아야 합니다.

- 데몬 시작:

`translationd`
