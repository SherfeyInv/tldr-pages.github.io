# wps

> AirPort가 무선 보호 설정(Wireless Protected Setup)을 사용하여 네트워크에 연결하는 것을 지원합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/wps.8.html>.

- 데몬 시작:

`wps`
