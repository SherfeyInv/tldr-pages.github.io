# xip

> 안전한 xip 아카이브로 압축 파일을 생성하거나 확장.
> Apple에서 서명한 아카이브만 신뢰되므로, 이 도구는 아카이브 생성에 사용하지 마세요.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/xip.1.html>.

- 아카이브를 현재 작업 디렉토리로 확장:

`xip --expand {{경로/대상/파일.xip}}`
