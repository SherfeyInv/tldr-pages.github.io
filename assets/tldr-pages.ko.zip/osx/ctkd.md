# ctkd

> SmartCard 데몬.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/ctkd.8.html>.

- 데몬 시작:

`ctkd`
