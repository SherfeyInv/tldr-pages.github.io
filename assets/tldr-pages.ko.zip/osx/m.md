# m

> macOS용 만능 도구.
> 더 많은 정보: <https://github.com/rgcr/m-cli>.

- 배터리 상태 확인:

`m battery status`

- 블루투스 끄기:

`m bluetooth off`

- 포맷 가능한 파일 시스템 나열:

`m disk filesystems`

- Dock 자동 숨김 기능 활성화:

`m dock autohide YES`

- 방화벽 비활성화:

`m firewall disable`
