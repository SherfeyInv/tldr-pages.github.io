# ocspd

> 인증서 검증을 위해 인증서 폐기 목록(CRL)과 온라인 인증서 상태 프로토콜(OCSP) 응답을 검색하고 캐시합니다.
> 수동으로 실행하지 마십시오.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/ocspd.1.html>.

- 데몬 시작:

`ocspd`
