# mdls

> [f]파일에 대한 메타데이터 속성을 표시합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/mdls.1.html>.

- [f]파일의 메타데이터 속성 목록을 표시:

`mdls {{경로/대상/파일}}`

- 특정 메타데이터 속성을 표시:

`mdls -name {{속성}} {{경로/대상/파일}}`
