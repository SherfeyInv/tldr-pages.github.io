# coreaudiod

> Core Audio, Apple's 오디오 시스템을 위한 서비스.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://developer.apple.com/library/archive/documentation/MusicAudio/Conceptual/CoreAudioOverview/WhatisCoreAudio/WhatisCoreAudio.html>.

- 데몬 시작:

`coreaudiod`
