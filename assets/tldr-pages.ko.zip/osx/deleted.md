# deleted

> 삭제 가능한 공간을 추적하고, 공간이 부족할 때 클라이언트에게 삭제를 요청합니다.
> 수동으로 실행하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/deleted.8.html>.

- 데몬 시작:

`deleted`
