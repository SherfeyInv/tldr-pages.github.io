# bnepd

> 모든 블루투스 네트워크 연결을 처리하는 서비스.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/bnepd.8.html>.

- 데몬 시작:

`bnepd`
