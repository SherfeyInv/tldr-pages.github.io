# vm_stat

> 가상 메모리 통계를 표시합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/vm_stat.1.html>.

- 가상 메모리 통계 표시:

`vm_stat`

- 2초 간격으로 5번 보고서 표시:

`vm_stat -c {{5}} {{2}}`
