# ipconfig

> IP 구성 상태를 보고 제어합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/ipconfig.8.html>.

- 모든 네트워크 인터페이스 나열:

`ipconfig getiflist`

- 인터페이스의 IP 주소 표시:

`ipconfig getifaddr {{인터페이스_이름}}`
