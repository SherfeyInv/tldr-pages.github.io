# secd

> 키체인 항목의 액세스 및 수정을 제어합니다.
> 수동으로 실행해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/secd.8.html>.

- 데몬 시작:

`secd`
