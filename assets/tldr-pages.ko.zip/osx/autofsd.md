# autofsd

> 시작 시 및 네트워크 구성 변경 이벤트에서 `automount` 실행.
> 수동으로 호출하지 않아야 합니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/autofsd.8.html>.

- 데몬 시작:

`autofsd`
