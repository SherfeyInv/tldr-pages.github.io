# nfcd

> 이 데몬은 NFC 컨트롤러를 제어합니다.
> 수동으로 실행해서는 안 됩니다.
> 더 많은 정보: <https://keith.github.io/xcode-man-pages/nfcd.8.html>.

- 데몬 시작:

`nfcd`
