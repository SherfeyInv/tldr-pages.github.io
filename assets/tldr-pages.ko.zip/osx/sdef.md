# sdef

> 스크립트 가능한 애플리케이션에서 스크립팅 정의(`sdef`) 파일을 가져오거나 생성.
> 더 많은 정보: <https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/ScriptableCocoaApplications/SApps_creating_sdef/SAppsCreateSdef.html>.

- 지정된 애플리케이션의 스크립팅 정의 출력:

`sdef {{/Applications/XCode.app}}`
