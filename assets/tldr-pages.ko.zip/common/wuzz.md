# wuzz

> HTTP 요청 및 응답을 대화형으로 검사.
> 더 많은 정보: <https://github.com/asciimoo/wuzz>.

- `wuzz` 시작:

`wuzz`

- HTTP 요청 전송:

`<Ctrl> + R`

- 다음 보기로 전환:

`<Ctrl> + J, <Tab>`

- 이전 보기로 전환:

`<Ctrl> + K, <Shift> + <Tab>`

- 도움말 표시:

`F1`
