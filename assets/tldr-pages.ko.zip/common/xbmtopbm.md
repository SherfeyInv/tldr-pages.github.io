# xbmtopbm

> X11 또는 X10 비트맵을 PBM 이미지로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/xbmtopbm.html>.

- XBM 이미지를 PPM 이미지로 변환:

`xbmtopbm {{경로/대상/입력_파일.xbm}} > {{경로/대상/출력_파일.pbm}}`
