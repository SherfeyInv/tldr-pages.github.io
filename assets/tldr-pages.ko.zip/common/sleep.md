# sleep

> 지정된 시간만큼 지연.
> 더 많은 정보: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- 초 단위 지연:

`sleep {{초}}`

- 20초 지연 후 특정 명령 실행:

`sleep 20 && {{명령}}`
