# users

> 로그인한 사용자 목록을 표시.
> 같이 보기: `useradd`, `userdel`, `usermod`.
> 더 많은 정보: <https://www.gnu.org/software/coreutils/users>.

- 로그인한 사용자 명 출력:

`users`

- 주어진 파일에 따라 로그인한 사용자 명 출력:

`users {{/var/log/wmtp}}`
