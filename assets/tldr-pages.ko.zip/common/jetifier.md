# jetifier

> Jetifier AndroidX 전환 도구로, npm 포맷의 react-native 호환 스타일을 제공합니다.
> 더 많은 정보: <https://github.com/mikehardy/jetifier>.

- 프로젝트 종속성을 AndroidX 포맷으로 마이그레이션:

`jetifier`

- 프로젝트 종속성을 AndroidX 포맷에서 되돌리기:

`jetifier reverse`
