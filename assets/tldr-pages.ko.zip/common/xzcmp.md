# xzcmp

> `xz`, `lzma`, `gzip`, `bzip2`, `lzop`, 또는 `zstd`로 압축된 파일을 비교하기 위해 `cmp`를 호출.
> 지정된 모든 옵션은 `cmp`에 직접 전달됨.
> 더 많은 정보: <https://manned.org/xzcmp>.

- 두 개의 특정 파일 비교:

`xzcmp {{경로/대상/파일1}} {{경로/대상/파일2}}`
