# false

> 종료 코드 1을 반환한다.
> 더 많은 정보: <https://www.gnu.org/software/coreutils/false>.

- 종료 코드 1 반환:

`false`
