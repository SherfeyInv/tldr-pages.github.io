# rapper

> Raptor RDF 구문 분석 도구.
> Raptor RDF 구문 라이브러리의 일부.
> 더 많은 정보: <https://librdf.org/raptor/rapper.html>.

- RDF/XML 문서를 Turtle 형식으로 변환:

`rapper -i rdfxml -o turtle {{경로/대상/파일}}`

- Turtle 파일의 삼중항 개수 세기:

`rapper -i turtle -c {{경로/대상/파일}}`
