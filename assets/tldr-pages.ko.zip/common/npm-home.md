# npm-home

> 웹 브라우저에서 패키지의 npm 페이지, Yarn 페이지 또는 GitHub 저장소를 열어줍니다.
> 더 많은 정보: <https://github.com/sindresorhus/npm-home>.

- 웹 브라우저에서 특정 패키지의 npm 페이지를 열기:

`npm-home {{패키지}}`

- 웹 브라우저에서 특정 패키지의 Github 저장소를 열기:

`npm-home -g {{패키지}}`

- 웹 브라우저에서 특정 패키지의 Yarn 페이지를 열기:

`npm-home -y {{패키지}}`
