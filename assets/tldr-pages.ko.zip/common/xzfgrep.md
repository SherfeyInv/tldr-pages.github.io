# xzfgrep

> 이 명령은 `xzgrep --fixed-strings`의 별칭입니다.
> 같이 보기: `fgrep`.

- 원본 명령에 대한 문서 보기:

`tldr xzgrep`
