# pbmtowbmp

> PBM 이미지를 무선 비트맵 파일로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pbmtowbmp.html>.

- PBM 이미지를 WBMP 파일로 변환:

`pbmtowbmp {{경로/대상/입력_파일.pbm}} > {{경로/대상/출력_파일.wbmp}}`
