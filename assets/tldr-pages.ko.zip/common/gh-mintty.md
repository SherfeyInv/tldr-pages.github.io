# gh mintty

> GitHub CLI 명령에 대한 MinTTY 통합 도움말 표시.
> 더 많은 정보: <https://cli.github.com/manual/gh_help_mintty>.

- MinTTY에서 `gh` 사용에 대한 도움말 표시:

`gh mintty`
