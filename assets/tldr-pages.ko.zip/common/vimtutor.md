# vimtutor

> Vim 튜터로, 기본 Vim 명령어를 가르칩니다.
> 같이 보기: `vim`, `vimdiff`, `nvim`.
> 더 많은 정보: <https://manned.org/vimtutor>.

- 주어진 언어로 Vim 튜터 시작 (예: en, fr, de 등):

`vimtutor {{언어}}`

- 튜터 종료:

`<Esc> :q <Enter>`
