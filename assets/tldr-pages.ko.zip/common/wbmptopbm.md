# wbmptopbm

> 무선 비트맵 파일을 PBM 이미지로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/wbmptopbm.html>.

- WBMP 파일을 PBM 이미지로 변환:

`wbmptopbm {{경로/대상/입력_파일.wbpm}} > {{경로/대상/출력_파일.pbm}}`
