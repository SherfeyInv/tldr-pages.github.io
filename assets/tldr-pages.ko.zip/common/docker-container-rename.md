# docker container rename

> 이 명령은 `docker rename`의 별칭입니다.
> 더 많은 정보: <https://docs.docker.com/reference/cli/docker/container/rename/>.

- 원본 명령에 대한 문서 보기:

`tldr docker rename`
