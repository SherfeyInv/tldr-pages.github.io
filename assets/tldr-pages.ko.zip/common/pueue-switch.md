# pueue switch

> 대기열에 있는 두 명령 또는 보관된 명령의 위치를 바꿉니다.
> 더 많은 정보: <https://github.com/Nukesor/pueue>.

- 두 작업의 우선순위 변경:

`pueue switch {{작업_아이디1}} {{작업_아이디2}}`
