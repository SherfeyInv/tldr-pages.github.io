# rustup check

> Rust 툴체인 및 `rustup` 업데이트 확인.
> 더 많은 정보: <https://rust-lang.github.io/rustup>.

- 모든 업데이트 확인:

`rustup check`
