# sunicontopnm

> Sun 아이콘을 Netpbm 이미지로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/sunicontopnm.html>.

- Sun 아이콘을 Netpbm 이미지로 변환:

`sunicontopnm {{경로/대상/입력.ico}} > {{경로/대상/출력.pbm}}`
