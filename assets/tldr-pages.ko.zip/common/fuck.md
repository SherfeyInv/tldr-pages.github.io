# fuck

> 이전 콘솔 명령을 수정.
> 더 많은 정보: <https://github.com/nvbn/thefuck>.

- `fuck` 별칭을 `thefuck` 도구로 설정:

`eval "$(thefuck --alias)"`

- 이전 명령에 대한 규칙을 일치시킴:

`fuck`

- 첫 번째 선택을 즉시 확인 (올바른 주장은 짜증의 정도에 따라 다름):

`fuck --{{yes|yeah|hard}}`
