# sc_warts2text

> `warts` 파일에 포함된 정보를 간단히 덤프.
> 더 많은 정보: <https://www.caida.org/catalog/software/scamper/>.

- `warts` 파일의 정보를 텍스트로 출력:

`sc_warts2text {{경로/대상/파일1.warts 경로/대상/파일2.warts ...}}`
