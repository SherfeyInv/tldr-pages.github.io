# script

> 터미널 세션의 typescript 파일을 생성.
> 더 많은 정보: <https://manned.org/script>.

- "typescript"라는 이름의 파일로 녹화 시작:

`script`

- 녹화 중지:

`exit`

- 지정된 파일로 녹화 시작:

`script {{로그파일.log}}`

- 기존 파일에 추가:

`script -a {{로그파일.log}}`

- 시작 및 완료 메시지 없이 조용히 실행:

`script -q {{로그파일.log}}`
