# zstdcat

> 이 명령은 `zstd --decompress --stdout`의 별칭입니다.

- 원본 명령에 대한 문서 보기:

`tldr zstd`
