# npm fund

> 패키지에서 자금 정보를 검색합니다.
> 더 많은 정보: <https://docs.npmjs.com/cli/commands/npm-fund>.

- 현재 폴더에 있는 프로젝트에 대한 자금 조달 URL로 의존성을 나열:

`npm fund`

- 기본 웹 브라우저에서 특정 패키지에 대한 자금 조달 URL 공개:

`npm fund {{패키지}}`

- 현재 폴더에 있는 프로젝트의 특정 작업 공간([w]orkspace)에 대한 자금 조달 URL을 사용하여 종속성을 나열:

`npm fund -w {{작업 공간}}`
