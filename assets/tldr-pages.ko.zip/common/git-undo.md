# git undo

> 최근 커밋을 되돌립니다.
> `git-extras`의 일부입니다.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-undo>.

- 가장 최근 커밋 제거:

`git undo`

- 가장 최근 커밋 중 특정 개수 제거:

`git undo {{3}}`
