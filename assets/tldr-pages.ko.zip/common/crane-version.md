# crane version

> 바이너리 버전을 출력.
> 버전 문자열은 바이너리 빌드 방법에 전적으로 의존, 버전 형식에 의존해서는 안 됨. 예고 없이 변경이 될 수 있음.
> 더 많은 정보: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_version.md>.

- 버전 정보 표시:

`crane version`

- 도움말 표시:

`crane version {{-h|--help}}`
