# hostapd

> 무선 인터페이스를 사용하여 액세스 포인트를 시작.
> 더 많은 정보: <https://w1.fi/hostapd/>.

- 액세스 포인트 시작:

`sudo hostapd {{경로/대상/hostapd.conf}}`

- 백그라운드로 분기하여, 액세스 포인트를 시작:

`sudo hostapd -B {{경로/대상/hostapd.conf}}`
