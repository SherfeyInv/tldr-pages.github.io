# icontopbm

> 이 명령은 `sunicontopnm`으로 대체됨.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/icontopbm.html>.

- 원본 명령의 도큐멘테이션 (설명서) 보기:

`tldr sunicontopnm`
