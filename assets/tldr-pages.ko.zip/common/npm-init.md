# npm init

> `package.json` 파일 생성.
> 더 많은 정보: <https://docs.npmjs.com/cli/commands/npm-init>.

- 프롬프트를 사용하여 새 패키지 초기화:

`npm init`

- 기본값으로 새 패키지 초기화:

`npm init -y`

- 특정 초기화 도구를 사용하여 새 패키지 초기화:

`npm init {{create-react-app}} {{my-app}}`
