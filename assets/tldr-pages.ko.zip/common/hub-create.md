# hub create

> GitHub에서 새로운 레포지토리 생성.
> 더 많은 정보: <https://hub.github.com/hub-create.1.html>.

- 현재 (로컬 전용) 저장소를 GitHub 계정에 공개로 업로드:

`hub create`

- 개인 저장소를 생성하고 웹 브라우저에서 새로운 저장소를 열기:

`hub create --private --browse`
