# calligrasheets

> Calligra의 스프레드 시트 애플리케이션.
> 참고: `calligraflow`, `calligrastage`, `calligrawords`.
> 더 많은 정보: <https://manned.org/calligrasheets>.

- 스프레드시트 애플리케이션을 실행:

`calligrasheets`

- 특정 스프레드시트 열기:

`calligrasheets {{경로/대상/스프레드시트}}`

- 도움말 또는 버전 표시:

`calligrasheets --{{help|version}}`
