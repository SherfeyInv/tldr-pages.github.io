# pbmto4425

> PBM 이미지를 AT&T 4425 터미널에 표시.
> 같이 보기: `ppmtoterm`, `pbmtoascii`.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pbmto4425.html>.

- 터미널의 모자이크 그래픽 문자 집합을 사용하여 PBM 이미지를 AT&T 4425 터미널에 표시:

`pbmto4425 {{경로/대상/이미지.pbm}}`
