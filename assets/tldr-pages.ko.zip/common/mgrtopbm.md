# mgrtopbm

> MGR 비트맵을 PBM 파일로 변환.
> 같이 보기: `pbmtomgr`.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/mgrtopbm.html>.

- MGR 비트맵을 PBM 파일로 변환:

`mgrtopbm {{경로/대상/이미지.mgr}} > {{경로/대상/출력.pbm}}`
