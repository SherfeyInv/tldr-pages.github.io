# yuy2topam

> YUY2 바이트를 PAM으로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/yuy2topam.html>.

- YUY2 바이트를 PAM으로 변환:

`yuy2topam -width {{값}} -height {{값}} {{경로/대상/파일.yuy2}} > {{경로/대상/파일.pam}}`
