# pbmtocmuwm

> PBM 이미지를 CMU 윈도우 매니저 비트맵으로 변환.
> 같이 보기: `cmuwmtopbm`.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pbmtocmuwm.html>.

- PBM 이미지를 CMU 윈도우 매니저 비트맵으로 변환:

`pbmtocmuwm {{경로/대상/이미지.pbm}} > {{경로/대상/출력.bmp}}`
