# az logout

> Azure 구독에서 로그아웃.
> `azure-cli`의 일부 (`az`라고도 함).
> 더 많은 정보: <https://learn.microsoft.com/cli/azure/reference-index#az_logout>.

- 활성 계정에서 로그아웃:

`az logout`

- 특정 사용자 이름을 로그아웃:

`az logout --username {{alias@somedomain.com}}`
