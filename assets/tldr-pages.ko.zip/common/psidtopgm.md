# psidtopgm

> PostScript 이미지 데이터를 PGM 이미지로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/psidtopgm.html>.

- PS 파일의 이미지 데이터를 지정된 크기와 품질의 PGM 이미지로 변환:

`psidtopgm {{너비}} {{높이}} {{샘플당_비트}} {{경로/대상/파일.ps}} > {{경로/대상/이미지.pgm}}`
