# cbonsai

> 아름답고 랜덤한 분재 나무 생성도구.
> 더 많은 정보: <https://gitlab.com/jallbrit/cbonsai>.

- 라이브 모드에서 분재를 생성:

`cbonsai -l`

- 무한 모드에서 분재를 생성:

`cbonsai -i`

- 분재에 메시지를 추가:

`cbonsai -m "{{메시지}}"`

- 분재에 대한 추가 정보 표시:

`cbonsai -v`

- 도움말 표시:

`cbonsai -h`
