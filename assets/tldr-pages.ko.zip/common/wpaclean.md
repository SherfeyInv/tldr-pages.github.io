# wpaclean

> 캡처 파일을 정리하여 4-way 핸드셰이크와 비콘만 얻기.
> Aircrack-ng 네트워크 소프트웨어 모음의 일부.
> 더 많은 정보: <https://manned.org/wpaclean.1>.

- 캡처 파일을 정리하고 결과에 4-way 핸드셰이크와 비콘만 저장:

`wpaclean {{경로/대상/결과.cap}} {{경로/대상/캡처.cap}}`

- 여러 캡처 파일을 정리하고 4-way 핸드셰이크와 비콘을 결과에 저장:

`wpaclean {{경로/대상/결과.cap}} {{경로/대상/캡처1.cap 경로/대상/캡처2.cap ...}}`
