# git blame-someone-else

> 당신의 잘못된 코드를 다른 사람에게 탓하는 도구.
> 더 많은 정보: <https://github.com/jayphelps/git-blame-someone-else>.

- 커밋의 작성자와 커미터 변경:

`git blame-someone-else "{{작성자 <someone@example.com>}}" {{커밋}}`
