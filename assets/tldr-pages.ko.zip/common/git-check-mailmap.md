# git check-mailmap

> 연락처의 표준 이름과 이메일 주소를 표시.
> 더 많은 정보: <https://git-scm.com/docs/git-check-mailmap>.

- 이메일 주소와 연관된 표준 이름 조회:

`git check-mailmap "<{{email@example.com}}>"`
