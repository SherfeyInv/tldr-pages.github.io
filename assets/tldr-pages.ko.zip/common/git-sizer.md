# git sizer

> 다양한 Git 저장소 크기 메트릭을 계산하고 문제나 불편을 초래할 수 있는 항목을 경고합니다.
> 더 많은 정보: <https://github.com/github/git-sizer>.

- 우려 수준이 0보다 큰 통계만 보고:

`git sizer`

- 모든 통계 보고:

`git sizer -v`

- 추가 옵션 보기:

`git sizer -h`
