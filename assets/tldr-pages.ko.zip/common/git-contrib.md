# git contrib

> 특정 작성자의 커밋을 표시.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-contrib>.

- 특정 작성자의 모든 커밋 해시 및 해당 커밋 메시지 표시:

`git contrib {{작성자}}`
