# wordgrinder

> 명령줄 워드 프로세서.
> 더 많은 정보: <https://cowlark.com/wordgrinder>.

- WordGrinder 시작 (기본적으로 빈 문서를 로드함):

`wordgrinder`

- 지정된 파일 열기:

`wordgrinder {{경로/대상/파일}}`

- 메뉴 표시:

`<Alt> + M`
