# airpaste

> 동일 네트워크 내에서 메시지와 파일들 공유.
> 더 많은 정보: <https://github.com/mafintosh/airpaste>.

- 메시지 대기와 수신 시 표시:

`airpaste`

- 텍스트 보내기:

`echo {{텍스트}} | airpaste`

- 파일 보내기:

`airpaste < {{경로/파일명}}`

- 파일 내려받기:

`airpaste > {{경로/파일명}}`

- 채널 만들기/접속하기:

`airpaste {{채널_이름}}`
