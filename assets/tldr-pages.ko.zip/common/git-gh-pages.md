# git gh-pages

> 현재 저장소 내에 `gh-pages`라는 새 브랜치를 생성합니다.
> `git-extras`의 일부입니다.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-gh-pages>.

- 현재 디렉터리의 저장소 내에 GitHub 페이지 브랜치 생성:

`git gh-pages`
