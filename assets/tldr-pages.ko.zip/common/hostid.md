# hostid

> 현재 호스트의 숫자 식별자를 출력 (IP 주소일 필요는 없음).
> 더 많은 정보: <https://www.gnu.org/software/coreutils/hostid>.

- 현재 호스트의 숫자 식별자를 16진수로 표시:

`hostid`
