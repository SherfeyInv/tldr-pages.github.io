# git browse-ci

> 현재 `git` 저장소의 CI 웹사이트를 기본 웹 브라우저에서 엽니다.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-browse-ci>.

- 현재 저장소의 CI 설정을 업스트림 웹사이트에서 열기:

`git browse-ci`

- 특정 원격 저장소의 CI 설정을 업스트림 웹사이트에서 열기:

`git browse-ci {{remote}}`
