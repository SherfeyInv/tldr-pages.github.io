# bundletool validate

> Android 애플리케이션 번들 조작.
> 더 많은 정보: <https://developer.android.com/tools/bundletool>.

- 번들을 확인하고, 이에 대한 자세한 정보를 표시:

`bundletool validate --bundle {{경로/대상/bundle.aab}}`
