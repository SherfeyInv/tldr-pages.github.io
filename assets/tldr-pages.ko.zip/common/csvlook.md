# csvlook

> 콘솔에서 csvkit에 포함된 CSV 파일을 고정 너비 테이블로 렌더링.
> 더 많은 정보: <https://csvkit.readthedocs.io/en/latest/scripts/csvlook.html>.

- CSV 파일 보기:

`csvlook {{데이터.csv}}`
