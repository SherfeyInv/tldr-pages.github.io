# freshclam

> ClamAV 바이러스 백신 프로그램의 바이러스 정의를 업데이트.
> 더 많은 정보: <https://www.clamav.net>.

- 바이러스 정의 업데이트:

`freshclam`
