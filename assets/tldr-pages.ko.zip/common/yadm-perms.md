# yadm-perms

> 권한 업데이트.
> `yadm`이 기본적으로 권한을 자동으로 처리하므로 이 명령을 실행할 필요는 없습니다. 이 자동 동작은 설정 `yadm.auto-perms`를 `"false"`로 설정하여 비활성화할 수 있습니다.
> 더 많은 정보: <https://github.com/TheLocehiliosan/yadm/blob/master/yadm.md#permissions>.

- 파일 권한 변경:

`yadm perms`
