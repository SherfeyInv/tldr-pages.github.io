# git delete-tag

> 기존 로컬 및 원격 태그 삭제.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-delete-tag>.

- 태그 삭제:

`git delete-tag {{태그_버전}}`
