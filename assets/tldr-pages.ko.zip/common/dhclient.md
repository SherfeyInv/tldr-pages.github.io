# dhclient

> DHCP 클라이언트.
> 더 많은 정보: <https://manned.org/dhclient>.

- 'eht0' 인터페이스의 IP 주소 얻기:

`sudo dhclient {{eth0}}`

- 'eth0' 인터페이스의 IP 주소 해제하기:

`sudo dhclient -r {{eth0}}`
