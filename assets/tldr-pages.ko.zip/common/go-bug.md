# go bug

> 버그 보고.
> 더 많은 정보: <https://golang.org/cmd/go/#hdr-Start_a_bug_report>.

- 버그 보고를 시작하기 위해 웹 페이지 열기:

`go bug`
