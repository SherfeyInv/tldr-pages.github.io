# Get-NodeInstallLocation

> `ps-nvm`에 대한 현재 Node.js 설치 디렉터리를 가져옴.
> `ps-nvm`의 일부이며 PowerShell에서만 실행할 수 있음.
> 더 많은 정보: <https://github.com/aaronpowell/ps-nvm>.

- 현재 Node.js 설치 디렉터리를 가져옴:

`Get-NodeInstallLocation`
