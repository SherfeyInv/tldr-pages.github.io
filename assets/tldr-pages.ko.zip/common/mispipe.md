# mispipe

> 두 개의 명령을 파이프하고 첫 번째 명령의 종료 상태를 반환.
> 더 많은 정보: <https://joeyh.name/code/moreutils/>.

- 두 개의 명령을 파이프하고 첫 번째 명령의 종료 상태 반환:

`mispipe {{명령1}} {{명령2}}`
