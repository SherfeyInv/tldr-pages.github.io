# pgmtopbm

> 이 명령은 `pamditherbw`로 대체되었습니다.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pgmtopbm.html>.

- 현재 명령에 대한 문서 보기:

`tldr pamditherbw`
