# crane manifest

> 이미지의 매니페스트를 가져옴.
> 더 많은 정보: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_manifest.md>.

- 매니페스트 가져오기:

`crane manifest {{이미지_이름}}`

- 도움말 표시:

`crane manifest {{-h|--help}}`
