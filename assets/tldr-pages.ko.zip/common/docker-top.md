# docker top

> 컨테이너의 실행 중인 프로세스를 표시.
> 더 많은 정보: <https://docs.docker.com/reference/cli/docker/container/top/>.

- 컨테이너의 실행 중인 프로세스 표시:

`docker top {{컨테이너}}`

- 도움말 표시:

`docker top --help`
