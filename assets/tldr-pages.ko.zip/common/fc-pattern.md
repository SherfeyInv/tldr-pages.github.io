# fc-pattern

> 패턴과 일치하는 글꼴에 대한 정보를 표시.
> 더 많은 정보: <https://manned.org/fc-pattern>.

- 글꼴에 대한 기본 정보를 표시:

`fc-pattern --default '{{DejaVu Serif}}'`

- 글꼴에 대한 구성 정보 표시:

`fc-pattern --config '{{DejaVu Serif}}'`
