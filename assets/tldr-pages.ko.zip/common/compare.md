# compare

> 이 명령은 `magick compare`의 별칭.

- 원래 명령에 대한 문서 보기:

`tldr magick compare`
