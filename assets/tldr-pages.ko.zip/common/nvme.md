# nvme

> NVMe 저장소 사용자 공간 유틸리티.
> 더 많은 정보: <https://github.com/linux-nvme/nvme-cli>.

- 모든 NVMe 장치 나열:

`sudo nvme list`

- 장치 정보 표시:

`sudo nvme smart-log {{장치}}`
