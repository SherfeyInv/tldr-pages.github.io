# phpize

> PHP 확장을 컴파일할 준비를 합니다.
> 더 많은 정보: <https://www.php.net/manual/install.pecl.phpize>.

- 현재 디렉토리에서 PHP 확장을 컴파일할 준비:

`phpize`

- phpize로 생성된 파일 삭제:

`phpize --clean`
