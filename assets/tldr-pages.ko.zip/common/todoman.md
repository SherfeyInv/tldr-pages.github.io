# todoman

> 간단하고 표준 기반의 CLI 할 일 관리 도구.
> `todoman`은 `todo`라는 명령의 일반적인 이름이며, 명령 자체는 아닙니다.
> 더 많은 정보: <https://todoman.readthedocs.io/>.

- 원본 명령에 대한 문서 보기:

`tldr todo`
