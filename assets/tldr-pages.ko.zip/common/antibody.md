# antibody

> "가장 빠른" 쉘 플러그인 관리자.
> 더 많은 정보: <https://getantibody.github.io>.

- 정적 로딩을 위해 모든 플러그인을 번들로 묶음:

`antibody bundle < {{~/.zsh_plugins.txt}} > {{~/.zsh_plugins.sh}}`

- 모든 번들 업데이트:

`antibody update`

- 설치된 모든 플러그인 나열:

`antibody list`
