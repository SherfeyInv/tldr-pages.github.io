# pnmtoplainpnm

> 이 명령은 `pamtopnm -plain`의 별칭입니다.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pnmtoplainpnm.html>.

- 원본 명령에 대한 문서 보기:

`tldr pamtopnm`
