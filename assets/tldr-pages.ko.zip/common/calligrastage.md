# calligrastage

> Calligra의 프레젠테이션 애플리케이션.
> 참고: `calligraflow`, `calligrawords`, `calligrasheets`.
> 더 많은 정보: <https://manned.org/calligrastage>.

- 프레젠테이션 애플리케이션 싱ㄹ행:

`calligrastage`

- 특정 프레젠테이션 열기:

`calligrastage {{경로/대상/프레젠테이션}}`

- 도움말 또는 버전 표시:

`calligrastage --{{help|version}}`
