# fstopgm

> Usenix FaceSaver 파일을 PGM 이미지로 변환.
> 참고: `pgmtofs`.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/fstopgm.html>.

- 지정된 Usenix FaceSaver 파일을 PGM 이미지로 변환:

`fstopgm {{경로/대상/입력.fs}} > {{경로/대상/출력.pgm}}`
