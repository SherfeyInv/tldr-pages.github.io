# sbigtopgm

> SBIG CCDOPS 파일을 PGM으로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/sbigtopgm.html>.

- SBIG CCDOPS 이미지 파일을 PGM으로 변환:

`sbigtopgm {{경로/대상/입력_파일.sbig}} > {{경로/대상/출력.pgm}}`
