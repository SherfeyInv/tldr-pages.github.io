# git fresh-branch

> 빈 로컬 브랜치를 생성.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md##git-fresh-branch>.

- 빈 로컬 브랜치 생성:

`git fresh-branch {{브랜치_이름}}`
