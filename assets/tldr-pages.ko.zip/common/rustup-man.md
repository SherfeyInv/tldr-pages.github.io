# rustup man

> `rustup`으로 관리되는 명령에 대한 매뉴얼 페이지 보기.
> 더 많은 정보: <https://rust-lang.github.io/rustup>.

- 기본 툴체인에서 주어진 명령의 매뉴얼 페이지 보기:

`rustup man {{명령}}`

- 지정된 툴체인에서 주어진 명령의 매뉴얼 페이지 보기:

`rustup man --toolchain {{명령}}`
