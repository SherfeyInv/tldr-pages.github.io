# netdiscover

> 네트워크에서 활성 호스트를 찾기 위한 네트워크 스캐너.
> 더 많은 정보: <https://github.com/netdiscover-scanner/netdiscover>.

- 네트워크 인터페이스의 IP 범위를 스캔하여 활성 호스트 검색:

`netdiscover -r {{172.16.6.0/23}} -i {{ens244}}`
