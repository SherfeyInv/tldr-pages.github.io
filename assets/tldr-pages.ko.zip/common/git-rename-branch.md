# git rename-branch

> Git 브랜치 이름 변경.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-rename-branch>.

- 현재 사용 중인 브랜치 이름 변경:

`git rename-branch {{새_브랜치_이름}}`

- 특정 브랜치 이름 변경:

`git rename-branch {{기존_브랜치_이름}} {{새_브랜치_이름}}`
