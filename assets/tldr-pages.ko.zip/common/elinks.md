# elinks

> `lynx`와 유사한 텍스트 기반 브라우저.
> 더 많은 정보: <https://github.com/rkd77/elinks>.

- ELink 시작:

`elinks`

- elinks 종료:

`<Ctrl> + C`

- 웹페이지 출력을 콘솔에 덤프하고, ANSI 제어 코드로 텍스트 색상을 지정:

`elinks -dump -dump-color-mode {{1}} {{url}}`
