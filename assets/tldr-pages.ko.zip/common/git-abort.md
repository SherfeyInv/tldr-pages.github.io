# git abort

> 진행중인 rebase, merge 혹은 cherry-pick을 중단합니다.
> `git-extras`의 일부입니다.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-abort>.

- Git rebase, merge, 혹은 cherry-pick 중단:

`git abort`
