# exfatlabel

> exFAT 파일 시스템 레이블 가져오기 또는 설정.
> 더 많은 정보: <https://manned.org/exfatlabel>.

- 현재 파일 시스템 레이블을 표시:

`exfatlabel {{/dev/sda}}`

- 파일 시스템 레이블을 설정:

`exfatlabel {{/dev/sda}} {{새로운_라벨}}`
