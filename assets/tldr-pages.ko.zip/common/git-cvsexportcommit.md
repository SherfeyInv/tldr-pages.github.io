# git cvsexportcommit

> 단일 `Git` 커밋을 CVS 체크아웃으로 내보내기.
> 더 많은 정보: <https://git-scm.com/docs/git-cvsexportcommit>.

- 특정 패치를 CVS에 병합:

`git cvsexportcommit -v -c -w {{경로/대상/프로젝트_cvs_체크아웃}} {{커밋_sha1}}`
