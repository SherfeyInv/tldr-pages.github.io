# git rename-remote

> 가져오기 및 푸시용 원격 저장소 변경.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-rename-remote>.

- 업스트림 원격 저장소를 origin으로 변경:

`git rename-remote {{upstream}} {{origin}}`
