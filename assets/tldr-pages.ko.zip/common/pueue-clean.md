# pueue clean

> 완료된 모든 작업을 목록에서 제거하고 로그를 삭제.
> 더 많은 정보: <https://github.com/Nukesor/pueue>.

- 완료된 작업 제거 및 로그 삭제:

`pueue clean`

- 성공적으로 완료된 명령만 정리:

`pueue clean --successful-only`
