# anytopnm

> 임의 유형의 이미지 파일을 일반적인 이미지 형식으로 변환합니다.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/anytopnm.html>.

- 입력 유형에 관계없이 입력 이미지를 PBM, PGM 또는 PPM 형식으로 변환:

`anytopnm {{경로/대상/입력}} > {{경로/대상/출력.pnm}}`

- 디스플레이 버전:

`anytopnm -version`
