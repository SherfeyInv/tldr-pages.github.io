# clear

> 터미널 화면을 지웁니다(clear).
> 더 많은 정보: <https://manned.org/clear>.

- 터미널 화면을 지웁니다 (Bash 쉘에서 Control-L을 누르는 것과 같은 기능입니다):

`clear`
