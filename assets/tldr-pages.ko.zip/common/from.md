# from

> 현재 사용자의 편지함에서 메일 헤더 줄을 출력.
> 더 많은 정보: <https://mailutils.org/manual/html_chapter/Programs.html#frm-and-from>.

- 메일 나열:

`from`

- 저장된 메시지 수 표시:

`from --count`

- 지정된 사서함 디렉토리의 메일을 나열:

`MAIL={{경로/대상/메일박스}} from`

- 지정된 주소에서 보낸 메일을 출력:

`from --sender={{me@example.com}}`
