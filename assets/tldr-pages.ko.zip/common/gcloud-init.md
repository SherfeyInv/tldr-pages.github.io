# gcloud init

> `gcloud`를 설정하거나 구성을 다시 초기화하는 대화형 워크플로우 시작.
> 더 많은 정보: <https://cloud.google.com/sdk/gcloud/reference/init>.

- "시작하기" 워크플로우 시작:

`gcloud init`

- 진단 없이 워크플로우 시작:

`gcloud init --skip-diagnostics`

- 콘솔을 사용하여 인증:

`gcloud init --console-only`
