# csvclean

> csvkit에 포함된 CSV 파일의 공통 문법 오류 찾기 및 정리.
> 더 많은 정보: <https://csvkit.readthedocs.io/en/latest/scripts/csvclean.html>.

- CSV 파일 정리:

`csvclean {{파일.csv}}`

- CSV 파일의 문법 오류 위치 나열:

`csvclean -n {{파일.csv}}`
