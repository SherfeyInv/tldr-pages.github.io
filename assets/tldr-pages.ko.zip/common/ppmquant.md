# ppmquant

> 이 명령은 `pnmquant` 및 `pnmremap`으로 대체되었습니다.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/ppmquant.html>.

- `pnmquant`에 대한 문서 보기:

`tldr pnmquant`

- `pnmremap`에 대한 문서 보기:

`tldr pnmremap`
