# mh_lint

> MATLAB 또는 Octave 코드에서 버그를 찾으려 시도합니다.
> 이 도구는 완벽하지도 않고 완전하지도 않음을 유의하세요.
> 더 많은 정보: <https://misshit.org>.

- 현재 디렉토리 검사:

`mh_lint`

- 특정 디렉토리를 재귀적으로 검사:

`mh_lint {{경로/대상/폴더}}`

- MATLAB 파일 검사:

`mh_lint {{경로/대상/파일.m}}`

- Octave 파일 검사:

`mh_lint --octave {{경로/대상/파일.m}}`
