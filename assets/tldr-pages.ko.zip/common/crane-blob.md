# crane blob

> 레지스트리에서 blob를 읽음.
> 더 많은 정보: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_blob.md>.

- 레지스트리에서 blob를 읽음:

`crane blob {{blob_구분자}}`

- 도움말 표시:

`crane blob {{-h|--help}}`
