# just

> `just`는 동일한 이름을 가진 여러 명령을 참조할 수 있습니다.

- 명령 실행기에 대한 문서 보기:

`tldr just.1`

- V8 JavaScript 런타임에 대한 문서 보기:

`tldr just.js`
