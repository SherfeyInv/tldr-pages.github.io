# ppmmake

> 지정한 색상과 크기의 PPM 이미지를 생성.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/ppmmake.html>.

- 지정한 색상과 크기의 PPM 이미지 생성:

`ppmmake {{색상}} {{너비}} {{높이}} > {{경로/대상/출력_파일.ppm}}`
