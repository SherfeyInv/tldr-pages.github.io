# view

> 읽기 전용 버전의 `vim`.
> 이는 `vim -R`과 동일합니다.
> 더 많은 정보: <https://www.vim.org>.

- 파일 열기:

`view {{경로/대상/파일}}`
