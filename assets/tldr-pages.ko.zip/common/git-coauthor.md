# git coauthor

> 최신 커밋에 다른 작성자를 추가. 이 명령은 Git 기록을 다시 작성하므로, 다음 푸시 시 `--force`가 필요합니다.
> `git-extras`의 일부입니다.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-coauthor>.

- 마지막 Git 커밋에 추가 작성자 삽입:

`git coauthor {{이름}} {{name@example.com}}`
