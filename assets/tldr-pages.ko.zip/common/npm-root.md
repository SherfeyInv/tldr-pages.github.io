# npm root

> `node_modules` 디렉토리 경로 표시.
> 더 많은 정보: <https://docs.npmjs.com/cli/commands/npm-root>.

- 로컬 `node_modules` 디렉토리 경로 표시:

`npm root`

- 전역 `node_modules` 디렉토리 경로 표시:

`npm root --global`
