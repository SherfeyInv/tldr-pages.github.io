# yadm-upgrade

> `yadm`을 최신 버전으로 업그레이드.
> 업그레이드 시 서브모듈을 비초기화하고 다시 초기화하려고 시도합니다.
> 더 많은 정보: <https://github.com/TheLocehiliosan/yadm/blob/master/yadm.md#commands>.

- `yadm`을 최신 버전으로 업그레이드:

`yadm upgrade`

- 변경 사항에 관계없이 강제로 업그레이드:

`yadm upgrade -f`
