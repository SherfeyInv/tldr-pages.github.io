# lzmore

> 이 명령은 `xzmore`의 별칭입니다.

- 원본 명령에 대한 문서 보기:

`tldr xzmore`
