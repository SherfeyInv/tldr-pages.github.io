# runsvchdir

> 기본적으로 `runsvdir`이 사용하는 디렉토리를 변경합니다.
> 더 많은 정보: <https://manned.org/runsvchdir.8>.

- `runsvdir` 디렉토리 변경:

`sudo runsvchdir {{경로/대상/폴더}}`
