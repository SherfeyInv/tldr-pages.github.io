# npm whoami

> npm 사용자 이름 표시.
> 더 많은 정보: <https://docs.npmjs.com/cli/whoami>.

- 현재 로그인된 사용자의 이름 표시:

`npm whoami`

- 특정 레지스트리에서 현재 사용자의 이름 표시:

`npm whoami --registry={{레지스트리_URL}}`
