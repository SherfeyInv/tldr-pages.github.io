# blockout2

> 3D 게임과 같은 테트리스.
> 더 많은 정보: <https://www.blockout.net/blockout2/>.

- 새로운 게임 시작:

`blockout2`

- 2D 평면에서 현재 조각을 탐색:

`{{Up|Down|Left|Right arrow key}}`

- 축을 중심으로 조각 회전:

`{{Q|W|E|A|S|D}}`

- 현재 조각을 하드 드롭:

`<Spacebar>`

- 게임 일시 중지/일시 중지 해제:

`p`
