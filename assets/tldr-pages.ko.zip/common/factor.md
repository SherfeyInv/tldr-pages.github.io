# factor

> 숫자의 소인수분해를 출력.
> 더 많은 정보: <https://www.gnu.org/software/coreutils/factor>.

- 숫자의 소인수분해를 표시:

`factor {{숫자}}`

- 인수가 지정되지 않은 경우, `stdin`에서 입력을 가져옴:

`echo {{숫자}} | factor`
