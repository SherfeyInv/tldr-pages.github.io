# pop

> 터미널에서 이메일을 보내는 도구.
> 더 많은 정보: <https://github.com/charmbracelet/pop>.

- 텍스트 기반 사용자 인터페이스 시작:

`pop`

- Markdown 파일의 내용을 본문으로 사용하여 이메일 보내기:

`pop < {{경로/대상/메시지.md}} --from {{me@example.com}} --to {{you@example.com}} --subject "{{오리에 대한 주제}}" --attach {{경로/대상/첨부파일}}`

- 도움말 표시:

`pop --help`
