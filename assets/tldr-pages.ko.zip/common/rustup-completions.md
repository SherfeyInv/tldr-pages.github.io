# rustup completions

> `rustup` 및 `cargo`의 셸 자동 완성 스크립트 생성.
> 더 많은 정보: <https://rust-lang.github.io/rustup>.

- 자동 완성 스크립트를 `stdout`에 출력:

`rustup completions {{bash|elvish|fish|powershell|zsh}} {{rustup|cargo}}`
