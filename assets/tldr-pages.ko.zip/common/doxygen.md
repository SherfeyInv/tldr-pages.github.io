# doxygen

> 다양한 프로그래밍 언어의 문서화 시스템.
> 더 많은 정보: <https://www.doxygen.nl>.

- 기본 템플릿 구성 파일 `Doxyfile`을 생성:

`doxygen -g`

- 템플릿 구성 파일 생성:

`doxygen -g {{경로/대상/구성_파일}}`

- 기존 구성 파일을 사용하여 문서 생성:

`doxygen {{경로/대상/구성_파일}}`
