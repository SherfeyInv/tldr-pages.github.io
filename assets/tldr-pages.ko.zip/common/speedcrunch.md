# speedcrunch

> 고정밀 과학 계산기.
> 더 많은 정보: <https://www.speedcrunch.org>.

- SpeedCrunch 시작:

`speedcrunch`

- 가장 최근 계산 결과 복사:

`<Ctrl> + R`

- 공식 책 열기:

`<Ctrl> + 1`

- 최근 계산 기록 지우기:

`<Ctrl> + N`

- 강조 표시된 부분을 괄호로 감싸기 (선택된 것이 없을 경우 모두 감싸기):

`<Ctrl> + P`

- speedcrunch 세션 불러오기:

`<Ctrl> + L`

- speedcrunch 세션 저장:

`<Ctrl> + S`

- 키패드 토글:

`<Ctrl> + K`
