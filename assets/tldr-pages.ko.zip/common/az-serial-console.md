# az serial-console

> 가상 머신의 직렬 콘솔에 연결.
> `azure-cli`의 일부 (`az`라고도 함).
> 더 많은 정보: <https://learn.microsoft.com/cli/azure/serial-console>.

- 직렬 콘솔에 연결:

`az serial-console connect --resource-group {{리소스_그룹_이름}} --name {{가상_머신_이름}}`

- 연결을 종료:

`<Ctrl>-]`
