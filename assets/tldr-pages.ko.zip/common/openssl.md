# openssl

> OpenSSL 암호화 툴킷.
> `req`와 같은 일부 하위 명령에는 자체 사용 설명서가 있습니다.
> 더 많은 정보: <https://www.openssl.org>.

- 도움말 표시:

`openssl help`

- 특정 하위 명령에 대한 도움말 표시:

`openssl help {{x509}}`

- 버전 표시:

`openssl version`
