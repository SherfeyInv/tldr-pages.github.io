# git show-merged-branches

> 현재 헤드에 병합된 모든 브랜치를 출력.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-show-merged-branches>.

- 현재 헤드에 병합된 모든 브랜치를 출력:

`git show-merged-branches`
