# git credential-store

> 디스크에 비밀번호를 저장하는 Git 도우미.
> 더 많은 정보: <https://git-scm.com/docs/git-credential-store>.

- 특정 파일에 Git 자격 증명 저장:

`git config credential.helper 'store --file={{경로/대상/파일}}'`
