# fossil init

> 프로젝트에 대한 새로운 저장소를 초기화함.
> 참고: `fossil clone`.
> 더 많은 정보: <https://fossil-scm.org/home/help/init>.

- 이름있는 파일에 새로운 저장소를 생성:

`fossil init {{경로/대상/파일이름}}`
