# cronic

> 과도한 이메일 전송을 방지하기 위해 cron 작업을 래핑하는 Bash 스크립트.
> 더 많은 정보: <https://habilis.net/cronic/>.

- 명령을 호출하고 0이 아닌 종료 코드를 반환하는 경우, 해당 출력을 표시:

`cronic {{명령어}}`
