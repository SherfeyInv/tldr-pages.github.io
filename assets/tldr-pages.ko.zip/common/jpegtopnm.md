# jpegtopnm

> JPEG/JFIF 파일을 PPM 또는 PGM 형식으로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/jpegtopnm.html>.

- JPEG/JFIF 이미지를 PPM 또는 PGM 이미지로 변환:

`jpegtopnm {{경로/대상/파일.jpg}} > {{경로/대상/파일.pnm}}`

- 버전 표시:

`jpegtopnm -version`
