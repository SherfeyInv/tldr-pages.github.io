# bastet

> 터미널에 테트리스 게임을 복제.
> 더 많은 정보: <https://fph.altervista.org/prog/bastet.html>.

- 테트리스 게임을 시작:

`bastet`

- 조각을 수평으로 탐색:

`{{Left|Right arrow key}}`

- 조각을 시계 방향 또는 시계 반대 방향으로 회전:

`{{Spacebar|Up arrow key}}`

- 조각을 부드럽게 떨어뜨림:

`<Down arrow key>`

- 조각을 세게 떨어뜨림:

`<Enter>`

- 게임 중지:

`p`

- 게임 나가기:

`<Ctrl> + C`
