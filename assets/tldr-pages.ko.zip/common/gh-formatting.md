# gh formatting

> gh GitHub CLI 명령어에서 내보낸 JSON 데이터에 대한 포맷 옵션.
> 더 많은 정보: <https://cli.github.com/manual/gh_help_formatting>.

- `jq`를 사용하여 `gh`의 JSON 출력 포맷에 대한 도움말 표시:

`gh formatting`
