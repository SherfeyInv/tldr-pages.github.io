# yard

> Ruby를 위한 문서화 도구.
> 더 많은 정보: <https://yardoc.org/>.

- 문서 생성:

`yard`

- 문서를 생성하고 하나의 파일로 저장:

`yard --one-file`

- 문서화되지 않은 모든 객체 나열:

`yard stats --list-undoc`
