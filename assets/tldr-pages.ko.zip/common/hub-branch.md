# hub branch

> 브랜치 생성 및 현재 브랜치 표시.
> 참고: `git branch`.

- 현재 활성화된 브랜치의 이름을 표시:

`hub branch`

- 새로운 브랜치 생성:

`hub branch {{브랜치_이름}}`
