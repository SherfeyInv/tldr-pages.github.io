# zotero

> 참고 문헌 관리 도구.
> 더 많은 정보: <https://www.zotero.org/support>.

- GUI로 실행:

`zotero`

- 헤드리스 모드로 실행:

`zotero --headless`

- 특정 프로필로 실행:

`zotero -P {{프로필}}`

- 마이그레이션 도우미 실행:

`zotero --migration`
