# sdkmanager

> Android SDK의 패키지 설치 도구.
> 더 많은 정보: <https://developer.android.com/tools/sdkmanager>.

- 사용 가능한 패키지 나열:

`sdkmanager --list`

- 패키지 설치:

`sdkmanager {{패키지}}`

- 설치된 모든 패키지 업데이트:

`sdkmanager --update`

- 패키지 제거:

`sdkmanager --uninstall {{패키지}}`
