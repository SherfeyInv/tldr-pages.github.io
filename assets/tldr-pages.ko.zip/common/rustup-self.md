# rustup self

> `rustup` 설치를 수정합니다.
> 더 많은 정보: <https://rust-lang.github.io/rustup>.

- `rustup` 업데이트:

`rustup self update`

- `rustup` 제거:

`rustup self uninstall`
