# bpytop

> CPU, 메모리, 디스크, 네트워크 및 프로세스에 대한 정보를 표시하는 리소스 모니터.
> `bashtop`의 Python 버전.
> 더 많은 정보: <https://github.com/aristocratos/bpytop>.

- `bpytop` 시작:

`bpytop`

- 메모리와 네트워킹 박스 없이 최소 모드에서 시작:

`bpytop -m`

- 최소 모드 전환:

`m`

- 실행 중인 프로그램이나 프로세스 검색:

`f`

- 설정 변경:

`M`

- 버전 표시:

`bpytop -v`
