# dive

> 도커 이미지, 레이어 컨텐츠, 그리고 축소 방법 탐색을 위한 도구.
> 더 많은 정보: <https://github.com/wagoodman/dive>.

- 도커 이미지 분석하기:

`dive {{이미지_태그}}`

- 이미지 구축과 분석 시작하기:

`dive build -t {{몇_가지_태그}}`
