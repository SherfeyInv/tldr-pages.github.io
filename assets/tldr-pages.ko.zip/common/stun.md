# stun

> 클래식 STUN 클라이언트.
> 더 많은 정보: <https://manned.org/stun.1>.

- STUN 요청 생성:

`stun {{STUN 호스트 이름}}`

- STUN 요청을 하고 소스 포트를 지정:

`stun {{STUN 호스트 이름}} -p {{4302}}`
