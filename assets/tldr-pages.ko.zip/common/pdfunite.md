# pdfunite

> PDF 병합 도구.
> 더 많은 정보: <https://github.com/mtgrosser/pdfunite>.

- 2개의 PDF를 하나의 PDF로 병합:

`pdfunite {{경로/대상/파일A.pdf}} {{경로/대상/파일B.pdf}} {{경로/대상/병합된_출력.pdf}}`

- 폴더 내의 PDF 파일을 하나의 PDF로 병합:

`pdfunite {{경로/대상/폴더/*.pdf}} {{경로/대상/병합된_출력.pdf}}`
