# git extras

> Git 확장 도구 모음.
> 더 많은 정보: <https://github.com/tj/git-extras>.

- `git-extras` 명령어 설치 또는 업그레이드:

`git extras update`

- 도움말 표시:

`git extras --help`

- 버전 표시:

`git extras --version`
