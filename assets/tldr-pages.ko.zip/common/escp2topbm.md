# escp2topbm

> PBM를 ESC/P2 프린터 파일로 변환.
> 참고: `pbmtoescp2`.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/escp2topbm.html>.

- ESC/P2 프린터 파일을 PBM 이미지로 변환:

`escp2topbm {{경로/대상/이미지.escp2}} > {{경로/대상/출력파일.pbm}}`
