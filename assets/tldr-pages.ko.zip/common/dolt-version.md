# dolt version

> 현재 dolt CLI 버전을 표시.
> 더 많은 정보: <https://docs.dolthub.com/cli-reference/cli#dolt-version>.

- 버전 정보 표시:

`dolt version`
