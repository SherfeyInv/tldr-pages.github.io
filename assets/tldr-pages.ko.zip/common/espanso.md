# espanso

> Rust로 작성된 크로스 플랫폼 텍스트 확장기.
> 더 많은 정보: <https://espanso.org>.

- 상태 확인:

`espanso status`

- 구성 파일 편집:

`espanso edit config`

- 허브 스토어 (<https://hub.espanso.org/>)에서 패키지를 설치:

`espanso install {{패키지}}`

- 다시 시작 (패키지 설치 후 필요, 실패 시 유용함):

`espanso restart`
