# calligrawords

> Calligra의 워드 프로세서 응용 프로그램.
> 참고: `calligraflow`, `calligrastage`, `calligrasheets`.
> 더 많은 정보: <https://manned.org/calligrawords>.

- 워드 프로세서 애플리케이션을 실행:

`calligrawords`

- 특정 문서 열기:

`calligrawords {{경로/대상/문서}}`

- 도움말 또는 버전 표시:

`calligrawords --{{help|version}}`
