# gh environment

> GitHub CLI 명령어에 사용되는 환경 변수에 대한 도움말 표시.
> 더 많은 정보: <https://cli.github.com/manual/gh_help_environment>.

- `gh`와 함께 사용할 수 있는 환경 변수에 대한 도움말 표시:

`gh environment`
