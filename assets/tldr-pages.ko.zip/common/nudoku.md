# nudoku

> 터미널에서 즐기는 스도쿠 게임.
> 더 많은 정보: <https://jubalh.github.io/nudoku/>.

- 스도쿠 게임 시작:

`nudoku`

- 게임 난이도 선택:

`nudoku -d {{easy|normal|hard}}`

- 보드 탐색:

`{{h|j|k|l}} OR {{왼쪽|아래|위|오른쪽 화살표 키}}`

- 숫자 삭제:

`{{Backspace|x}}`

- 힌트 얻기:

`H`

- 전체 정답 보기:

`S`

- 새로운 퍼즐 생성:

`N`

- 게임 종료:

`Q`
