# ppmtoneo

> PPM 이미지를 Atari Neochrome 파일로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/ppmtoneo.html>.

- PPM 이미지를 NEO 파일로 변환:

`ppmtoneo {{경로/대상/파일.ppm}} > {{경로/대상/파일.neo}}`
