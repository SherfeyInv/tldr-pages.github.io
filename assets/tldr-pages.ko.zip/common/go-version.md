# go version

> Go 버전을 표시.
> 더 많은 정보: <https://golang.org/cmd/go/#hdr-Print_Go_version>.

- 버전 표시:

`go version`

- 특정 실행 파일을 빌드하는 데 사용된 Go 버전 표시:

`go version {{경로/대상/실행파일}}`
