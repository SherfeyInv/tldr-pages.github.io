# sc_warts2json

> `warts` 파일에 포함된 정보를 JSON으로 덤프.
> 더 많은 정보: <https://www.caida.org/catalog/software/scamper/>.

- `warts` 파일을 JSON으로 변환하고 결과 출력:

`sc_warts2json {{경로/대상/파일1.warts 경로/대상/파일2.warts ...}}`
