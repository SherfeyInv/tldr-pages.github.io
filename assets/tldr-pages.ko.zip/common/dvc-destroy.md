# dvc destroy

> DVC 프로젝트에서 모든 DVC 파일과 디렉터리를 제거.
> 더 많은 정보: <https://dvc.org/doc/command-reference/destroy>.

- 현재 프로젝트 삭제:

`dvc destroy`

- 현재 프로젝트 강제 삭제:

`dvc destroy --force`
