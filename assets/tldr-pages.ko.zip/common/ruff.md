# ruff

> 매우 빠른 Python 린터 및 코드 포매터로, Rust로 작성되었습니다.
> 더 많은 정보: <https://docs.astral.sh/ruff/tutorial>.

- Ruff 린터에 대한 문서 보기:

`tldr ruff check`

- Ruff 코드 포매터에 대한 문서 보기:

`tldr ruff format`
