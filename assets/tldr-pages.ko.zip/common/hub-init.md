# hub init

> 새로운 로컬 Git 저장소를 초기화.
> 더 많은 정보: <https://hub.github.com/hub-init.1.html>.

- 새로운 로컬 저장소를 초기화:

`hub init`
