# git rename-tag

> Git 태그 이름 변경.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-rename-tag>.

- 기존 Git 태그를 로컬 및 원격에서 이름 변경:

`git rename-tag {{old_tag_name}} {{new_tag_name}}`
