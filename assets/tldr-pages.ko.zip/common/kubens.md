# kubens

> Kubernetes 네임스페이스 간 전환 유틸리티.
> 더 많은 정보: <https://github.com/ahmetb/kubectx>.

- 네임스페이스 나열:

`kubens`

- 활성 네임스페이스 변경:

`kubens {{이름}}`

- 이전 네임스페이스로 전환:

`kubens -`
