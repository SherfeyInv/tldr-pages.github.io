# git pull-request

> GitHub 프로젝트에 대한 풀 리퀘스트 생성.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-pull-request>.

- GitHub 프로젝트에 대한 풀 리퀘스트 생성:

`git pull-request {{대상_브랜치}}`
