# aws codecommit

> 개인 Git 저장소를 호스팅하는 관리형 소스 제어 서비스.
> 더 많은 정보: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- 도움말 표시:

`aws codecommit help`

- 특정 명령어에 대한 도움말 표시:

`aws codecommit {{명령어}} help`
