# idevicesyslog

> 연결된 iOS 장치의 syslog 메시지를 릴레이.
> 더 많은 정보: <https://manned.org/idevicesyslog>.

- 연결된 장치의 syslog 메시지 릴레이:

`idevicesyslog`

- 커널 메시지를 억제하고 다른 모든 내용을 출력:

`idevicesyslog --no-kernel`
