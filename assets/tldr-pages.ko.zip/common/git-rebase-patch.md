# git rebase-patch

> 패치가 적용되는 커밋을 찾고 리베이스를 수행.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-rebase-patch>.

- 패치가 적용되는 커밋을 찾고 리베이스 수행:

`git rebase-patch {{패치_파일}}`
