# git brv

> 마지막 커밋 날짜별로 정렬된 브랜치 목록을 출력.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-brv>.

- 날짜, 최신 커밋 해시 및 메시지를 표시하여 각 브랜치 나열:

`git brv`
