# go run

> Go 코드를 컴파일하고 바이너리를 저장하지 않고 실행.
> 더 많은 정보: <https://pkg.go.dev/cmd/go#hdr-Compile_and_run_Go_program>.

- Go 파일 실행:

`go run {{경로/대상/파일.go}}`

- 메인 Go 패키지 실행:

`go run {{경로/대상/패키지}}`
