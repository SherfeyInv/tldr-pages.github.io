# pgmbentley

> PGM 이미지에 벤틀리 효과 적용.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pgmbentley.html>.

- PGM 이미지에 벤틀리 효과 적용:

`pgmbentley {{경로/대상/입력_파일.pgm}} > {{경로/대상/출력_파일.pgm}}`
