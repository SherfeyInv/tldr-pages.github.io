# gcloud-version

> Google Cloud CLI 구성 요소의 버전 정보를 출력.
> 더 많은 정보: <https://cloud.google.com/sdk/gcloud/reference/version>.

- 설치된 모든 구성 요소의 버전 정보와 사용 가능한 업데이트 표시:

`gcloud version`

- 도움말 표시:

`gcloud version --help`
