# azure-cli

> 이 명령은 `az`의 별칭.
> 더 많은 정보: <https://learn.microsoft.com/cli/azure>.

- 원래 명령에 대한 문서를 보기:

`tldr az`
