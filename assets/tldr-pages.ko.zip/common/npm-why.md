# npm-why

> npm 패키지가 설치된 이유를 식별합니다.
> 더 많은 정보: <https://github.com/amio/npm-why>.

- npm 패키지가 설치된 이유 표시:

`npm-why {{패키지}}`
