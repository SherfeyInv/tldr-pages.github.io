# ppmtopgm

> PPM 이미지를 PGM 이미지로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/ppmtopgm.html>.

- PPM 이미지를 PGM 이미지로 변환:

`ppmtopgm {{경로/대상/파일.ppm}} > {{경로/대상/파일.pgm}}`

- 버전 표시:

`ppmtopgm -version`
