# hub ci-status

> GitHub 검사 상태를 표시.
> 더 많은 정보: <https://hub.github.com/hub-ci-status.1.html>.

- 이 브랜치의 CI 상태를 확인:

`hub ci-status --verbose`

- 커밋에 대한 GitHub 검사 상태 표시:

`hub ci-status --verbose {{커밋_SHA}}`
