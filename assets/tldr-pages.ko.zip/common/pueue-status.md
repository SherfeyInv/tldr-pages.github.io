# pueue status

> 모든 작업의 현재 상태 표시.
> 더 많은 정보: <https://github.com/Nukesor/pueue>.

- 모든 작업의 상태 표시:

`pueue status`

- 특정 그룹의 상태 표시:

`pueue status --group {{그룹_이름}}`
