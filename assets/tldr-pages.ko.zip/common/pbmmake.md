# pbmmake

> 빈 비트맵 생성.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/pbmmake.html>.

- 지정된 크기의 빈 비트맵 생성:

`pbmmake {{너비}} {{높이}} > {{경로/대상/출력_파일.pbm}}`

- 생성된 비트맵의 색상 지정:

`pbmmake -{{white|black|grey}} {{너비}} {{높이}} > {{경로/대상/출력_파일.pbm}}`
