# git touch

> 새 파일을 생성하고 색인에 추가.
> `git-extras`의 일부.
> 더 많은 정보: <https://github.com/tj/git-extras/blob/master/Commands.md#git-touch>.

- 새 파일을 생성하고 색인에 추가:

`git touch {{경로/대상/파일1 경로/대상/파일2 ...}}`
