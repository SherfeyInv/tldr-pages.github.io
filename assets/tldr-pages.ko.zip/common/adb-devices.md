# adb devices

> 연결된 Android 장치 나열.
> 더 많은 정보: <https://manned.org/adb>.

- 장치 목록 나열:

`adb devices`

- 장치 및 해당 시스템 정보 나열:

`adb devices -l`
