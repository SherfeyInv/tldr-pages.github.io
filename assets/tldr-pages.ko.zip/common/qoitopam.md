# qoitopam

> QOI 이미지(Quite OK Image format)를 Netpbm으로 변환.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/qoitopam.html>.

- QOI 이미지를 Netpbm으로 변환:

`qoitopam {{경로/대상/이미지.qoi}} > {{경로/대상/출력.pnm}}`
