# systemd-resolve

> 도메인 이름, IPv4 및 IPv6 주소, DNS 리소스 레코드 및 서비스를 해석.
> 참고: 이 도구는 `systemd`의 새로운 버전에서 `resolvectl`로 이름이 변경되었습니다.
> 더 많은 정보: <https://manned.org/systemd-resolve>.

- `resolvectl`에 대한 문서 보기:

`tldr resolvectl`
