# qm mtunnel

> `qmigrate`에서 사용.
> 수동으로 호출해서는 안 됨.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- VM에서 다른 호스트로 데이터 마이그레이션 중에 `qmigrate`에서 사용되는 명령:

`qm mtunnel`
