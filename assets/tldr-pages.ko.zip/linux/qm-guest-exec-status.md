# qm guest exec-status

> QEMU/KVM 가상 머신 관리자에서 게스트 에이전트에 의해 시작된 PID의 상태를 출력.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 PID의 상태 출력:

`qm guest exec-status {{가상_머신_ID}} {{pid}}`
