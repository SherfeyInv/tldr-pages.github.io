# systemd-confext

> 이 명령은 `systemd-sysext`의 별칭입니다.
> `/usr` 및 `/opt`에서 작동하는 `systemd-sysext`와 같은 원리를 따르지만, `confext`는 오직 `/etc`만 확장합니다.
> 더 많은 정보: <https://www.freedesktop.org/software/systemd/man/latest/systemd-sysext.html>.

- 원래 명령의 문서 보기:

`tldr systemd-sysext`
