# qm help

> 명령어에 대한 도움말 표시.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 명령에 대한 도움말 표시:

`qm help {{명령어}}`

- 자세한 정보와 함께 특정 명령에 대한 도움말 표시:

`qm help {{명령어}} --verbose {{true|false}}`
