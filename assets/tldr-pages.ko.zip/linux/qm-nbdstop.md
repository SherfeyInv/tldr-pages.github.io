# qm nbdstop

> 내장 nbd 서버 중지.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 내장 nbd 서버 중지:

`qm nbdstop {{가상_머신_ID}}`
