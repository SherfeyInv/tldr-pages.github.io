# btrfs version

> btrfs-progs 버전 표시.
> 더 많은 정보: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- 도움말 표시:

`btrfs version --help`

- btrfs-progs 버전 표시:

`btrfs version`
