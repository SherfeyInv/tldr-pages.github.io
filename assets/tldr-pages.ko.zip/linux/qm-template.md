# qm template

> Proxmox VM 템플릿 생성.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신으로부터 템플릿 생성:

`qm template {{가상_머신_ID}}`
