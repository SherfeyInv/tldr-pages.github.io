# qm vncproxy

> 가상 머신의 VNC (Virtual Network Computing) 트래픽을 `stdin` 또는 `stdout`으로 프록시.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신을 프록시:

`qm vncproxy {{가상_머신_ID}}`
