# qm guest cmd

> QEMU 게스트 에이전트 명령 실행.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 QEMU 게스트 에이전트 명령 실행:

`qm guest cmd {{가상_머신_ID}} {{fsfreeze-freeze|fsfreeze-status|fsfreeze-thaw|fstrim|get-fsinfo|...}}`
