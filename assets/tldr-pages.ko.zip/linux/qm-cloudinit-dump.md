# qm cloudinit dump

> cloudinit 구성 파일 생성.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 구성 유형에 대한 cloudinit 파일 생성:

`qm cloudinit dump {{가상_머신_ID}} {{meta|network|user}}`
