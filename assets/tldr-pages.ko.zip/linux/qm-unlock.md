# qm unlock

> QEMU/KVM 가상 머신 관리자에서 가상 머신 잠금 해제.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신 잠금 해제:

`qm unlock {{가상_머신_ID}}`
