# qm listsnapshot

> 가상 머신의 스냅샷 나열.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신의 모든 스냅샷 나열:

`qm listsnapshot {{가상_머신_ID}}`
