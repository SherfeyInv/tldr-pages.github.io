# qm pending

> 현재 및 보류 중인 값을 포함한 가상 머신 구성을 가져옵니다.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신의 가상 머신 구성 가져오기:

`qm pending {{가상_머신_ID}}`
