# qm list

> 모든 가상 머신 나열.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 모든 가상 머신 나열:

`qm list`

- 현재 실행 중인 가상 머신의 전체 상태와 함께 모든 가상 머신 나열:

`qm list --full 1`
