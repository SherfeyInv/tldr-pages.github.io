# umount

> 올바른 명령은 `umount` (u-mount)입니다.
> 더 많은 정보: <https://manned.org/umount.8>.

- 올바른 명령에 대한 문서 보기:

`tldr umount`
