# systemctl reboot

> 시스템 재부팅.
> 더 많은 정보: <https://www.freedesktop.org/software/systemd/man/systemctl.html#reboot>.

- 시스템 재부팅:

`systemctl reboot`

- BIOS/UEFI 메뉴로 재부팅:

`systemctl reboot --firmware-setup`
