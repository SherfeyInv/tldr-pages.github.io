# qm monitor

> QEMU 모니터 인터페이스에 진입.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 가상 머신의 QEMU 모니터 인터페이스에 진입:

`qm monitor {{가상_머신_ID}}`
