# qm rollback

> VM 상태를 지정된 스냅샷으로 롤백.
> 더 많은 정보: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- 특정 VM의 상태를 지정된 스냅샷으로 롤백:

`qm rollback {{가상_머신_ID}} {{snap_name}}`
