# qm import disk

> 이 명령은 `qm disk import`의 별칭입니다.

- 원본 명령에 대한 문서 보기:

`tldr qm disk import`
