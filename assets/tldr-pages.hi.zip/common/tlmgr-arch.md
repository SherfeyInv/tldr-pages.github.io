# tlmgr arch

> यह आदेश `tlmgr platform` का उपनाम है।
> अधिक जानकारी: <https://www.tug.org/texlive/tlmgr.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr tlmgr platform`
