# bundler

> यह आदेश `bundle` का उपनाम है।
> अधिक जानकारी: <https://bundler.io/man/bundle.1.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr bundle`
