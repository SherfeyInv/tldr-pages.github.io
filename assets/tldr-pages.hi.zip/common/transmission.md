# transmission

> यह आदेश `transmission-daemon` का उपनाम है।
> अधिक जानकारी: <https://transmissionbt.com/>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr transmission-daemon`
