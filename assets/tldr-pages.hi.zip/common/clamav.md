# ClamAV

> यह आदेश `clamdscan` का उपनाम है।
> अधिक जानकारी: <https://www.clamav.net>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr clamdscan`
