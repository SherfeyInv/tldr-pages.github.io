# fossil forget

> यह आदेश `fossil rm` का उपनाम है।
> अधिक जानकारी: <https://fossil-scm.org/home/help/forget>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr fossil rm`
