# gh cs

> यह आदेश `gh codespace`.का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gh codespace`
