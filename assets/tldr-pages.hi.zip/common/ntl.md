# ntl

> यह आदेश `netlify` का उपनाम है।
> अधिक जानकारी: <https://cli.netlify.com>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr netlify`
