# unlzma

> यह आदेश `xz` का उपनाम है।
> अधिक जानकारी: <https://manned.org/unlzma>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr xz`
