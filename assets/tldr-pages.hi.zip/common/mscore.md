# mscore

> यह आदेश `musescore` का उपनाम है।
> अधिक जानकारी: <https://musescore.org/handbook/command-line-options>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr musescore`
