# fossil new

> यह आदेश  `fossil init`.का उपनाम है।
> अधिक जानकारी: <https://fossil-scm.org/home/help/new>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr fossil init`
