# pio init

> यह आदेश `pio project` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pio project`
