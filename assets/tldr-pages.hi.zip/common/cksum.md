# cksum

> किसी फ़ाइल की CRC चेकसम और बाइट गिनती की गणना करें।
> नोट: पुराने UNIX सिस्टम पर CRC कार्यान्वयन भिन्न हो सकता है।
> अधिक जानकारी: <https://www.gnu.org/software/coreutils/manual/html_node/cksum-invocation.html>।

- 32-बिट चेकसम, बाइट्स में आकार और फ़ाइल नाम प्रदर्शित करें:

`cksum {{फ़ाइल/का/पथ}}`
