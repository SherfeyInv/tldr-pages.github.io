# backlight_control

> प्रतिशत मानों का उपयोग करके लिनक्स मशीन की बैकलाइट को नियंत्रित करें।
> अधिक जानकारी: <https://github.com/Hendrikto/backlight_control>।

- एक विशिष्ट प्रतिशत गणना द्वारा बैकलाइट बढ़ाएँ/घटाएँ:

`backlight_control {{+|-}}{{5}}`

- बैकलाइट की ताकत को एक विशिष्ट प्रतिशत गणना पर सेट करें:

`backlight_control {{90}}`

- सहायता प्रिंट करें:

`backlight_control`
