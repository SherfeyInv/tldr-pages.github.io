# megadl

> यह आदेश `megatools-dl` का उपनाम है।
> अधिक जानकारी: <https://megatools.megous.com/man/megatools-dl.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr megatools-dl`
