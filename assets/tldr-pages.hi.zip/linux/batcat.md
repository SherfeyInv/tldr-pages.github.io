# batcat

> यह आदेश `bat` का उपनाम है।
> अधिक जानकारी: <https://github.com/sharkdp/bat>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr bat`
