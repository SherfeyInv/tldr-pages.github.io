# caffeine

> फ़ुल-स्क्रीन मोड में डेस्कटॉप निष्क्रियता को रोकें।
> अधिक जानकारी: <https://manned.org/caffeine>।

- कैफीन सर्वर प्रारंभ करें:

`caffeine`

- सहायता प्रदर्शित करें:

`caffeine --help`

- संस्करण प्रदर्शित करें:

`caffeine --version`
