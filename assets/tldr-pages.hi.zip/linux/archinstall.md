# archinstall

> एक सहायक लाइब्रेरी जो आर्क लिनक्स (Arch Linux) की स्थापना को स्वचालित करती है।
> अधिक जानकारी: <https://archinstall.readthedocs.io>।

- इंटरैक्टिव इंस्टॉलर प्रारंभ करें:

`archinstall`

- पूर्व निर्धारित इंस्टॉलर प्रारंभ करें:

`archinstall {{minimal|unattended}}`
