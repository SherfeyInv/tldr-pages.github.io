# ip route list

> यह आदेश `ip route show`.का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr ip route show`
