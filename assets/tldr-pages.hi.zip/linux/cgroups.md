# cgroups

> यह आदेश `cgclassify` का उपनाम है।
> अधिक जानकारी: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr cgclassify`
