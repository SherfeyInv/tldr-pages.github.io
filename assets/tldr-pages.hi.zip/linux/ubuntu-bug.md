# ubuntu-bug

> यह आदेश `apport-bug` का उपनाम है।
> अधिक जानकारी: <https://manned.org/ubuntu-bug>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr apport-bug`
