# gbase32

> यह आदेश `-p linux base32` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux base32`
