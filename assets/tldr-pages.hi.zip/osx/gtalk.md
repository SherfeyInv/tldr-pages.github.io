# gtalk

> यह आदेश `-p linux talk` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux talk`
