# gunlink

> यह आदेश `-p linux unlink` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux unlink`
