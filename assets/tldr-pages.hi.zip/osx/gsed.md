# gsed

> यह आदेश `-p linux sed` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux sed`
