# dalvikvm

> एंड्रॉइड जावा वर्चुअल मशीन।
> अधिक जानकारी: <https://source.android.com/docs/core/runtime>।

- एक विशिष्ट जावा प्रोग्राम प्रारंभ करें:

`dalvikvm -classpath {{फ़ाइल.jar/का/पथ}} {{क्लासनाम}}`
