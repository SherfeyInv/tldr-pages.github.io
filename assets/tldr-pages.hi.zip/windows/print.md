# print

> एक टेक्स्ट फ़ाइल को प्रिंटर पर प्रिंट करें।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/print>।

- डिफ़ॉल्ट प्रिंटर पर एक टेक्स्ट फ़ाइल प्रिंट करें:

`print {{फाइल\का\पथ}}`

- एक विशेष प्रिंटर पर एक टेक्स्ट फ़ाइल प्रिंट करें:

`print /d:{{प्रिंटर}} {{फाइल\का\पथ}}`
