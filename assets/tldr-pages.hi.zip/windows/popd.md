# popd

> `pushd` कमांड द्वारा संग्रहित निर्देशिका में वर्तमान निर्देशिका को बदलता है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/popd>।

- स्टैक के शीर्ष पर स्थित निर्देशिका पर स्विच करें:

`popd`
