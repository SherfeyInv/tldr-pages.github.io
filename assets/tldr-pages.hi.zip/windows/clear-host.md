# Clear-Host

> स्क्रीन को साफ करता है।
> नोट: इस कमांड का उपयोग केवल पॉवरशेल के माध्यम से किया जा सकता है।
> अधिक जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/clear-host>।

- स्क्रीन साफ करें:

`cls`
