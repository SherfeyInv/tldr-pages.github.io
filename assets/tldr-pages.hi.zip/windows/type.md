# type

> एक फाइल की सामग्रियों को प्रदर्शित कीजिए।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/type>।

- किसी विशिष्ट फ़ाइल की सामग्री प्रदर्शित करें:

`type {{फ़ाइल\का\पथ}}`
