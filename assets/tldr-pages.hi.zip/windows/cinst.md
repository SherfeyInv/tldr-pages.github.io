# cinst

> यह आदेश `choco install` का उपनाम है।
> अधिक जानकारी: <https://docs.chocolatey.org/en-us/choco/commands/install>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr choco install`
