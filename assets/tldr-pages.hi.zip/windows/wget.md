# wget

> यह आदेश `wget -p common` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr wget -p common`
