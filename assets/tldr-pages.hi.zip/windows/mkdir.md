# mkdir

> एक निर्देशिका बनाता है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>।

- एक निर्देशिका बनाएं:

`mkdir {{निर्देशिका\का\पथ}}`

- पुनरावर्ती रूप से एक नेस्टेड निर्देशिका ट्री बनाएं:

`mkdir {{उपनिर्देशिका\का\पथ}}`
