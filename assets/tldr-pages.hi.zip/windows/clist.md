# clist

> यह आदेश `choco list` का उपनाम है।
> अधिक जानकारी: <https://docs.chocolatey.org/en-us/choco/commands/list>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr choco list`
