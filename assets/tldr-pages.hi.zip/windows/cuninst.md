# cuninst

> यह आदेश `choco uninstall` का उपनाम है।
> अधिक जानकारी: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr choco uninstall`
