# cls

> स्क्रीन को साफ करता है।
> PowerShell में, यह कमांड `Clear-Host` का उपनाम है। यह दस्तावेज़ Command Prompt (`cmd`) संस्करण के `cls` पर आधारित है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>।

- समकक्ष PowerShell कमांड का दस्तावेज़ देखें:

`tldr clear-host`

- स्क्रीन को साफ करें:

`cls`
