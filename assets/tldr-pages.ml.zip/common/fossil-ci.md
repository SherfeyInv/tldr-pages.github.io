# fossil ci

> ഈ കമാൻഡ് `fossil commit`.എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr fossil commit`
