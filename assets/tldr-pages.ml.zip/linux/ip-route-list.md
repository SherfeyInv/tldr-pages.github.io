# ip route list

> ഈ കമാൻഡ്  `ip route show`.എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr ip-route-show`
