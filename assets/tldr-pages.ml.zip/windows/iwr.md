# iwr

> ഈ കമാൻഡ് `invoke-webrequest` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr invoke-webrequest`
