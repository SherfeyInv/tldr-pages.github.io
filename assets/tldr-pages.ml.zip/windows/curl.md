# curl

> ഈ കമാൻഡ് `curl -p common` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr curl -p common`
