# zbarimg

> Skanna och avkoda streckkoder från bildfil(er).
> Mer information: <https://zbar.sourceforge.net>.

- Processa en bildfil:

`zbarimg {{bild_fil}}`
