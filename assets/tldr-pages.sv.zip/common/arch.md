# arch

> Visa namnet på systemarkitekturen.
> Se även `uname`.
> Mer information: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Visa systemarkitekturen:

`arch`
