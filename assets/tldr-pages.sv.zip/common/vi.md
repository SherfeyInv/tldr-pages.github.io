# vi

> Det här kommandot är ett alias för `vim`.

- Se dokumentationen för orginalkommandot:

`tldr vim`
