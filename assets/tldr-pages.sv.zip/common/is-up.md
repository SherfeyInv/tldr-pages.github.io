# is-up

> Kontrollera om en webbplats är uppe eller nere.
> Mer information: <https://github.com/sindresorhus/is-up-cli>.

- Kontrollera statusen för den angivna webbplatsen:

`is-up {{exempel.com}}`
