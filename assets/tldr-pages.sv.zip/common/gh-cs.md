# gh cs

> Det här kommandot är ett alias för `gh codespace`.
> Mer information: <https://cli.github.com/manual/gh_codespace>.

- Se dokumentationen för orginalkommandot:

`tldr gh codespace`
