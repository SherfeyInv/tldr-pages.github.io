# gh cs

> Det här kommandot är ett alias för `gh codespace`.

- Se dokumentationen för orginalkommandot:

`tldr gh codespace`
