# tldrl

> Det här kommandot är ett alias för `tldr-lint`.

- Se dokumentationen för orginalkommandot:

`tldr tldr-lint`
