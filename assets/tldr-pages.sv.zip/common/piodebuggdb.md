# piodebuggdb

> Det här kommandot är ett alias för `pio debug`.

- Se dokumentationen för orginalkommandot:

`tldr pio debug`
