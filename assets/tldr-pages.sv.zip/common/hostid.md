# hostid

> Skriver ut den numeriska identifieraren för den aktuella värden (inte nödvändigtvis IP-adressen).
> Mer information: <https://www.gnu.org/software/coreutils/hostid>.

- Visa den numeriska identifieraren för den aktuella värden i hexadecimal:

`hostid`
