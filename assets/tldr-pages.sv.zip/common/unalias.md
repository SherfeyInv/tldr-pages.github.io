# unalias

> Ta bort alias.
> Mer information: <https://manned.org/unalias>.

- Ta bort en alias:

`unalias {{alias_namn}}`

- Ta bort alla alias:

`unalias -a`
