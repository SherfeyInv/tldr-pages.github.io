# nohup

> Tillåter en process att leva när terminalen dödas.
> Mer information: <https://www.gnu.org/software/coreutils/nohup>.

- Kör process som kan leva bortom terminalen:

`nohup {{kommandoalternativ}}`
