# tlmgr arch

> Det här kommandot är ett alias för `tlmgr platform`.

- Se dokumentationen för orginalkommandot:

`tldr tlmgr platform`
