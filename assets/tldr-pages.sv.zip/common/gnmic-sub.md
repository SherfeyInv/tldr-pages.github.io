# gnmic sub

> Det här kommandot är ett alias för `gnmic subscribe`.

- Se dokumentationen för orginalkommandot:

`tldr gnmic subscribe`
