# yarn-why

> Identifierar varför ett Yarn paket har installerats.
> Mer information: <https://github.com/amio/yarn-why>.

- Visa varför ett Yarn paket är installerat:

`yarn-why {{paket_namn}}`
