# fossil new

> Det här kommandot är ett alias för `fossil init`.

- Se dokumentationen för orginalkommandot:

`tldr fossil init`
