# iwr

> Det här kommandot är ett alias för `invoke-webrequest`.

- Se dokumentationen för orginalkommandot:

`tldr invoke-webrequest`
