# cuninst

> Det här kommandot är ett alias för `choco uninstall`.
> Mer information: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Se dokumentationen för orginalkommandot:

`tldr choco uninstall`
