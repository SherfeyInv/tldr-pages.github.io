# pwsh where

> Det här kommandot är ett alias för `Where-Object`.

- Se dokumentationen för orginalkommandot:

`tldr Where-Object`
