# clist

> Det här kommandot är ett alias för `choco list`.
> Mer information: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Se dokumentationen för orginalkommandot:

`tldr choco list`
