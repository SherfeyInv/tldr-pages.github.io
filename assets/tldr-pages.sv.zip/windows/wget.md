# wget

> Det här kommandot är ett alias för `wget -p common`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Se dokumentationen för orginalkommandot:

`tldr wget -p common`
