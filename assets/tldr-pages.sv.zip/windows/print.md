# print

> Skriv ut en textfil till en skrivare.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/print>.

- Skriv ut en textfil till standardskrivaren:

`print {{sökväg/till/filen}}`

- Skriv ut en textfil till en specifik skrivare:

`print /d:{{skrivare}} {{sökväg/till/filen}}`
