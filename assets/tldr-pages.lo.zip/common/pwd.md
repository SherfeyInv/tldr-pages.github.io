# pwd

> ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.gnu.org/software/coreutils/pwd>.

- ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່:

`pwd`

- ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່ໂດຍບໍ່ລວມ symlinks:

`pwd -P`
