# fossil ci

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ  `fossil commit`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://fossil-scm.org/home/help/commit>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr fossil commit`
