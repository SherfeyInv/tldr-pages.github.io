# fossil new

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ  `fossil init`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://fossil-scm.org/home/help/new>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr fossil-init`
