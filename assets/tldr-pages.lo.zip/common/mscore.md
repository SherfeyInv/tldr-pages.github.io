# mscore

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `musescore`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://musescore.org/handbook/command-line-options>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr musescore`
