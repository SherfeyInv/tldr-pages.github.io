# tldrl

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `tldr-lint`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/tldr-pages/tldr-lint>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr tldr-lint`
