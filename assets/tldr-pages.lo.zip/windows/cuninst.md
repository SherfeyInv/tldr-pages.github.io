# cuninst

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `choco uninstall`.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr choco uninstall`
