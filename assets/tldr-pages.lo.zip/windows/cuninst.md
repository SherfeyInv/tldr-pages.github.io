# cuninst

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `choco uninstall`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr choco uninstall`
