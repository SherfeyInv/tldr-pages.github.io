# mkdir

> ディレクトリを作成します。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>

- ディレクトリを作成します:

`mkdir {{ディレクトリ名}}`

- ネストされたディレクトリツリーを再帰的に作成します:

`mkdir {{サブディレクトリ名のパス}}`
