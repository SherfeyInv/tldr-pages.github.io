# iwr

> このコマンドは `invoke-webrequest` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>

- オリジナルのコマンドのドキュメントを表示する:

`tldr invoke-webrequest`
