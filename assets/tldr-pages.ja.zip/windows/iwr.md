# iwr

> このコマンドは `invoke-webrequest` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr invoke-webrequest`
