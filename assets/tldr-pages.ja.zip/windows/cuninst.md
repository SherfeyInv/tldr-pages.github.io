# cuninst

> このコマンドは `choco uninstall` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco uninstall`
