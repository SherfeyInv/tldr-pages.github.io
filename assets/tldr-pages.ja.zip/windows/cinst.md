# cinst

> このコマンドは `choco install` のエイリアスです。
> 詳しくはこちら: <https://docs.chocolatey.org/en-us/choco/commands/install>

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco install`
