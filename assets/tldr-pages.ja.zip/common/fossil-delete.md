# fossil delete

> このコマンドは `fossil rm` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil rm`
