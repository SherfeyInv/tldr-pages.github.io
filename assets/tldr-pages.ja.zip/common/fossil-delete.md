# fossil delete

> このコマンドは `fossil rm` のエイリアスです。
> 詳しくはこちら: <https://fossil-scm.org/home/help/delete>

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil rm`
