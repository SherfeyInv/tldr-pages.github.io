# ClamAV

> このコマンドは `clamdscan` のエイリアスです。
> 詳しくはこちら: <https://www.clamav.net>

- オリジナルのコマンドのドキュメントを表示する:

`tldr clamdscan`
