# fossil ci

> このコマンドは `fossil commit`.のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil commit`
