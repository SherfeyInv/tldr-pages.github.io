# tldrl

> このコマンドは `tldr-lint` のエイリアスです。
> 詳しくはこちら: <https://github.com/tldr-pages/tldr-lint>

- オリジナルのコマンドのドキュメントを表示する:

`tldr tldr-lint`
