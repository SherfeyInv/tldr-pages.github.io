# gh cs

> このコマンドは `gh codespace`.のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr gh codespace`
