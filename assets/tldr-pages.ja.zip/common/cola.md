# cola

> このコマンドは `git-cola` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr git-cola`
