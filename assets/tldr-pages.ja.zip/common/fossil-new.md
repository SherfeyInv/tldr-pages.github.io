# fossil new

> このコマンドは  `fossil init`.のエイリアスです。
> 詳しくはこちら: <https://fossil-scm.org/home/help/new>

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil-init`
