# llvm-strings

> このコマンドは `strings` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr strings`
