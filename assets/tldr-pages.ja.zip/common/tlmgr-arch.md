# tlmgr arch

> このコマンドは `tlmgr platform` のエイリアスです。
> 詳しくはこちら: <https://www.tug.org/texlive/tlmgr.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr tlmgr platform`
