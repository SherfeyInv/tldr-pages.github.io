# ip route list

> このコマンドは `ip route show`.のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr ip route show`
