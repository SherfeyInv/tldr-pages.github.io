# gb2sum

> Este comando es un alias de `-p linux b2sum`.

- Muestra la documentación del comando original:

`tldr -p linux b2sum`
