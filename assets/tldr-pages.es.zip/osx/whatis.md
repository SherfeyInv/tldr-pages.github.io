# whatis

> Herramienta que busca palabras clave en un conjunto de archivos de base de datos que contienen descripciones breves de comandos del sistema.
> Más información: <https://www.linfo.org/whatis.html>.

- Busca información sobre palabra clave:

`whatis {{palabra_clave}}`

- Busca información sobre varias palabras clave:

`whatis {{palabra_clave1}} {{palabra_clave2}}`
