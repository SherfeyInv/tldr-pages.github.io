# bnepd

> Un servicio que gestiona todas las conexiones de red Bluetooth.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/bnepd.8.html>.

- Inicia el daemon:

`bnepd`
