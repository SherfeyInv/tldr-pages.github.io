# grmdir

> Este comando es un alias de `-p linux rmdir`.

- Muestra la documentación del comando original:

`tldr -p linux rmdir`
