# greadlink

> Este comando es un alias de `-p linux readlink`.

- Muestra la documentación del comando original:

`tldr -p linux readlink`
