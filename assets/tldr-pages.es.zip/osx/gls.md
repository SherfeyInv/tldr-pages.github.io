# gls

> Este comando es un alias de `-p linux ls`.

- Muestra la documentación del comando original:

`tldr -p linux ls`
