# aa

> Este comando es un alias de `yaa`.

- Muestra la documentación del comando original:

`tldr yaa`
