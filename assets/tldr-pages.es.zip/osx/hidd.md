# hidd

> Daemon userland de la librería HID.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/hidd.8.html>.

- Inicia el daemon:

`hidd`
