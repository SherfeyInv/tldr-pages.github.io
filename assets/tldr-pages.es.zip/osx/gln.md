# gln

> Este comando es un alias de `-p linux ln`.

- Muestra la documentación del comando original:

`tldr -p linux ln`
