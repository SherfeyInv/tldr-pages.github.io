# ggrep

> Este comando es un alias de `-p linux grep`.

- Muestra la documentación del comando original:

`tldr -p linux grep`
