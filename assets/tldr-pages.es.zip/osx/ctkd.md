# ctkd

> Daemon de SmartCard.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/ctkd.8.html>.

- Inicia el daemon:

`ctkd`
