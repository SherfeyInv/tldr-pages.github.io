# uptime

> Indica cuánto tiempo lleva funcionando el sistema y otras informaciones.
> Más información: <https://keith.github.io/xcode-man-pages/uptime.1.html>.

- Imprime la hora actual, el tiempo de actividad, el número de usuarios conectados y otras informaciones:

`uptime`
