# gunlink

> Este comando es un alias de `-p linux unlink`.

- Muestra la documentación del comando original:

`tldr -p linux unlink`
