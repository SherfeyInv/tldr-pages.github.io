# airportd

> Gestiona las interfaces inalámbricas.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/airportd.8.html>.

- Inicia el daemon:

`airportd`
