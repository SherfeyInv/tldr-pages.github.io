# glibtool

> Este comando es un alias de `-p linux libtool`.

- Muestra la documentación del comando original:

`tldr -p linux libtool`
