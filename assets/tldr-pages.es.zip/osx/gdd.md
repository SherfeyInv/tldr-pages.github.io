# gdd

> Este comando es un alias de `-p linux dd`.

- Muestra la documentación del comando original:

`tldr -p linux dd`
