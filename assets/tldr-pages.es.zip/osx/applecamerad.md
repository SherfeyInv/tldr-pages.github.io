# applecamerad

> Gestor de cámara.
> No debe ser invocado manualmente.
> Más información: <https://www.theiphonewiki.com/wiki/Services>.

- Inicia el proceso residente:

`applecamerad`
