# reboot

> Reinicia el sistema.
> Más información: <https://keith.github.io/xcode-man-pages/reboot.8.html>.

- Reinicia inmediatamente:

`sudo reboot`

- Reinicia inmediatamente sin apagar el sistema:

`sudo reboot -q`
