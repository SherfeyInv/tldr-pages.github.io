# glibtoolize

> Este comando es un alias de `-p linux libtoolize`.

- Muestra la documentación del comando original:

`tldr -p linux libtoolize`
