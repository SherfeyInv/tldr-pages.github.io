# gjoin

> Este comando es un alias de `-p linux join`.

- Muestra la documentación del comando original:

`tldr -p linux join`
