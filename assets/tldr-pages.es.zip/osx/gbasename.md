# gbasename

> Este comando es un alias de `-p linux basename`.

- Muestra la documentación del comando original:

`tldr -p linux basename`
