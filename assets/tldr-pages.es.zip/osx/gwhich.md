# gwhich

> Este comando es un alias de `-p linux which`.

- Muestra la documentación del comando original:

`tldr -p linux which`
