# guptime

> Este comando es un alias de `-p linux uptime`.

- Muestra la documentación del comando original:

`tldr -p linux uptime`
