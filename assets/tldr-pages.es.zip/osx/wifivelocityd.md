# wifivelocityd

> Asistente XPC para realizar acciones de contexto de sistema para el framework WiFiVelocity.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/wifivelocityd.8.html>.

- Inicia el daemon:

`wifivelocityd`
