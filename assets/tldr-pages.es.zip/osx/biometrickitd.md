# biometrickitd

> Proporciona soporte para operaciones biométricas.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/biometrickitd.8.html>.

- Inicia el proceso residente:

`biometrickitd`
