# gexpand

> Este comando es un alias de `-p linux expand`.

- Muestra la documentación del comando original:

`tldr -p linux expand`
