# gdate

> Este comando es un alias de `-p linux date`.

- Muestra la documentación del comando original:

`tldr -p linux date`
