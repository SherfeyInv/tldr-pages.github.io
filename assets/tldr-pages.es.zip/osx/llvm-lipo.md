# llvm-lipo

> Este comando es un alias de `lipo`.

- Muestra la documentación del comando original:

`tldr lipo`
