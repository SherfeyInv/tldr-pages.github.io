# gshred

> Este comando es un alias de `-p linux shred`.

- Muestra la documentación del comando original:

`tldr -p linux shred`
