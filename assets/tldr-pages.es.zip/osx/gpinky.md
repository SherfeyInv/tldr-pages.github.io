# gpinky

> Este comando es un alias de `-p linux pinky`.

- Muestra la documentación del comando original:

`tldr -p linux pinky`
