# ged

> Este comando es un alias de `-p linux ed`.

- Muestra la documentación del comando original:

`tldr -p linux ed`
