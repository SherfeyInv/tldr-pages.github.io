# avbdeviced

> Un servicio para gestionar dispositivos Audio Video Bridging (AVB).
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/avbdeviced.1.html>.

- Inicia el daemon:

`avbdeviced`
