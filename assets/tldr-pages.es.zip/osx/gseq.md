# gseq

> Este comando es un alias de `-p linux seq`.

- Muestra la documentación del comando original:

`tldr -p linux seq`
