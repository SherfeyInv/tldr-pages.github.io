# InternetSharing

> Configura Internet Sharing.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/InternetSharing/>.

- Inicia el daemon:

`InternetSharing`
