# gpathchk

> Este comando es un alias de `-p linux pathchk`.

- Muestra la documentación del comando original:

`tldr -p linux pathchk`
