# ghead

> Este comando es un alias de `-p linux head`.

- Muestra la documentación del comando original:

`tldr -p linux head`
