# bird

> Esto admite la sincronización de iCloud e iCloud Drive.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/bird.8.html>.

- Inicia el proceso residente:

`bird`
