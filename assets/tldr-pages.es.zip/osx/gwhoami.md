# gwhoami

> Este comando es un alias de `-p linux whoami`.

- Muestra la documentación del comando original:

`tldr -p linux whoami`
