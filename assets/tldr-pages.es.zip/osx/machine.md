# machine

> Imprime el tipo de máquina.
> Más información: <https://keith.github.io/xcode-man-pages/machine.1.html>.

- Imprime la arquitectura de la CPU:

`machine`
