# corebrightnessd

> Gestiona Night Shift.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/corebrightnessd.8.html>.

- Inicia el proceso residente:

`corebrightnessd`
