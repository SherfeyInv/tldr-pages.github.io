# coreaudiod

> Servicio para Core Audio, el sistema de audio de Apple.
> No debe invocarse manualmente.
> Más información: <https://developer.apple.com/library/archive/documentation/MusicAudio/Conceptual/CoreAudioOverview/WhatisCoreAudio/WhatisCoreAudio.html>.

- Inicia el daemon:

`coreaudiod`
