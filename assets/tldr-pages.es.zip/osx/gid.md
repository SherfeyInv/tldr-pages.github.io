# gid

> Este comando es un alias de `-p linux id`.

- Muestra la documentación del comando original:

`tldr -p linux id`
