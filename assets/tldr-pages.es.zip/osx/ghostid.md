# ghostid

> Este comando es un alias de `-p linux hostid`.

- Muestra la documentación del comando original:

`tldr -p linux hostid`
