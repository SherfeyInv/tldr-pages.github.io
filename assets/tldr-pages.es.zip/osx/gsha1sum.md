# gsha1sum

> Este comando es un alias de `-p linux sha1sum`.

- Muestra la documentación del comando original:

`tldr -p linux sha1sum`
