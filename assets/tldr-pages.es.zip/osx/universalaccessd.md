# universalaccessd

> Proporciona servicios de acceso universal.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/universalaccessd.8.html>.

- Inicia el daemon:

`universalaccessd`
