# warmd

> Controla las cachés utilizadas durante el arranque y el inicio de sesión.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/warmd.8.html>.

- Inicia el daemon:

`warmd`
