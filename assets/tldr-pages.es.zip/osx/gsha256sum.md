# gsha256sum

> Este comando es un alias de `-p linux sha256sum`.

- Muestra la documentación del comando original:

`tldr -p linux sha256sum`
