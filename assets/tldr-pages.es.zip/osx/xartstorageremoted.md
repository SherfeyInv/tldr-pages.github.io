# xartstorageremoted

> El Daemon de Almacenamiento Remoto xART. Recibe las solicitudes de guardar/obtener del CoProcesador.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/xartstorageremoted.8.html>.

- Inicia el daemon:

`xartstorageremoted`
