# gdircolors

> Este comando es un alias de `-p linux dircolors`.

- Muestra la documentación del comando original:

`tldr -p linux dircolors`
