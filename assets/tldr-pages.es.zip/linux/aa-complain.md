# aa-complain

> Establece una política de AppArmor en modo de queja.
> Vea también: `aa-disable`, `aa-enforce`, `aa-status`.
> Más información: <https://gitlab.com/apparmor/apparmor/-/wikis/manpage_aa-complain.8>.

- Establece la política en modo de queja:

`sudo aa-complain {{ruta/a/perfil1 ruta/a/perfil2 ...}}`

- Establece políticas en modo de queja:

`sudo aa-complain --dir {{ruta/a/perfiles}}`
