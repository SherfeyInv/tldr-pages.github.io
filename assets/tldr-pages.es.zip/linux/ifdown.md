# ifdown

> Desactiva interfaces de red.
> Más información: <https://manned.org/ifdown>.

- Desactiva la interfaz eth0:

`ifdown {{eth0}}`

- Desactiva todas las interfaces que estén activadas:

`ifdown -a`
