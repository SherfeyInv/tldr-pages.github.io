# cacaclock

> Muestra la hora actual como arte ASCII.
> Más información: <https://packages.debian.org/sid/caca-utils>.

- Muestra la hora:

`cacaclock`

- Cambia la fuente:

`cacaclock -f {{fuente}}`

- Cambia el formato usando una especificación de formato de `strftime`:

`cacaclock -d {{argumentos_strftime}}`
