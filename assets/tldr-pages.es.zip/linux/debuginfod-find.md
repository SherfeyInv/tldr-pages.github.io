# debuginfod-find

> Solicita datos relacionados con debuginfo.
> Más información: <https://manned.org/debuginfod-find>.

- Solicita datos basados en `build_id`:

`debuginfod-find -vv debuginfo {{identificador_de_build}}`
