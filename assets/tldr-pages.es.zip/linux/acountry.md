# acountry

> Imprime el país donde se encuentra una dirección IPv4 o el nombre de un host.
> Más información: <https://manned.org/acountry>.

- Imprime un país donde se encuentra una dirección IPv4 o host:

`acountry {{ejemplo.com}}`

- Imprime salida de depuración adicional:

`acountry -d {{ejemplo.com}}`

- Imprime información más detallada:

`acountry -v {{ejemplo.com}}`
