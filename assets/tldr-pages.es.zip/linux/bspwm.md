# bspwm

> Un gestor de ventanas embaldosado basado en particionado de espacio binario.
> Vea también: `bspc`, para controlar el gestor.
> Más información: <https://github.com/baskerville/bspwm>.

- Inicia `bspwm` (cabe recalcar que no debe haber otro gestor de ventanas al ejecutar este comando):

`bspwm -c {{ruta/a/archivo_de_configuración}}`
