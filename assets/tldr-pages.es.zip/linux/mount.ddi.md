# mount.ddi

> Monta imágenes de disco reconocibles.
> Vea `tldr systemd-dissect` para otros comandos relevantes para DDIs.
> Más información: <https://www.freedesktop.org/software/systemd/man/latest/systemd-dissect.html>.

- Monta una imagen con un sistema operativo:

`mount.ddi {{ruta/a/imagen.raw}} {{/mnt/image}}`
