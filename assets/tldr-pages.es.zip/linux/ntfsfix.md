# ntfsfix

> Arregla problemas habituales de una partición NTFS.
> Más información: <https://manned.org/ntfsfix>.

- Arregla una partición NTFS dada:

`sudo ntfsfix {{/dev/sdXN}}`
