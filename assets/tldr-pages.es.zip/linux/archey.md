# archey

> Herramienta sencilla para mostrar información del sistema con estilo.
> Más información: <https://lclarkmichalek.github.io/archey3/>.

- Muestra información del sistema:

`archey`
