# halt

> Detiene, apaga o reinicia la máquina.
> Más información: <https://manned.org/halt.8>.

- Detiene la máquina:

`halt`

- Apaga la máquina:

`halt --poweroff`

- Reinicia la máquina:

`halt --reboot`
