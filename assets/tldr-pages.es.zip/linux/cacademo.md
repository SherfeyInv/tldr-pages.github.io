# cacademo

> Muestra una animación aleatoria de arte ASCII.
> Más información: <https://packages.debian.org/sid/caca-utils>.

- Ve una animación:

`cacademo`
