# sensors

> Proporciona información de los sensores.
> Más información: <https://manned.org/sensors>.

- Muestra las lecturas actuales de todos los sensores:

`sensors`

- Muestra las temperaturas en grados Fahrenheit:

`sensors --fahrenheit`
