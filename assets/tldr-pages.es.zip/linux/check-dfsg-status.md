# check-dfsg-status

> Informa de paquetes no libres instalados en sistemas operativos basados en Debian.
> Este comando se conocía anteriormente como `vrms`.
> Más información: <https://debian.pages.debian.net/check-dfsg-status/>.

- Lista los paquetes no libres y `contrib` (más la descripción):

`check-dfsg-status`

- Muestra solo los nombres de los paquetes:

`check-dfsg-status --sparse`
