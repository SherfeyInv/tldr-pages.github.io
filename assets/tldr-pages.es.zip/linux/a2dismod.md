# a2dismod

> Deshabilita un módulo de Apache en sistemas operativos basados en Debian.
> Más información: <https://manned.org/a2dismod.8>.

- Deshabilita un módulo:

`sudo a2dismod {{módulo}}`

- Deshabilita un módulo sin mostrar mensajes informativos:

`sudo a2dismod --quiet {{módulo}}`
