# ubuntu-bug

> Este comando es un alias de `apport-bug`.
> Más información: <https://manned.org/ubuntu-bug>.

- Muestra la documentación del comando original:

`tldr apport-bug`
