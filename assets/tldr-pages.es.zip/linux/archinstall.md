# archinstall

> Instalador guiado de Arch Linux con un giro.
> Más información: <https://archinstall.readthedocs.io>.

- Inicia el instalador interactivo:

`archinstall`

- Inicia un instalador preestablecido:

`archinstall {{minimal|unattended}}`
