# newgrp

> Cambia el grupo primario de pertenencia.
> Más información: <https://manned.org/newgrp>.

- Cambia el grupo primario de pertenencia del usuario:

`newgrp {{nombre_grupo}}`

- Restablece el grupo primario de pertenencia al grupo por defecto del usuario `/etc/passwd`:

`newgrp`
