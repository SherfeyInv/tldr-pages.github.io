# tcpflow

> Captura el tráfico TCP para depuración y análisis.
> Más información: <https://manned.org/tcpflow>.

- Muestra todos los datos de la interfaz y el puerto indicados:

`tcpflow -c -i {{eth0}} port {{80}}`
