# batcat

> Este comando es un alias de `bat`.
> Más información: <https://github.com/sharkdp/bat>.

- Muestra la documentación del comando original:

`tldr bat`
