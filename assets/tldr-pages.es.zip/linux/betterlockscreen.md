# betterlockscreen

> Pantalla de bloqueo simple y mínima.
> Más información: <https://github.com/betterlockscreen/betterlockscreen>.

- Bloquea la pantalla:

`betterlockscreen --lock`

- Cambia el fondo de la pantalla de bloqueo:

`betterlockscreen -u {{ruta/a/imagen.png}}`

- Bloquea la pantalla y muestra un texto personalizado:

`betterlockscreen -l pixel -t "{{texto de pantalla de bloqueo personalizado}}"`

- Bloquea la pantalla, con un tiempo de espera personalizado para apagar el monitor en segundos:

`betterlockscreen --off {{5}} -l`
