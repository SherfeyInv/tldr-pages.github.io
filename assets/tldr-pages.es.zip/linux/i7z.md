# i7z

> Una herramienta de informes en tiempo real para CPUs Intel (sólo i3, i5 e i7).
> Más información: <https://manned.org/i7z>.

- Inicia i7z (se necesita ejecutar en modo superusuario):

`sudo i7z`
