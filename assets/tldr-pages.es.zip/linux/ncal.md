# ncal

> Este comando es un alias de `cal`.
> Más información: <https://manned.org/ncal>.

- Muestra la documentación del comando original:

`tldr cal`
