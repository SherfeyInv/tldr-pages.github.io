# ydotool

> Controla las entradas de teclado y ratón mediante comandos de forma agnóstica al servidor de visualización.
> Más información: <https://github.com/ReimuNotMoe/ydotool>.

- Inicia el daemon ydotool en segundo plano:

`ydotoold`

- Realiza un clic con el botón izquierdo:

`ydotool click 0xC0`

- Realiza un clic con el botón derecho:

`ydotool click 0xC1`

- Ingresa la combinación de teclas Alt+F4:

`ydotool key 56:1 62:1 62:0 56:0`
