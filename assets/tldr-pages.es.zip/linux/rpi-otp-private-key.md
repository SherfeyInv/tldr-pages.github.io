# rpi-otp-private-key

> Muestra la llave privada de la clave de un solo uso (OTP) de una Raspberry Pi.
> Más información: <https://www.raspberrypi.com/documentation/computers/raspberry-pi.html#program-a-key-into-otp-with-rpi-otp-private-key>.

- Lee la clave privada OTP:

`rpi-otp-private-key`
