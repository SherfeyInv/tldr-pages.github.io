# dhcpcd

> Cliente DHCP.
> Más información: <https://roy.marples.name/projects/dhcpcd>.

- Libera todas las direcciones:

`sudo dhcpcd --release`

- Solicita nuevas direcciones al servidor DHCP:

`sudo dhcpcd --rebind`
