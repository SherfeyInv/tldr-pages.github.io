# terraria

> Crea e inicia un servidor Terraria sin interfaz gráfica.
> Más información: <https://terraria.wiki.gg/wiki/Server>.

- Inicia la configuración interactiva de un servidor:

`{{ruta/a/TerrariaServer}}`

- Inicia un servidor Terraria:

`{{ruta/a/TerrariaServer}} -world {{ruta/a/world.wld}}`
