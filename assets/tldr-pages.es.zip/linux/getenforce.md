# getenforce

> Obtén el modo actual de SELinux (es decir, obligatorio, permisivo o deshabilitado).
> Más información: <https://manned.org/getenforce>.

- Muestra el modo actual de SELinux:

`getenforce`
