# wm

> Muestra información sobre la pantalla de un dispositivo Android.
> Este comando solo se puede usar a través de `adb shell`.
> Más información: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Muestra el tamaño físico de la pantalla de un dispositivo Android:

`wm size`

- Muestra la densidad física de la pantalla de un dispositivo Android:

`wm density`
