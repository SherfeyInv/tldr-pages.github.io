# chsh

> Este comando es un alias de `chpass`.

- Vea la documentación para el comando original:

`tldr chpass`
