# npm restart

> Este comando es un alias de `npm run restart`.

- Vea la documentación para el comando original:

`tldr npm run`
