# azure-cli

> Este comando es un alias de `az`.

- Vea la documentación del comando original:

`tldr az`
