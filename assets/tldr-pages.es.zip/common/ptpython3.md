# ptpython3

> Este comando es un alias de `ptpython`.

- Muestra la documentación del comando original:

`tldr ptpython`
