# vimtutor

> Vim tutor, enseña los comandos básicos de vim.
> Más información: <https://manned.org/vimtutor>.

- Ejecuta vim tutor utilizando el idioma especificado (en, es, de, ...):

`vimtutor {{idioma}}`

- Sale del tutor:

`<Esc> :q <Enter>`
