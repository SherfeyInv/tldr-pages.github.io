# pgmedge

> Este comando ha sido sustituido por `pamedge`.
> Más información: <https://netpbm.sourceforge.net/doc/pgmedge.html>.

- Consulta la documentación del comando actual:

`tldr pamedge`
