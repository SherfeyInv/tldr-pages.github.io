# pnmfile

> Este comando ha sido sustituido por `pamfile`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmfile.html>.

- Vea la documentación del comando actual:

`tldr pamfile`
