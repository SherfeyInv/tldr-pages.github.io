# docker top

> Muestra los procesos que se están ejecutando en un contenedor.
> Más información: <https://docs.docker.com/reference/cli/docker/container/top/>.

- Muestra los procesos que se están ejecutando en un contenedor:

`docker top {{contenedor}}`

- Muestra la ayuda:

`docker top --help`
