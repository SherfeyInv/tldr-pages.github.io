# lzcmp

> Este comando es un alias de `xzcmp`.

- Vea la documentación para el comando original:

`tldr xzcmp`
