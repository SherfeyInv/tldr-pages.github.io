# xzmore

> Muestra texto de archivos comprimidos `xz` o `lzma`.
> Casi equivalente a `xzless`, excepto que respeta la variable de entorno `PAGER`, utiliza `more` de forma predeterminada y no puede pasar opciones al paginador.
> Más información: <https://manned.org/xzmore>.

- Muestra un archivo comprimido:

`xzmore {{ruta/al/archivo}}`
