# pi1toppm

> Convierte una imagen Atari Degas PI1 en una imagen PPM.
> Vea también: `ppmtopi1`.
> Más información: <https://netpbm.sourceforge.net/doc/pi1toppm.html>.

- Convierte una imagen Atari Degas PI1 en una imagen PPM:

`pi1toppm {{ruta/a/imagen_atari.pi1}} > {{ruta/a/imagen.ppm}}`
