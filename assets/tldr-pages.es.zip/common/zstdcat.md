# zstdcat

> Este comando es un alias de `zstd --decompress --stdout`.

- Vea la documentación para el comando original:

`tldr zstd`
