# docker container remove

> Este comando es un alias de `docker rm`.

- Vea la documentación para el comando original:

`tldr docker rm`
