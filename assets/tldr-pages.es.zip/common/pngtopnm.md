# pngtopnm

> Este comando ha sido sustituido por `pngtopam`.
> Más información: <https://netpbm.sourceforge.net/doc/pngtopnm.html>.

- Ve documentación del comando actual:

`tldr pngtopam`
