# ppmtopi1

> Convierte una imagen PPM en una imagen Atari Degas PI1.
> Vea también: `pi1toppm`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmtopi1.html>.

- Convierte una imagen PPM en una imagen Atari Degas PI1:

`ppmtopi1 {{ruta/a/imagen.ppm}} > {{ruta/a/imagen_salida.pi1}}`
