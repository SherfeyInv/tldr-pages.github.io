# tldrl

> Este comando es un alias de `tldr-lint`.

- Vea la documentación del comando original:

`tldr tldr-lint`
