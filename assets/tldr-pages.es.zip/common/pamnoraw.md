# pamnoraw

> Este comando es un alias de `pamtopnm -plain`.

- Vea la documentación para el comando original:

`tldr pamtopnm`
