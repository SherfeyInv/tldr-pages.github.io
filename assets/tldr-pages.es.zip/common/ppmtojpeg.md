# ppmtojpeg

> Este comando ha sido sustituido por `pnmtojpeg`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmtojpeg.html>.

- Ve documentación del comando actual:

`tldr pnmtojpeg`
