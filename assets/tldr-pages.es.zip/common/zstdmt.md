# zstdmt

> Este comando es un alias de `zstd --threads 0` (que establece el número de hilos (working threads) al número de núcleos de CPU físicos).

- Vea la documentación para el comando original:

`tldr zstd`
