# mscore

> Este comando es un alias de `musescore`.

- Vea la documentación del comando original:

`tldr musescore`
