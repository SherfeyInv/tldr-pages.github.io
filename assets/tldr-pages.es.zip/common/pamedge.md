# pamedge

> Realiza la detección de bordes en una imagen Netpbm.
> Más información: <https://netpbm.sourceforge.net/doc/pamedge.html>.

- Detecta bordes en una imagen Netpbm:

`pamedge {{ruta/a/entrada.pam}} > {{ruta/a/salida.pam}}`
