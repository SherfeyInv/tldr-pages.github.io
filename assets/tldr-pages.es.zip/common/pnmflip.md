# pnmflip

> Este comando ha sido sustituido por `pamflip`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmflip.html>.

- Vea documentación del comando actual:

`tldr pamflip`
