# trash-cli

> Este comando es un alias de `trash`.

- Vea la documentación para el comando original:

`tldr trash`
