# az feedback

> Envía comentarios al equipo de Azure CLI.
> Parte de `azure-cli` (también conocido como `az`).
> Más información: <https://learn.microsoft.com/cli/azure/reference-index#az_feedback>.

- Envía comentarios al equipo de Azure CLI:

`az feedback`
