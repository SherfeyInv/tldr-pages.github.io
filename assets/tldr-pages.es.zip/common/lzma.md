# lzma

> Este comando es un alias de `xz --format=lzma`.

- Vea la documentación para el comando original:

`tldr xz`
