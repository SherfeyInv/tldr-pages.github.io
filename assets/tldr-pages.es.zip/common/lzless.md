# lzless

> Este comando es un alias de `xzless`.

- Vea la documentación para el comando original:

`tldr xzless`
