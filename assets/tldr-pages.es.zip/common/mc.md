# mc

> Midnight Commander, un administrador de archivos TUI.
> Navega la estructura del directorio usando las flechas del teclado, el ratón o escribiendo los comandos en la terminal.
> Vea también: `ranger`, `clifm`, `vifm`, `nautilus`.
> Más información: <https://midnight-commander.org>.

- Inicia Midnight Commander:

`mc`

- Inicia Midnight Commander en blanco y negro:

`mc -b`
