# npm stop

> Este comando es un alias de `npm run stop`.

- Vea la documentación para el comando original:

`tldr npm run`
