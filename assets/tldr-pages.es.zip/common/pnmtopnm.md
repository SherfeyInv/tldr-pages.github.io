# pnmtopnm

> Este comando es un alias de `pamtopnm`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmtopnm.html>.

- Vea la documentación para el comando original:

`tldr pamtopnm`
