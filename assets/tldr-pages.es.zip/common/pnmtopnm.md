# pnmtopnm

> Este comando es un alias de `pamtopnm`.

- Vea la documentación para el comando original:

`tldr pamtopnm`
