# docker container top

> Este comando es un alias de `docker top`.
> Más información: <https://docs.docker.com/reference/cli/docker/container/top/>.

- Vea la documentación para el comando original:

`tldr docker top`
