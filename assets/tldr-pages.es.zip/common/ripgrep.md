# ripgrep

> Este comando es un alias de `rg`.

- Muestra la documentación del comando original:

`tldr rg`
