# transmission

> Este comando es un alias de `transmission-daemon`.
> Más información: <https://transmissionbt.com/>.

- Muestra la documentación del comando original:

`tldr transmission-daemon`
