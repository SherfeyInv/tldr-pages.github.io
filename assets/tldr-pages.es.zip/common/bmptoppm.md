# bmptoppm

> Este comando es reemplazado por `bmptopnm`.
> Más información: <https://netpbm.sourceforge.net/doc/bmptoppm.html>.

- Ve documentación del comando actual:

`tldr bmptopnm`
