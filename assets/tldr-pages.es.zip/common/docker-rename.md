# docker rename

> Renombra un contenedor.
> Más información: <https://docs.docker.com/reference/cli/docker/container/rename/>.

- Renombra un contenedor:

`docker rename {{contenedor}} {{nuevo_nombre}}`

- Muestra la ayuda:

`docker rename --help`
