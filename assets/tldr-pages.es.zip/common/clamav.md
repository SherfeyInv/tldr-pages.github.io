# ClamAV

> Programa antivirus de código abierto.
> ClamAV no es un comando, sino un conjunto de comandos.
> Más información: <https://www.clamav.net>.

- Muestra la página tldr para escanear archivos usando el daemon `clamd`:

`tldr clamdscan`

- Muestra la página tldr para escanear archivos sin que se ejecute el daemon `clamd`:

`tldr clamscan`

- Muestra la página tldr para actualizar las definiciones de virus:

`tldr freshclam`
