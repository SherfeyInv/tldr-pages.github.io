# ppmbrighten

> Este comando ha sido sustituido por `pambrighten`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmbrighten.html>.

- Vea documentación del comando actual:

`tldr pambrighten`
