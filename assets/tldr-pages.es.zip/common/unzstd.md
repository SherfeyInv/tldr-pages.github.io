# unzstd

> Este comando es un alias de `zstd --decompress`.

- Vea la documentación para el comando original:

`tldr zstd`
