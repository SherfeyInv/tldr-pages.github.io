# pnmcut

> Este comando ha sido sustituido por `pamcut`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmcut.html>.

- Ve documentación del comando actual:

`tldr pamcut`
