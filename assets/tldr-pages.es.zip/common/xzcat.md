# xzcat

> Este comando es un alias de `xz --decompress --stdout`.

- Vea la documentación para el comando original:

`tldr xz`
