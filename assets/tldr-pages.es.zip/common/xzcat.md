# xzcat

> Este comando es un alias de `xz`.
> Más información: <https://manned.org/xzcat>.

- Muestra la documentación del comando original:

`tldr xz`
