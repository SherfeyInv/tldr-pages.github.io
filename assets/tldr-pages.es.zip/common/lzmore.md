# lzmore

> Este comando es un alias de `xzmore`.

- Vea la documentación para el comando original:

`tldr xzmore`
