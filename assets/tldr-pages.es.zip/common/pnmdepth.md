# pnmdepth

> Este comando es un alias de `pamdepth`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmdepth.html>.

- Vea la documentación para el comando original:

`tldr pamdepth`
