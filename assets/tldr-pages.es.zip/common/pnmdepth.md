# pnmdepth

> Este comando es un alias de `pamdepth`.

- Vea la documentación para el comando original:

`tldr pamdepth`
