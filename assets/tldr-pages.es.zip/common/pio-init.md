# pio init

> Este comando es un alias de `pio project init`.

- Vea la documentación para el comando original:

`tldr pio project`
