# mogrify

> Este comando es un alias de `magick mogrify`.

- Vea la documentación para el comando original:

`tldr magick mogrify`
