# xzcmp

> Invoca `cmp` en archivos comprimidos con `xz`, `lzma`, `gzip`, `bzip2`, `lzop`, o `zstd`.
> Todas las opciones especificadas se pasan directamente a `cmp`.
> Más información: <https://manned.org/xzcmp>.

- Compara dos archivos específicos:

`xzcmp {{ruta/al/archivo1}} {{ruta/al/archivo2}}`
