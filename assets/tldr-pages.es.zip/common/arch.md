# arch

> Muestra el nombre de la arquitectura del sistema.
> Vea también `uname`.
> Más información: <https://www.gnu.org/software/coreutils/arch>.

- Muestra la arquitectura del sistema:

`arch`
