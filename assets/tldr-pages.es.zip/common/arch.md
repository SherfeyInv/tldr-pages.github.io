# arch

> Muestra el nombre de la arquitectura del sistema.
> Vea también `uname`.
> Más información: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Muestra la arquitectura del sistema:

`arch`
