# npm start

> Este comando es un alias de `npm run start`.

- Vea la documentación para el comando original:

`tldr npm run`
