# identify

> Este comando es un alias de `magick identify`.

- Vea la documentación para el comando original:

`tldr magick identify`
