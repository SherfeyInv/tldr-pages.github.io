# vivaldi

> Este comando es un alias de `chromium`.
> Más información: <https://vivaldi.com>.

- Vea la documentación para el comando original:

`tldr chromium`
