# lima

> Este comando es un alias de `limactl shell` para la instancia VM predeterminada.
> También puede establecer la variable ambiente '$LIMA_INSTANCE' para trabajar en una instancia diferente.

- Vea la documentación para el comando original:

`tldr limactl`
