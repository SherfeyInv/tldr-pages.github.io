# rcat

> Este comando es un alias de `rc`.

- Muestra la documentación del comando original:

`tldr rc`
