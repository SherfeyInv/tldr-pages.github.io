# pnmtoplainpnm

> Este comando es un alias de `pamtopnm -plain`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmtoplainpnm.html>.

- Vea la documentación para el comando original:

`tldr pamtopnm`
