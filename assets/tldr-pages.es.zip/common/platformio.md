# platformio

> Este comando es un alias de `pio`.
> Más información: <https://docs.platformio.org/en/latest/core/userguide/>.

- Muestra la documentación del comando original:

`tldr pio`
