# npm test

> Este comando es un alias de `npm run test`.

- Vea la documentación para el comando original:

`tldr npm run`
