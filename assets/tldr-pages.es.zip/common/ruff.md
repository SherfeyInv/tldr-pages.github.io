# ruff

> Un linter y formateador de código para Python, escrito en Rust.
> Más información: <https://docs.astral.sh/ruff/tutorial>.

- Vea la documentación para el linter de Ruff:

`tldr ruff check`

- Vea la documentación para el formateador de Ruff:

`tldr ruff format`
