# npm run-script

> Este comando es un alias de `npm run`.

- Vea la documentación para el comando original:

`tldr npm run`
