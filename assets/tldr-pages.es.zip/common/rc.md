# rc

> Una escucha de puerto moderna simplificada y con interfaz de comando reversa.
> Similar a `nc`.
> Más información: <https://github.com/robiot/rustcat/wiki/Basic-Usage>.

- Comienza a escuchar en un puerto específico:

`rc -lp {{puerto}}`

- Comienza una interfaz de comando inversa:

`rc {{equipo}} {{puerto}} -r {{shell}}`
