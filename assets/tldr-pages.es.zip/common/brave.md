# brave

> Este es un comando alias de `chromium`.
> Más información: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Muestra la documentación del comando original:

`tldr chromium`
