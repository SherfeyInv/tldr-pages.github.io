# brave

> Este comando es un alias de `chromium`.
> Más información: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Vea la documentación para el comando original:

`tldr chromium`
