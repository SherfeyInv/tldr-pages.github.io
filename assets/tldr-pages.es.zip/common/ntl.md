# ntl

> Este comando es un alias de `netlify`.

- Vea la documentación del comando original:

`tldr netlify`
