# docker container rename

> Este comando es un alias de `docker rename`.

- Vea la documentación para el comando original:

`tldr docker rename`
