# dolt gc

> Busca en el repositorio los datos que ya no se referencian ni necesitan.
> Más información: <https://docs.dolthub.com/cli-reference/cli#dolt-gc>.

- Limpia datos no referenciados del repositorio:

`dolt gc`

- Inicia un proceso de recolección de basura más rápido pero menos exhaustivo:

`dolt gc --shallow`
