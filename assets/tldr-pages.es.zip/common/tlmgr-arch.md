# tlmgr arch

> Este comando es un alias de `tlmgr platform`.

- Vea la documentación del comando original:

`tldr tlmgr platform`
