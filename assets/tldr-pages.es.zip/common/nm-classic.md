# nm-classic

> Este comando es un alias de `nm`.

- Muestra la documentación del comando original:

`tldr nm`
