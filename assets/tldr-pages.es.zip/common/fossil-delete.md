# fossil delete

> Este comando es un alias de `fossil rm`.
> Más información: <https://fossil-scm.org/home/help/delete>.

- Muestra la documentación del comando original:

`tldr fossil rm`
