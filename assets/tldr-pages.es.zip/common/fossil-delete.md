# fossil delete

> Este comando es un alias de `fossil rm`.

- Vea la documentación del comando original:

`tldr fossil rm`
