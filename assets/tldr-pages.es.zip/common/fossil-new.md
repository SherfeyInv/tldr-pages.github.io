# fossil new

> Este comando es un alias de `fossil init`.

- Vea la documentación del comando original:

`tldr fossil init`
