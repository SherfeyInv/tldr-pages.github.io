# fossil new

> Este comando es un alias de `fossil init`.
> Más información: <https://fossil-scm.org/home/help/new>.

- Muestra la documentación del comando original:

`tldr fossil-init`
