# sls

> Este comando es un alias de `Select-String`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Muestra la documentación del comando original:

`tldr select-string`
