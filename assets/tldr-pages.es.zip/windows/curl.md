# curl

> Este comando es un alias de `curl -p common`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Muestra la documentación del comando original:

`tldr curl -p common`
