# exit

> Sale de la instancia CMD actual o del archivo por lotes actual.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- Sale de la instancia CMD actual:

`exit`

- Sale del conjunto de instrucciones del archivo por lotes actual:

`exit /b`

- Sale usando un código de salida específico:

`exit {{2}}`
