# cinst

> Este comando es un alias de `choco install`.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Muestra la documentación del comando original:

`tldr choco install`
