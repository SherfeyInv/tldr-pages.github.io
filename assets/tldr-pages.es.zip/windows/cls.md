# cls

> Borra la pantalla.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Borra la pantalla:

`cls`
