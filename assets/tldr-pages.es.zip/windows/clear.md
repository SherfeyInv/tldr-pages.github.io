# clear

> En PowerShell, este comando es un alias de `Clear-Host`.

- Muestra la documentación del comando original:

`tldr clear-host`
