# pwsh where

> Este comando es un alias de `Where-Object`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Muestra la documentación del comando original:

`tldr Where-Object`
