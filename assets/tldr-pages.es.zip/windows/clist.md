# clist

> Este comando es un alias de `choco list`.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Muestra la documentación del comando original:

`tldr choco list`
