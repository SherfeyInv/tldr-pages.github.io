# pwsh where

> Denne kommandoen er et alias for `Where-Object`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr Where-Object`
