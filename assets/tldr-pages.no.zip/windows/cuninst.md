# cuninst

> Denne kommandoen er et alias for `choco uninstall`.
> Mer informasjon: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco uninstall`
