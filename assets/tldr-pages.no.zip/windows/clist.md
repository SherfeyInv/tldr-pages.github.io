# clist

> Denne kommandoen er et alias for `choco list`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco list`
