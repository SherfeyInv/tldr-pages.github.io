# curl

> Denne kommandoen er et alias for `curl -p common`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr curl -p common`
