# ncal

> Denne kommandoen er et alias for `cal`.
> Mer informasjon: <https://manned.org/ncal>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr cal`
