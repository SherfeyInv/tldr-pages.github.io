# ncal

> Denne kommandoen er et alias for `cal`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr cal`
