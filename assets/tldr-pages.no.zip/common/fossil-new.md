# fossil new

> Denne kommandoen er et alias for  `fossil init`.
> Mer informasjon: <https://fossil-scm.org/home/help/new>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil-init`
