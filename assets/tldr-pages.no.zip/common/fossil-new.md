# fossil new

> Denne kommandoen er et alias for `fossil init`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil init`
