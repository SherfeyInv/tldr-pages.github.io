# pio init

> Denne kommandoen er et alias for `pio project`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pio project`
