# ClamAV

> Denne kommandoen er et alias for `clamdscan`.
> Mer informasjon: <https://www.clamav.net>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr clamdscan`
