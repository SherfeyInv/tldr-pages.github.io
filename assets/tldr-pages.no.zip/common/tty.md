# tty

> Returner terminal navn.
> Mer informasjon: <https://www.gnu.org/software/coreutils/tty>.

- Print fil navnet fra denne terminalen:

`tty`
