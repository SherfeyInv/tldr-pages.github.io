# fossil forget

> Denne kommandoen er et alias for `fossil rm`.
> Mer informasjon: <https://fossil-scm.org/home/help/forget>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil rm`
