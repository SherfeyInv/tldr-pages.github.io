# platformio

> Denne kommandoen er et alias for `pio`.
> Mer informasjon: <https://docs.platformio.org/en/latest/core/userguide/>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pio`
