# llvm-nm

> Denne kommandoen er et alias for `nm`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr nm`
