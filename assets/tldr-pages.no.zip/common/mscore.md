# mscore

> Denne kommandoen er et alias for `musescore`.
> Mer informasjon: <https://musescore.org/handbook/command-line-options>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr musescore`
