# fossil delete

> Denne kommandoen er et alias for `fossil rm`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil rm`
