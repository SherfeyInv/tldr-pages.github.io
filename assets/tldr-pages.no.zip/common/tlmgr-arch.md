# tlmgr arch

> Denne kommandoen er et alias for `tlmgr platform`.
> Mer informasjon: <https://www.tug.org/texlive/tlmgr.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr tlmgr platform`
