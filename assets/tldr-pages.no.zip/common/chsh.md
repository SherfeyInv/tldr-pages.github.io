# chsh

> Forandre brukerens påloggings shell.
> Mer informasjon: <https://manned.org/chsh>.

- Forandre shell:

`chsh -s {{sti/til/shell_binær}} {{brukernavn}}`
