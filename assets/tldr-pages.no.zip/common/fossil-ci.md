# fossil ci

> Denne kommandoen er et alias for  `fossil commit`.
> Mer informasjon: <https://fossil-scm.org/home/help/commit>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil-commit`
