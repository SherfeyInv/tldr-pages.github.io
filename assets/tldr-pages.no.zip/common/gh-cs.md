# gh cs

> Denne kommandoen er et alias for  `gh codespace`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gh codespace`
