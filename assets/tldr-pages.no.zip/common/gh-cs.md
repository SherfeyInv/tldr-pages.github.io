# gh cs

> Denne kommandoen er et alias for  `gh codespace`.
> Mer informasjon: <https://cli.github.com/manual/gh_codespace>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gh-codespace`
