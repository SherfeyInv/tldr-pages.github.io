# sls

> Este comando é um apelido de `Select-String`.

- Exibe documentação sobre o comando original:

`tldr select-string`
