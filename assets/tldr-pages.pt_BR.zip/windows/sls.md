# sls

> Este comando é um apelido de `Select-String`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Exibe documentação sobre o comando original:

`tldr select-string`
