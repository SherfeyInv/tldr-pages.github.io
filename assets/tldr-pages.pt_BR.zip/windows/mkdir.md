# mkdir

> Criar um diretório.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Cria um diretório:

`mkdir {{nome_do_diretorio}}`

- Cria recursivamente uma árvore de diretórios aninhados:

`mkdir {{caminho/para/subdiretorio}}`
