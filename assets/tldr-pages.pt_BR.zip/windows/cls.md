# cls

> Limpar a tela de saída.
> No PowerShell, este comando é um apelido de `Clear-Host`. Esta documentação é baseada na versão Prompt de Comando (`cmd`) do `cls`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Exibe a documentação do comando equivalente do PowerShell:

`tldr clear-host`

- Limpa a tela:

`cls`
