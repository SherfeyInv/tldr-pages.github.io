# ver

> Exibe a atual versão do Windows ou MS-DOS.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- Mostra a atual versão:

`ver`
