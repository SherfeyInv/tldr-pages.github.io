# type

> Mostrar o conteúdo de um arquivo.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/type>.

- Mostra o conteúdo de um arquivo específico:

`type {{caminho/para/arquivo}}`
