# clist

> Este comando é um apelido de `choco list`.

- Exibe documentação sobre o comando original:

`tldr choco list`
