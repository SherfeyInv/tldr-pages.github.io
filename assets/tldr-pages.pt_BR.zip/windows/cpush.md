# cpush

> Este comando é um apelido de `choco push`.

- Exibe documentação sobre o comando original:

`tldr choco push`
