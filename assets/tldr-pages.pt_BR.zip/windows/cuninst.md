# cuninst

> Este comando é um apelido de `choco uninstall`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Exibe documentação sobre o comando original:

`tldr choco uninstall`
