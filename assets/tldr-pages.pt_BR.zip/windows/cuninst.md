# cuninst

> Este comando é um apelido de `choco uninstall`.

- Exibe documentação sobre o comando original:

`tldr choco uninstall`
