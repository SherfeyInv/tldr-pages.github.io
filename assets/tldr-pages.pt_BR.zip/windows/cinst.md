# cinst

> Este comando é um apelido de `choco install`.

- Exibe documentação sobre o comando original:

`tldr choco install`
