# pwsh where

> Este comando é um apelido de `Where-Object`.

- Exibe documentação sobre o comando original:

`tldr Where-Object`
