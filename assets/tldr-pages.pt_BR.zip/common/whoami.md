# whoami

> Imprime o nome do usuário associado com o ID do usuário efetivamente atual.
> Mais informações: <https://www.gnu.org/software/coreutils/whoami>.

- Exibe o nome do usuário logado:

`whoami`

- Exibe o nome do usuário depois de uma mudança do ID do usuário:

`sudo whoami`
