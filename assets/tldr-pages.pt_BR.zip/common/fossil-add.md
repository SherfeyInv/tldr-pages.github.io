# fossil add

> Coloca arquivos ou diretórios sob o controle de versão do Fossil.
> Mais informações: <https://fossil-scm.org/home/help/add>.

- Coloca um arquivo ou diretório sob o controle de versão, de forma que ele estará no checkout atual:

`fossil add {{caminho/para/arquivo_ou_diretório}}`

- Remove todos os arquivos adicionados do checkout atual:

`fossil add --reset`
