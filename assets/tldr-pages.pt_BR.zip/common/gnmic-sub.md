# gnmic sub

> Este comando é um apelido de `gnmic subscribe`.

- Exibe documentação sobre o comando original:

`tldr gnmic subscribe`
