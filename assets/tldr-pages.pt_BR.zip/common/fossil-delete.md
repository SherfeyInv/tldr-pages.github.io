# fossil delete

> Este comando é um apelido de `fossil rm`.

- Exibe documentação sobre o comando original:

`tldr fossil rm`
