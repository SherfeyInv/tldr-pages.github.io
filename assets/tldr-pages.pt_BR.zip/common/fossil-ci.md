# fossil ci

> Este comando é um apelido de  `fossil commit`.
> Mais informações: <https://fossil-scm.org/home/help/commit>.

- Exibe documentação sobre o comando original:

`tldr fossil-commit`
