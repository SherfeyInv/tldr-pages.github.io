# banner

> Exibe o argumento inserido como um grande banner em arte ASCII.
> Mais informações: <https://manned.org/banner>.

- Exibe uma mensagem em texto como banner (aspas são opcionais):

`banner "{{Olá Mundo}}"`

- Exibe um banner com a largura de 50 caracteres:

`banner -w 50 "{{Olá Mundo}}"`

- Lê texto da `stdin`, isto é, da entrada padrão:

`banner`
