# brave

> Este comando é um alias(apelido) de `chromium`.
> Mais informações: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Veja a documentação para o comando original:

`tldr chromium`
