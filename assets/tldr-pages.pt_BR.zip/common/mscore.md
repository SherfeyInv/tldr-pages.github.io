# mscore

> Este comando é um apelido de `musescore`.
> Mais informações: <https://musescore.org/handbook/command-line-options>.

- Exibe documentação sobre o comando original:

`tldr musescore`
