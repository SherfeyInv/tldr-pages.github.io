# fc-list

> Exibe todas as fontes disponíveis no sistema.
> Mais informações: <https://manned.org/fc-list>.

- Exibe as fontes instaladas correspondentes ao critério de busca:

`fc-list | grep '{{criterio_de_busca}}'`
