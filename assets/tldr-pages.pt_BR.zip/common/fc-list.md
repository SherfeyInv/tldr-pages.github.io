# fc-list

> Exibe todas as fontes disponíveis no sistema.
> Mais informações: <https://manned.org/fc-list>.

- Retorna uma lista de fontes instaladas no seu sistema:

`fc-list`

- Retorna uma lista de fontes com um dado nome:

`fc-list | grep '{{DejaVu Serif}}'`

- Retorna o número de fontes instaladas no seu sistema:

`fc-list | wc -l`
