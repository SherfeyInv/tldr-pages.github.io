# arp

> Mostrar e manipular a cache ARP do sistema.
> Mais informações: <https://manned.org/arp>.

- Mostra a tabela arp atual:

`arp -a`

- Elimina uma entrada específica:

`arp -d {{endereço}}`

- Cria uma entrada:

`arp -s {{endereço}} {{endereço_mac}}`
