# python3

> Este comando é um apelido de `python`.

- Exibe documentação sobre o comando original:

`tldr python`
