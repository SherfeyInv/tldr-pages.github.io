# batch

> Este comando é um apelido de `at`.

- Exibe documentação sobre o comando original:

`tldr at`
