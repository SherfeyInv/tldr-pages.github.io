# yes

> Exibe algo repetidamente.
> Mais informações: <https://www.gnu.org/software/coreutils/yes>.

- Exibir a palavra "mensagem" repetidamente:

`yes {{mensagem}}`

- Exibir a letra "y" repetidamente:

`yes`

- Aceitar tudo solicitado pelo comando apt-get:

`yes | sudo apt-get install {{programa}}`
