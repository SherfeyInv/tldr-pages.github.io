# xcv

> Corta, copia e cola na linha de comando.
> Mais informações: <https://github.com/busterc/xcv>.

- Corta um arquivo:

`xcv x {{arquivo_a_ser_cortado}}`

- Copia um arquivo:

`xcv c {{arquivo_a_ser_copiado}}`

- Cola um arquivo:

`xcv v {{arquivo_a_ser_colado}}`

- Lista todos os arquivos disponíveis para serem colados:

`xcv l`
