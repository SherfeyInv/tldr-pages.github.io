# freshclam

> Atualiza as definições de vírus para o programa de antivírus ClamAV.
> Mais informações: <https://www.clamav.net>.

- Atualiza as definições de vírus:

`freshclam`
