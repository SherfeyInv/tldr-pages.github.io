# virsh pool-destroy

> Interrompe um pool de armazenamento ativo de máquina virtual.
> Veja também: `virsh`, `virsh-pool-delete`.
> Mais informações: <https://manned.org/virsh>.

- Interrompe um pool de armazenamento especificado pelo nome ou UUID (determinado usando `virsh pool-list`):

`virsh pool-destroy --pool {{nome|uuid}}`
