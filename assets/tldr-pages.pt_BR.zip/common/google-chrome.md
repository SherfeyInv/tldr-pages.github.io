# google-chrome

> Este comando é um apelido de `chromium`.
> Mais informações: <https://chrome.google.com>.

- Exibe documentação sobre o comando original:

`tldr chromium`
