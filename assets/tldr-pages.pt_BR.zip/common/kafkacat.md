# kafkacat

> Este comando é um apelido de `kcat`.

- Exibe documentação sobre o comando original:

`tldr kcat`
