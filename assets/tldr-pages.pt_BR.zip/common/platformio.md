# platformio

> Este comando é um apelido de `pio`.
> Mais informações: <https://docs.platformio.org/en/latest/core/userguide/>.

- Exibe documentação sobre o comando original:

`tldr pio`
