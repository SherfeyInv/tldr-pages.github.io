# platformio

> Este comando é um apelido de `pio`.

- Exibe documentação sobre o comando original:

`tldr pio`
