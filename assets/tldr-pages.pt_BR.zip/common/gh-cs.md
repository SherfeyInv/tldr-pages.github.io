# gh cs

> Este comando é um apelido de `gh codespace`.
> Mais informações: <https://cli.github.com/manual/gh_codespace>.

- Exibe documentação sobre o comando original:

`tldr gh codespace`
