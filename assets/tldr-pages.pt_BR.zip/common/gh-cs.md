# gh cs

> Este comando é um apelido de `gh codespace`.

- Exibe documentação sobre o comando original:

`tldr gh codespace`
