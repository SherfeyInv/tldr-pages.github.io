# cola

> Este comando é um apelido de `git-cola`.

- Exibe documentação sobre o comando original:

`tldr git-cola`
