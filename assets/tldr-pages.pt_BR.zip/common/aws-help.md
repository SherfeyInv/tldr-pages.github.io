# aws help

> Exibe ajuda sobre o AWS CLI.
> Mais informações: <https://docs.aws.amazon.com/cli/latest/userguide/cli-usage-help.html>.

- Exibe a ajuda:

`aws help`

- Lista todos os tópicos disponíveis:

`aws help topics`

- Exibe ajuda sobre um tópico específico:

`aws help {{nome_do_tópico}}`
