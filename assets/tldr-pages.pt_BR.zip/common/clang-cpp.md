# clang-cpp

> Este comando é um apelido de `clang++`.

- Exibe documentação sobre o comando original:

`tldr clang++`
