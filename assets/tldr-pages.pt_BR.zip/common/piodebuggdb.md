# piodebuggdb

> Este comando é um apelido de `pio debug`.

- Exibe documentação sobre o comando original:

`tldr pio debug`
