# ptpython3

> Este comando é um apelido de `ptpython`.

- Exibe documentação sobre o comando original:

`tldr ptpython`
