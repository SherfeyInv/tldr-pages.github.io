# vi

> Este comando é um apelido de `vim`.

- Exibe documentação sobre o comando original:

`tldr vim`
