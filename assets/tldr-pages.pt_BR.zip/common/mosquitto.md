# mosquitto

> Um broker de MQTT.
> Mais informações: <https://mosquitto.org/>.

- Inicia mosquitto:

`mosquitto`

- Especifica um arquivo de configuração para usar:

`mosquitto --config-file {{caminho/para/arquivo.conf}}`

- Escuta em uma porta específica:

`mosquitto --port {{8883}}`

- Cria um processo rodando em background:

`mosquitto --daemon`
