# wordgrinder

> Processador de texto em linha de comando.
> Mais informações: <https://cowlark.com/wordgrinder>.

- Inicia o wordgrinder (carrega um documento vazio por padrão):

`wordgrinder`

- Abre um arquivo específico:

`wordgrinder {{nome_do_arquivo}}`

- Mostra o menu:

`<Alt> + M`
