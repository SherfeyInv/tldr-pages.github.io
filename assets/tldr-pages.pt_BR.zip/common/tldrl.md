# tldrl

> Este comando é um apelido de `tldr-lint`.
> Mais informações: <https://github.com/tldr-pages/tldr-lint>.

- Exibe documentação sobre o comando original:

`tldr tldr-lint`
