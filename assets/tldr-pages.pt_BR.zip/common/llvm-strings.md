# llvm-strings

> Este comando é um apelido de `strings`.

- Exibe documentação sobre o comando original:

`tldr strings`
