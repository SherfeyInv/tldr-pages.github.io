# git stage

> Este comando é um apelido de `git add`.

- Exibe documentação sobre o comando original:

`tldr git add`
