# convert

> Este comando é um alias(apelido) de `magick convert`.
> Nota: esse alias está obsoleto desde ImageMagick 7. Sendo substituído por `magick`.
> Use `magick convert` se precisar usar a ferramenta antiga em versões 7+.
> Mais informações: <https://imagemagick.org/script/convert.php>.

- Veja a documentação para o comando original:

`tldr magick convert`
