# fossil new

> Este comando é um apelido de `fossil init`.

- Exibe documentação sobre o comando original:

`tldr fossil init`
