# pacman4console

> Um jogo de console baseado em texto inspirado no Pacman original.
> Mais informações: <https://github.com/YoctoForBeaglebone/pacman4console>.

- Inicia um jogo no nível 1:

`pacman4console`

- Inicia um jogo em determinado nível (há nove níveis oficiais):

`pacman4console --level={{numero_nivel}}`

- Inicia o editor de níveis do pacman4console, salvando em um arquivo texto especificado:

`pacman4consoleedit {{caminho/para/arquivo_nivel}}`

- Joga um nível personalizado:

`pacman4console --level={{caminho/para/arquivo_nivel}}`
