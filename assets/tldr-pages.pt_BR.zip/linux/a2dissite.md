# a2dissite

> Desativa um host virtual do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manned.org/a2dissite.8>.

- Desativa um host virtual:

`sudo a2dissite {{host_virtual}}`

- Não mostra mensagens informativas:

`sudo a2dissite --quiet {{host_virtual}}`
