# archinstall

> Instalador do Arch Linux guiado com uma torção.
> Mais informações: <https://archinstall.readthedocs.io>.

- Inicia o instalador interativo:

`archinstall`

- Inicia um instalador predefinido:

`archinstall {{minimal|unattended}}`
