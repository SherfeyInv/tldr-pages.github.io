# bspwm

> Um gerenciador de janelas em mosaico baseado em um particionamento de espaço binário.
> Veja também: `bspc`, para controlá-lo.
> Mais informações: <https://github.com/baskerville/bspwm>.

- Inicia `bspwm` (um gerenciador de janelas pré existente não deve estar aberto quando esse comando for executado):

`bspwm -c {{caminho/para/configuracao}}`
