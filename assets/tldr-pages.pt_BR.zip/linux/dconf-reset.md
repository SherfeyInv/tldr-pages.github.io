# dconf reset

> Redefine chaves valores nos bancos de dados dconf.
> Veja também: `dconf`.
> Mais informações: <https://manned.org/dconf>.

- Redefine um valor de chave específico:

`dconf reset {{/caminho/para/chave}}`

- Redefine um diretório específico:

`dconf reset -f {{/caminho/para/diretório/}}`
