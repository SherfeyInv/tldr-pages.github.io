# megadl

> Este comando é um apelido de `megatools-dl`.
> Mais informações: <https://megatools.megous.com/man/megatools-dl.html>.

- Exibe documentação sobre o comando original:

`tldr megatools-dl`
