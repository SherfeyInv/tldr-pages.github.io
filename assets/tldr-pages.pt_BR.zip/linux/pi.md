# pi

> Calcula a constante decimal de Arquimedes Pi na linha de comando.
> Mais informações: <https://manned.org/pi>.

- Exibe 100 dígitos decimais da constante de Archimedes Pi:

`pi`

- Exibe um número específico de dígitos decimais da constante de Archimedes Pi:

`pi {{number}}`

- Exibe leituras recomendadas:

`pi --bibliography`

- Exibe ajuda:

`pi --help`

- Exibe a versão:

`pi --version`
