# cc

> Este comando é um apelido de `gcc`.
> Mais informações: <https://gcc.gnu.org>.

- Exibe documentação sobre o comando original:

`tldr gcc`
