# ip route list

> Este comando é um apelido de  `ip route show`.

- Exibe documentação sobre o comando original:

`tldr ip-route-show`
