# fatlabel

> Define ou exibe o rótulo de uma partição FAT32.
> Mais informações: <https://manned.org/fatlabel>.

- Exibe o rótulo de uma partição FAT32:

`fatlabel {{/dev/sda1}}`

- Define o rótulo de uma partição FAT32:

`fatlabel {{/dev/sdc3}} "{{rotulo}}"`
