# cpuid

> Exibe informações detalhadas sobre todas as CPUs.
> Mais informações: <http://etallen.com/cpuid.html>.

- Exibe informações de todas as CPUs:

`cpuid`

- Exibe informações apenas da CPU atual:

`cpuid -1`

- Exibe informações em hexadecimal sem decodificação:

`cpuid -r`
