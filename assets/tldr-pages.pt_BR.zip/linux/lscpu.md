# lscpu

> Exibe informações sobre a arquitetura da CPU.
> Mais informações: <https://manned.org/lscpu>.

- Exibe informações sobre todas as CPUs:

`lscpu`

- Exibe informações em uma tabela:

`lscpu --extended`

- Exibe apenas informações sobre CPUs desligadas em uma tabela:

`lscpu --extended --offline`
