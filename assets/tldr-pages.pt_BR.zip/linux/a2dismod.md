# a2dismod

> Desativa um módulo do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manned.org/a2dismod.8>.

- Desativa um módulo:

`sudo a2dismod {{módulo}}`

- Não mostra mensagens informativas:

`sudo a2dismod --quiet {{módulo}}`
