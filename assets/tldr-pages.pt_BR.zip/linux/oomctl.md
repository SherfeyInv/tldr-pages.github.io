# oomctl

> Analise o estado armazenado no `systemd-oomd`.
> Mais informações: <https://www.freedesktop.org/software/systemd/man/oomctl.html>.

- Mostra o estado atual dos contextos de cgroups e do sistema armazenados pelo `systemd-oomd`:

`oomctl dump`
