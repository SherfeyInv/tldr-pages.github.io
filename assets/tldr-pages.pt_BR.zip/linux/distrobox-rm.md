# distrobox-rm

> Remover um contêiner Distrobox.
> Subcomando de `distrobox`. Veja também: `tldr distrobox`.
> Mais informações: <https://distrobox.it/usage/distrobox-rm>.

- Remove um contêiner Distrobox (Dica: Pare o contêiner antes de removê-lo):

`distrobox-rm {{nome_do_contêiner}}`

- Remove um contêiner Distrobox forçadamente:

`distrobox-rm {{nome_do_contêiner}} --force`
