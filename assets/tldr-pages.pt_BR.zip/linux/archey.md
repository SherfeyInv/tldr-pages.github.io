# archey

> Ferramenta que exibe informações do sistema de forma estilizada.
> Mais informações: <https://lclarkmichalek.github.io/archey3/>.

- Exibe as informações do sistema:

`archey`
