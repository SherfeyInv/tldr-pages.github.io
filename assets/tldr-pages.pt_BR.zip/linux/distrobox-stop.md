# distrobox-stop

> Parar um contêiner Distrobox.
> Subcomando de `distrobox`. Veja também: `tldr distrobox`.
> Mais informações: <https://distrobox.it/usage/distrobox-stop>.

- Para um contêiner Distrobox:

`distrobox-stop {{nome_do_contêiner}}`

- Para um contêiner Distrobox de forma não interativa (sem confirmação):

`distrobox-stop --name {{nome_do_contêiner}} --yes`
