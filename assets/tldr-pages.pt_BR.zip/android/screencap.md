# screencap

> Tira uma scrennshot do display mobile.
> Este comando apenas pode ser usado atraves de `adb shell`.
> Mais informações: <https://developer.android.com/tools/adb#screencap>.

- Tira uma screenshot:

`screencap {{caminho/para/arquivo}}`
