# dalvikvm

> A máquina virtual Java do Android.
> Mais informações: <https://source.android.com/docs/core/runtime>.

- Inicia um programa Java:

`dalvikvm -classpath {{caminho/para/arquivo.jar}} {{nome_da_classe}}`
