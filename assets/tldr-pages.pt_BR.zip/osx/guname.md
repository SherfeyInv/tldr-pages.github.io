# guname

> Este comando é um apelido de `-p linux uname`.

- Exibe documentação sobre o comando original:

`tldr -p linux uname`
