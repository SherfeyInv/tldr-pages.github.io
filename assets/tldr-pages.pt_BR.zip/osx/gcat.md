# gcat

> Este comando é um apelido de `-p linux cat`.

- Exibe documentação sobre o comando original:

`tldr -p linux cat`
