# gpathchk

> Este comando é um apelido de `-p linux pathchk`.

- Exibe documentação sobre o comando original:

`tldr -p linux pathchk`
