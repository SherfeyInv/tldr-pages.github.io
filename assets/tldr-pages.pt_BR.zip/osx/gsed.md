# gsed

> Este comando é um apelido de `-p linux sed`.

- Exibe documentação sobre o comando original:

`tldr -p linux sed`
