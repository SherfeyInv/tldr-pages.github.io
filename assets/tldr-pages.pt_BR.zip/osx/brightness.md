# brightness

> Obtém e define o nível de brilho de todos os monitores internos e alguns monitores externos.
> Mais informações: <https://github.com/nriley/brightness>.

- Mostra o brilho atual:

`brightness -l`

- Define o brilho para 100%:

`brightness {{1}}`

- Define o brilho para 50%:

`brightness {{0.5}}`
