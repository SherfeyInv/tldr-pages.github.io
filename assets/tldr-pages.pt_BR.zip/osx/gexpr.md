# gexpr

> Este comando é um apelido de `-p linux expr`.

- Exibe documentação sobre o comando original:

`tldr -p linux expr`
