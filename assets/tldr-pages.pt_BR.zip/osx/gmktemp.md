# gmktemp

> Este comando é um apelido de `-p linux mktemp`.

- Exibe documentação sobre o comando original:

`tldr -p linux mktemp`
