# gtruncate

> Este comando é um apelido de `-p linux truncate`.

- Exibe documentação sobre o comando original:

`tldr -p linux truncate`
