# gsha512sum

> Este comando é um apelido de `-p linux sha512sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux sha512sum`
