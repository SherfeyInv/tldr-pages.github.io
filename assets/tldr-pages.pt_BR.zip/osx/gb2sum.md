# gb2sum

> Este comando é um apelido de `-p linux b2sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux b2sum`
