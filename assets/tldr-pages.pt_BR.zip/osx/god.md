# god

> Este comando é um apelido de `-p linux od`.

- Exibe documentação sobre o comando original:

`tldr -p linux od`
