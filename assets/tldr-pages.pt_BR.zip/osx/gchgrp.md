# gchgrp

> Este comando é um apelido de `-p linux chgrp`.

- Exibe documentação sobre o comando original:

`tldr -p linux chgrp`
