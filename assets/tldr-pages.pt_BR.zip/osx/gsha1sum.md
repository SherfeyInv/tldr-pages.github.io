# gsha1sum

> Este comando é um apelido de `-p linux sha1sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux sha1sum`
