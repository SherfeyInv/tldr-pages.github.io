# aa

> Este comando é um alias de `yaa`.

- Veja a documentação do comando original:

`tldr yaa`
