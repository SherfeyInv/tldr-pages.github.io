# gegrep

> Este comando é um apelido de `-p linux egrep`.

- Exibe documentação sobre o comando original:

`tldr -p linux egrep`
