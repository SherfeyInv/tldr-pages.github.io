# cfprefsd

> Fornece serviços de preferências (`CFPreferences`, `NSUserDefaults`).
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/cfprefsd.8.html>.

- Inicia o daemon:

`cfprefsd`
