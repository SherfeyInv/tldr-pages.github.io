# gbasenc

> Este comando é um apelido de `-p linux basenc`.

- Exibe documentação sobre o comando original:

`tldr -p linux basenc`
