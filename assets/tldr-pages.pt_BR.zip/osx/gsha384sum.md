# gsha384sum

> Este comando é um apelido de `-p linux sha384sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux sha384sum`
