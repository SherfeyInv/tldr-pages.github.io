# gsha256sum

> Este comando é um apelido de `-p linux sha256sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux sha256sum`
