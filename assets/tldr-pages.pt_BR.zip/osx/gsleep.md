# gsleep

> Este comando é um apelido de `-p linux sleep`.

- Exibe documentação sobre o comando original:

`tldr -p linux sleep`
