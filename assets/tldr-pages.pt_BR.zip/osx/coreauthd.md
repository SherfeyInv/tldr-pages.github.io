# coreauthd

> Um daemon de sistema que fornece o framework `LocalAuthentication`.
> Não deve ser invocado manualmente. Veja também: `coreautha`.
> Mais informações: <https://keith.github.io/xcode-man-pages/coreauthd.8.html>.

- Inicia o daemon:

`coreauthd`
