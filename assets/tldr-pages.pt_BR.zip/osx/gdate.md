# gdate

> Este comando é um apelido de `-p linux date`.

- Exibe documentação sobre o comando original:

`tldr -p linux date`
