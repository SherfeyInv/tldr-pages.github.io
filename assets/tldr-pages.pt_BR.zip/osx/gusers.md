# gusers

> Este comando é um apelido de `-p linux users`.

- Exibe documentação sobre o comando original:

`tldr -p linux users`
