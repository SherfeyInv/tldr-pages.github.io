# gstdbuf

> Este comando é um apelido de `-p linux stdbuf`.

- Exibe documentação sobre o comando original:

`tldr -p linux stdbuf`
