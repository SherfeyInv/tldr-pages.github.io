# launchd

> Este comando gerencia processo, tanto do sistema quanto de usuários.
> Você não pode invocar launchd manualmente, use launchctl para interagir com ele.
> Mais informações: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Executa init:

`/sbin/launchd`

- Exibe documentação sobre a interação com launchd por meio do launchctl:

`tldr launchctl`
