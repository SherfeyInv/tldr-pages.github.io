# automountd

> Um daemon de montagem/desmontagem automática para `autofs`. Iniciado sob demanda por `launchd`.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/automountd.8.html>.

- Inicia o daemon:

`automountd`

- Log de mais detalhes em `syslog`:

`automountd -v`
