# deleted

> Acompanha o espaço purgável e solicita que os clientes removam os arquivos quando o espaço estiver baixo.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/deleted.8.html>.

- Inicia o daemon:

`deleted`
