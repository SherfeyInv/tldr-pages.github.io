# glink

> Este comando é um apelido de `-p linux link`.

- Exibe documentação sobre o comando original:

`tldr -p linux link`
