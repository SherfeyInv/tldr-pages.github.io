# gtee

> Este comando é um apelido de `-p linux tee`.

- Exibe documentação sobre o comando original:

`tldr -p linux tee`
