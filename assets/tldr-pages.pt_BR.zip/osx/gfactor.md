# gfactor

> Este comando é um apelido de `-p linux factor`.

- Exibe documentação sobre o comando original:

`tldr -p linux factor`
