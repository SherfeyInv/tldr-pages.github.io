# bnepd

> Serviço que lida com todas as conexões de rede Bluetooth.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/bnepd.8.html>.

- Inicia o daemon:

`bnepd`
