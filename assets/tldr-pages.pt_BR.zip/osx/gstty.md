# gstty

> Este comando é um apelido de `-p linux stty`.

- Exibe documentação sobre o comando original:

`tldr -p linux stty`
