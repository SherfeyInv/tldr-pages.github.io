# apachectl

> Interface de controle do Servidor HTTP Apache para macOS.
> Mais informações: <https://keith.github.io/xcode-man-pages/apachectl.8.html>.

- Inicia o job launchd `org.apache.httpd`:

`apachectl start`

- Para o job launchd:

`apachectl stop`

- Para, e então inicia o job launchd:

`apachectl restart`
