# gfind

> Este comando é um apelido de `-p linux find`.

- Exibe documentação sobre o comando original:

`tldr -p linux find`
