# gtsort

> Este comando é um apelido de `-p linux tsort`.

- Exibe documentação sobre o comando original:

`tldr -p linux tsort`
