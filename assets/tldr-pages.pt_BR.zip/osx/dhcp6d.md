# dhcp6d

> Servidor DHCPv6 stateless. Veja também: `InternetSharing`.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/dhcp6d/>.

- Inicia o daemon:

`dhcp6d`

- Usa uma configuração personalizada:

`dhcp6d {{caminho/para/configuração}}`
