# gtr

> Este comando é um apelido de `-p linux tr`.

- Exibe documentação sobre o comando original:

`tldr -p linux tr`
