# gbase32

> Este comando é um apelido de `-p linux base32`.

- Exibe documentação sobre o comando original:

`tldr -p linux base32`
