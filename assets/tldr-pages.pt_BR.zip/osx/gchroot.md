# gchroot

> Este comando é um apelido de `-p linux chroot`.

- Exibe documentação sobre o comando original:

`tldr -p linux chroot`
