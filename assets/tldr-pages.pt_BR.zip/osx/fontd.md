# fontd

> Disponibiliza fontes para o sistema.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/fontd.8.html>.

- Inicia o daemon:

`fontd`
