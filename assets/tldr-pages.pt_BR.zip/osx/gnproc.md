# gnproc

> Este comando é um apelido de `-p linux nproc`.

- Exibe documentação sobre o comando original:

`tldr -p linux nproc`
