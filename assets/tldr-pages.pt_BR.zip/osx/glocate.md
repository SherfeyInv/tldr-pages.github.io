# glocate

> Este comando é um apelido de `-p linux locate`.

- Exibe documentação sobre o comando original:

`tldr -p linux locate`
