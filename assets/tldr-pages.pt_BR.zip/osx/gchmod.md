# gchmod

> Este comando é um apelido de `-p linux chmod`.

- Exibe documentação sobre o comando original:

`tldr -p linux chmod`
