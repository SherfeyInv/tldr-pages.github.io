# gnice

> Este comando é um apelido de `-p linux nice`.

- Exibe documentação sobre o comando original:

`tldr -p linux nice`
