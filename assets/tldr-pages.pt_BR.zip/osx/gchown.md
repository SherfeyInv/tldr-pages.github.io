# gchown

> Este comando é um apelido de `-p linux chown`.

- Exibe documentação sobre o comando original:

`tldr -p linux chown`
