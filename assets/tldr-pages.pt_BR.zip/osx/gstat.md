# gstat

> Este comando é um apelido de `-p linux stat`.

- Exibe documentação sobre o comando original:

`tldr -p linux stat`
