# guniq

> Este comando é um apelido de `-p linux uniq`.

- Exibe documentação sobre o comando original:

`tldr -p linux uniq`
