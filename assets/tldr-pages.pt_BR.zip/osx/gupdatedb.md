# gupdatedb

> Este comando é um apelido de `-p linux updatedb`.

- Exibe documentação sobre o comando original:

`tldr -p linux updatedb`
