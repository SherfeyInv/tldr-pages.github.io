# gdd

> Este comando é um apelido de `-p linux dd`.

- Exibe documentação sobre o comando original:

`tldr -p linux dd`
