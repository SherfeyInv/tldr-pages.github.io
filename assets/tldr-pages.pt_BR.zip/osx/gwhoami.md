# gwhoami

> Este comando é um apelido de `-p linux whoami`.

- Exibe documentação sobre o comando original:

`tldr -p linux whoami`
