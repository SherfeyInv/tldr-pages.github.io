# ghostid

> Este comando é um apelido de `-p linux hostid`.

- Exibe documentação sobre o comando original:

`tldr -p linux hostid`
