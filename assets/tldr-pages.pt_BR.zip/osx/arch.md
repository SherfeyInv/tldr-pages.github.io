# arch

> Exibe o nome da arquitetura do sistema ou executa um comando em uma arquitetura diferente.
> Veja também: `uname`.
> Mais informações: <https://keith.github.io/xcode-man-pages/arch.1.html>.

- Exibe o nome da arquitetura do sistema:

`arch`

- Executa um comando usando a arquitetura x86_64:

`arch -x86_64 "{{comando}}"`

- Executa um comando usando arm:

`arch -arm64 "{{comando}}"`
