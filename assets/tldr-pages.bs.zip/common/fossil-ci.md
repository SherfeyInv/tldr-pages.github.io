# fossil ci

> Ova komanda je pseudonim za  `fossil commit`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil commit`
