# clojure

> Ova komanda je pseudonim za `clj`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr clj`
