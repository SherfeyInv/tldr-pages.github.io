# platformio

> Ova komanda je pseudonim za `pio`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr pio`
