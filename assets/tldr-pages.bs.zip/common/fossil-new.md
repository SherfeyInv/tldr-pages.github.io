# fossil new

> Ova komanda je pseudonim za  `fossil init`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil init`
