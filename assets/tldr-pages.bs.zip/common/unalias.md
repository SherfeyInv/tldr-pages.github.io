# unalias

> Ukloni pseudonime.
> Više informacija: <https://manned.org/unalias>.

- Ukloni pseudonim:

`unalias {{ime_alijasa}}`

- Ukloni sve pseudonime:

`unalias -a`
