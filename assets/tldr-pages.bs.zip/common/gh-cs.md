# gh cs

> Ova komanda je pseudonim za  `gh codespace`.
> Više informacija: <https://cli.github.com/manual/gh_codespace>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gh-codespace`
