# gh cs

> Ova komanda je pseudonim za `gh codespace`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gh codespace`
