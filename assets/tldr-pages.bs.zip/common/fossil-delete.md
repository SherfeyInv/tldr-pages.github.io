# fossil delete

> Ova komanda je pseudonim za `fossil rm`.
> Više informacija: <https://fossil-scm.org/home/help/delete>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil rm`
