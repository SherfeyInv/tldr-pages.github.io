# llvm-objdump

> Ova komanda je pseudonim za `objdump`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr objdump`
