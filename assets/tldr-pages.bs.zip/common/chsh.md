# chsh

> Promijeni korisnički login shell.
> Više informacija: <https://manned.org/chsh>.

- Promijeni shell:

`chsh -s {{putanja/do/shell_binarni}} {{korisničkoime}}`
