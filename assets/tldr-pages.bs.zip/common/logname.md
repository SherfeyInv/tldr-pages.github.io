# logname

> Prikazuje ime prijevljenog korisnika.
> Više informacija: <https://www.gnu.org/software/coreutils/logname>.

- Prikaži ime trenutno prijavljenog korisnika:

`logname`
