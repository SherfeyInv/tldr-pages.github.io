# tlmgr arch

> Ova komanda je pseudonim za `tlmgr platform`.
> Više informacija: <https://www.tug.org/texlive/tlmgr.html>.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr tlmgr platform`
