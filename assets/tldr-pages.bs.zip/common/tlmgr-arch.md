# tlmgr arch

> Ova komanda je pseudonim za `tlmgr platform`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr tlmgr platform`
