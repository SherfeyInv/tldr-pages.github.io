# gnmic sub

> Ova komanda je pseudonim za `gnmic subscribe`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gnmic subscribe`
