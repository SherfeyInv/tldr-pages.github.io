# zless

> Pregledaj kompresovane datoteke.
> Više informacija: <https://manned.org/zless>.

- Prelistaj kroz kompresovanu arhivu sa `less`:

`zless {{fajl.txt.gz}}`
