# ncal

> Ova komanda je pseudonim za `cal`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr cal`
