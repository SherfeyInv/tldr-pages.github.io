# sls

> Ova komanda je pseudonim za `Select-String`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr select-string`
