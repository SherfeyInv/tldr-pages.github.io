# cuninst

> Ova komanda je pseudonim za `choco uninstall`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco uninstall`
