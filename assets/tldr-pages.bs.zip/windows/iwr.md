# iwr

> Ova komanda je pseudonim za `invoke-webrequest`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr invoke-webrequest`
