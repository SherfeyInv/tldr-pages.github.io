# cinst

> Ova komanda je pseudonim za `choco install`.
> Više informacija: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco install`
