# pwsh where

> Ova komanda je pseudonim za `Where-Object`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr Where-Object`
