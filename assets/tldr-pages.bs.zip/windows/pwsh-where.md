# pwsh where

> Ova komanda je pseudonim za `Where-Object`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr Where-Object`
