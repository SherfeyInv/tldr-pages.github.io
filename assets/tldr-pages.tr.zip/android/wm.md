# wm

> Bir Android cihazının ekranı ile ilgili bilgi göster.
> Bu komut yalnızca `adb shell` ile kullanılabilir.
> Daha fazla bilgi için: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Bir Android cihazının ekranının fiziksel boyutunu görüntüle:

`wm size`

- Bir Android cihazının ekranının fiziksel derinliğini görüntüle:

`wm density`
