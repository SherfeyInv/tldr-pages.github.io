# bugreport

> Bir Android bug raporu göster.
> Bu komut yalnızca `adb shell` ile kullanılabilir.
> Daha fazla bilgi için: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Bir Android cihazı için eksizsiz bug raporu göster:

`bugreport`
