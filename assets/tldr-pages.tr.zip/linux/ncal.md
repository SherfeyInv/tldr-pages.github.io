# ncal

> Bu komut `cal` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/ncal>.

- Asıl komutun belgelerini görüntüleyin:

`tldr cal`
