# alternatives

> Bu komut `update-alternatives` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/alternatives>.

- Asıl komutun belgelerini görüntüleyin:

`tldr update-alternatives`
