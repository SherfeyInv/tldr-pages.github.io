# ubuntu-bug

> Bu komut `apport-bug` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/ubuntu-bug>.

- Asıl komutun belgelerini görüntüleyin:

`tldr apport-bug`
