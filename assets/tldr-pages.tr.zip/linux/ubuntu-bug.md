# ubuntu-bug

> Bu komut `apport-bug` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr apport-bug`
