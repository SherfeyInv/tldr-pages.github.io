# xeyes

> Ekranda fare imlecini takip eden bir çift göz göster.
> Daha fazla bilgi için: <https://manned.org/xeyes>.

- Xeyes'ı yerel makinenin varsayılan ekranında başlat:

`xeyes`

- Xeyes'ı uzak bir makinenin 0. görüntü ve 0. ekran koordinatlarında başlat:

`xeyes -display {{uzak_makine}}:{{0}}.{{0}}`
