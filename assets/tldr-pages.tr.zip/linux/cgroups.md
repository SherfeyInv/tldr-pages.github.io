# cgroups

> Bu komut `cgclassify` için bir takma addır.
> Daha fazla bilgi için: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Asıl komutun belgelerini görüntüleyin:

`tldr cgclassify`
