# megadl

> Bu komut `megatools-dl` için bir takma addır.
> Daha fazla bilgi için: <https://megatools.megous.com/man/megatools-dl.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr megatools-dl`
