# megadl

> Bu komut `megatools-dl` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr megatools-dl`
