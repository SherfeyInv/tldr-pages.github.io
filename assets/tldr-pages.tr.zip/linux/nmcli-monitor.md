# nmcli monitor

> NetworkManager bağlantı durumundaki değişiklikleri izleyin.
> Daha fazla bilgi için: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- NetworkManager değişikliklerini izlemeye başla:

`nmcli monitor`
