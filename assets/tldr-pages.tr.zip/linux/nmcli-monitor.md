# nmcli monitor

> NetworkManager bağlantı durumundaki değişiklikleri izleyin.
> Daha fazla bilgi için: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- NetworkManager değişikliklerini izlemeye başla:

`nmcli monitor`
