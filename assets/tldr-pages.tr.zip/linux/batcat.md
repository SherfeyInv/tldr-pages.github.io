# batcat

> Bu komut `bat` için bir takma addır.
> Daha fazla bilgi için: <https://github.com/sharkdp/bat>.

- Asıl komutun belgelerini görüntüleyin:

`tldr bat`
