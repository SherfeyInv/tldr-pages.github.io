# a2ensite

> Debian tabanlı işletim sistemlerinde Apache sanal hostu etkinleştir.
> Daha fazla bilgi için: <https://manned.org/a2ensite.8>.

- Bir sanal hostu etkinleştir:

`sudo a2ensite {{sanal_host}}`

- Bilgilendirici mesajları gösterme:

`sudo a2ensite --quiet {{sanal_host}}`
