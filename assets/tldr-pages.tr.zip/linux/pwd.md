# pwd

> Mevcut/çalışan dizinin ismini yazdır.
> Daha fazla bilgi için: <https://www.gnu.org/software/coreutils/pwd>.

- Mevcut dizini yazdır:

`pwd`

- Mevcut dizini yazdır ve tüm symlink'leri çöz (yani "fiziksel" yolu göster):

`pwd --physical`

- Mevcut mantıksal dizini yazdır:

`pwd --logical`
