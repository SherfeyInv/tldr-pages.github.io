# a2dismod

> Debian tabanlı işletim sistemlerinde bir Apache modülünü devre dışı bırak.
> Daha fazla bilgi için: <https://manned.org/a2dismod.8>.

- Bir modülü devre dışı bırak:

`sudo a2dismod {{modül}}`

- Bilgilendirici mesajları gösterme:

`sudo a2dismod --quiet {{module}}`
