# cinst

> Bu komut `choco install` için bir takma addır.
> Daha fazla bilgi için: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco install`
