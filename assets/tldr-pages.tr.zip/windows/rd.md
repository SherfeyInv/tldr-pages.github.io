# rd

> Bu komut `rmdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr rmdir`
