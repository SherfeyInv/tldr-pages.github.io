# sls

> Bu komut `Select-String` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr select-string`
