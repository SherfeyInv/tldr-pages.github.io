# sls

> Bu komut `Select-String` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Asıl komutun belgelerini görüntüleyin:

`tldr select-string`
