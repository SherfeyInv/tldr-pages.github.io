# iwr

> Bu komut `invoke-webrequest` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Asıl komutun belgelerini görüntüleyin:

`tldr invoke-webrequest`
