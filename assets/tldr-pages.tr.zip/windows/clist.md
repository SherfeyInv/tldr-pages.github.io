# clist

> Bu komut `choco list` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco list`
