# gchroot

> Bu komut `-p linux chroot` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux chroot`
