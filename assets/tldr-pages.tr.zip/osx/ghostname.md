# ghostname

> Bu komut `-p linux hostname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux hostname`
