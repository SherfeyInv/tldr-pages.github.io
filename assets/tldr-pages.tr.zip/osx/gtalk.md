# gtalk

> Bu komut `-p linux talk` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux talk`
