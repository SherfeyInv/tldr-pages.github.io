# gdf

> Bu komut `-p linux df` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux df`
