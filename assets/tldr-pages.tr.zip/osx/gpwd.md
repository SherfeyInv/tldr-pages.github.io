# gpwd

> Bu komut `-p linux pwd` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux pwd`
