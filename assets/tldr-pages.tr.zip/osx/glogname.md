# glogname

> Bu komut `-p linux logname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux logname`
