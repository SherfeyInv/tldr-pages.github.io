# gsed

> Bu komut `-p linux sed` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sed`
