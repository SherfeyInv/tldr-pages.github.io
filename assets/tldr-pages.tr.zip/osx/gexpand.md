# gexpand

> Bu komut `-p linux expand` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux expand`
