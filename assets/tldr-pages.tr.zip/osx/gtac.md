# gtac

> Bu komut `-p linux tac` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tac`
