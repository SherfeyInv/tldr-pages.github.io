# guname

> Bu komut `-p linux uname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux uname`
