# gsha512sum

> Bu komut `-p linux sha512sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sha512sum`
