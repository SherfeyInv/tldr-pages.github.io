# gpathchk

> Bu komut `-p linux pathchk` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux pathchk`
