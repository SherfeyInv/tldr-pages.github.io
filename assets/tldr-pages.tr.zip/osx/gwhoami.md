# gwhoami

> Bu komut `-p linux whoami` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux whoami`
