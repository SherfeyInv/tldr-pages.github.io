# gsort

> Bu komut `-p linux sort` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sort`
