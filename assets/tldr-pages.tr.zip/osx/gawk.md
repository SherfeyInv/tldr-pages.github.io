# gawk

> Bu komut `-p linux awk` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux awk`
