# gdirname

> Bu komut `-p linux dirname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux dirname`
