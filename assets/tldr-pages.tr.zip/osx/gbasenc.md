# gbasenc

> Bu komut `-p linux basenc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux basenc`
