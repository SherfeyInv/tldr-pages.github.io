# gtar

> Bu komut `-p linux tar` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tar`
