# guptime

> Bu komut `-p linux uptime` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux uptime`
