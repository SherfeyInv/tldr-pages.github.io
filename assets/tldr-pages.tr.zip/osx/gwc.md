# gwc

> Bu komut `-p linux wc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux wc`
