# gdd

> Bu komut `-p linux dd` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux dd`
