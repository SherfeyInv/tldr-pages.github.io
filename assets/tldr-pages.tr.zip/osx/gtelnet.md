# gtelnet

> Bu komut `-p linux telnet` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux telnet`
