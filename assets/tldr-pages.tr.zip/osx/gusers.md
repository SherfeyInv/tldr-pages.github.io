# gusers

> Bu komut `-p linux users` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux users`
