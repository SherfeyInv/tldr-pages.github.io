# gcut

> Bu komut `-p linux cut` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux cut`
