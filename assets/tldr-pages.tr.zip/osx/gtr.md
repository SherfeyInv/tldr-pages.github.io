# gtr

> Bu komut `-p linux tr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tr`
