# genv

> Bu komut `-p linux env` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux env`
