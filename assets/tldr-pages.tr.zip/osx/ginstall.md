# ginstall

> Bu komut `-p linux install` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux install`
