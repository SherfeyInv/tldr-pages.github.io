# gkill

> Bu komut `-p linux kill` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux kill`
