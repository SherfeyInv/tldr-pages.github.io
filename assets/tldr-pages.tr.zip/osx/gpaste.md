# gpaste

> Bu komut `-p linux paste` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux paste`
