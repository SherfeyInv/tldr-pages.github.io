# gb2sum

> Bu komut `-p linux b2sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux b2sum`
