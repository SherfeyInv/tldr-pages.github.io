# gmd5sum

> Bu komut `-p linux md5sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux md5sum`
