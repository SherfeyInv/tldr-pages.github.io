# gcp

> Bu komut `-p linux cp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux cp`
