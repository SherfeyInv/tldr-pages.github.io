# gtsort

> Bu komut `-p linux tsort` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tsort`
