# gftp

> Bu komut `-p linux ftp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ftp`
