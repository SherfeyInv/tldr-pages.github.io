# gupdatedb

> Bu komut `-p linux updatedb` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux updatedb`
