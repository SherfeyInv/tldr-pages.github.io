# gprintf

> Bu komut `-p linux printf` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux printf`
