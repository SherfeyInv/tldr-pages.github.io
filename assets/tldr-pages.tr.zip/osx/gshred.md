# gshred

> Bu komut `-p linux shred` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux shred`
