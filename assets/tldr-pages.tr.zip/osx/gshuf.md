# gshuf

> Bu komut `-p linux shuf` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux shuf`
