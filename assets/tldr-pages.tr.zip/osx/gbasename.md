# gbasename

> Bu komut `-p linux basename` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux basename`
