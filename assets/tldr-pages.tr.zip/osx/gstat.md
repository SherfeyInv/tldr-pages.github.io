# gstat

> Bu komut `-p linux stat` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux stat`
