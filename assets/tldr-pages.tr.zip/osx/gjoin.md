# gjoin

> Bu komut `-p linux join` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux join`
