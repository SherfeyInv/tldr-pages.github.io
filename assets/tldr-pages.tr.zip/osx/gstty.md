# gstty

> Bu komut `-p linux stty` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux stty`
