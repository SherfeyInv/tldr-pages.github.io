# gls

> Bu komut `-p linux ls` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ls`
