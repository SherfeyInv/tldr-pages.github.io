# gsha256sum

> Bu komut `-p linux sha256sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sha256sum`
