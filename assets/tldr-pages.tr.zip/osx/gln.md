# gln

> Bu komut `-p linux ln` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ln`
