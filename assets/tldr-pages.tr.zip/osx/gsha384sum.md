# gsha384sum

> Bu komut `-p linux sha384sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sha384sum`
