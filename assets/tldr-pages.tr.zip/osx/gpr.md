# gpr

> Bu komut `-p linux pr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux pr`
