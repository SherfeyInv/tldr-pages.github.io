# gifconfig

> Bu komut `-p linux ifconfig` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ifconfig`
