# gunits

> Bu komut `-p linux units` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux units`
