# gecho

> Bu komut `-p linux echo` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux echo`
