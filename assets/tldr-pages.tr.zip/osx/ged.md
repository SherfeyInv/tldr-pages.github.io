# ged

> Bu komut `-p linux ed` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ed`
