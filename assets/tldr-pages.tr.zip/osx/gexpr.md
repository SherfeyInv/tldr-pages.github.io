# gexpr

> Bu komut `-p linux expr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux expr`
