# gfalse

> Bu komut `-p linux false` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux false`
