# gtruncate

> Bu komut `-p linux truncate` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux truncate`
