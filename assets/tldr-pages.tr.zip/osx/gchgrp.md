# gchgrp

> Bu komut `-p linux chgrp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux chgrp`
