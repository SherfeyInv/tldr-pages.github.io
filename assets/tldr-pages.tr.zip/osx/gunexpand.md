# gunexpand

> Bu komut `-p linux unexpand` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux unexpand`
