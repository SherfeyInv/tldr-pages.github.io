# gruncon

> Bu komut `-p linux runcon` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux runcon`
