# gmkdir

> Bu komut `-p linux mkdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux mkdir`
