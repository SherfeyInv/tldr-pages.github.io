# gwho

> Bu komut `-p linux who` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux who`
