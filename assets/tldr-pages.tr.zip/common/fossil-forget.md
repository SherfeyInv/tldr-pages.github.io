# fossil forget

> Bu komut `fossil rm` için bir takma addır.
> Daha fazla bilgi için: <https://fossil-scm.org/home/help/forget>.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil rm`
