# rcat

> Bu komut `rc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr rc`
