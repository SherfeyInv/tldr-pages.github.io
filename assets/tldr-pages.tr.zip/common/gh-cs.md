# gh cs

> Bu komut `gh codespace`.için bir takma addır.
> Daha fazla bilgi için: <https://cli.github.com/manual/gh_codespace>.

- Asıl komutun belgelerini görüntüleyin:

`tldr gh codespace`
