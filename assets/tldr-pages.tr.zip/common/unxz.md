# unxz

> Bu komut `xz` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr xz`
