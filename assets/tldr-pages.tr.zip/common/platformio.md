# platformio

> Bu komut `pio` için bir takma addır.
> Daha fazla bilgi için: <https://docs.platformio.org/en/latest/core/userguide/>.

- Asıl komutun belgelerini görüntüleyin:

`tldr pio`
