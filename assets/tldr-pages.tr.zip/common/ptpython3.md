# ptpython3

> Bu komut `ptpython` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ptpython`
