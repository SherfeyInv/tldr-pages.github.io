# anki

> Güçlü ve akıllı bir aralıklı tekrar programı.
> Daha fazla bilgi için: <https://docs.ankiweb.net>.

- Çalıştır:

`anki`

- Belirtilen bir profil ismi ile çalıştır:

`anki -p {{profil_ismi}}`

- Belirtilen bir dil ile çalıştır:

`anki -l {{dil}}`

- Belirtilen bir dizinden (konumdan) calıştır:

`anki -b {{dizin/yolu}}`
