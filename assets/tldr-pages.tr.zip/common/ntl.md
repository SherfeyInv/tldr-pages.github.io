# ntl

> Bu komut `netlify` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr netlify`
