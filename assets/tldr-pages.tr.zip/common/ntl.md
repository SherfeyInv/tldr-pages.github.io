# ntl

> Bu komut `netlify` için bir takma addır.
> Daha fazla bilgi için: <https://cli.netlify.com>.

- Asıl komutun belgelerini görüntüleyin:

`tldr netlify`
