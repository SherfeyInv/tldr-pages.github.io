# fossil ci

> Bu komut `fossil commit` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil commit`
