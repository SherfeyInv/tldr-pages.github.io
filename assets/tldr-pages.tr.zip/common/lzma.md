# lzma

> Bu komut `xz` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/lzma>.

- Asıl komutun belgelerini görüntüleyin:

`tldr xz`
