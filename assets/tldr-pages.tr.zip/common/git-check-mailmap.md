# git check-mailmap

> Bağlantıların kanonik isimleri ve e-posta adreslerini göster.
> Daha fazla bilgi için: <https://git-scm.com/docs/git-check-mailmap>.

- Bir e-posta adresi ile eşleşen kanonik ismi bul:

`git check-mailmap "<{{örnek@e-posta.com}}>"`
