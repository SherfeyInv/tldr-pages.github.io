# fossil delete

> Bu komut `fossil rm` için bir takma addır.
> Daha fazla bilgi için: <https://fossil-scm.org/home/help/delete>.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil rm`
