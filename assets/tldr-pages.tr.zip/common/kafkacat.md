# kafkacat

> Bu komut `kcat` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr kcat`
