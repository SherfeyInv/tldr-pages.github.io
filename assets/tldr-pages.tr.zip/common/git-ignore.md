# git ignore

> Önceden belirlenmiş şablonlarla .gitignore dosyaları oluştur.
> Daha fazla bilgi için: <https://github.com/tj/git-extras/blob/master/Commands.md#git-ignore>.

- Mevzut şablonları sırala:

`git ignore list`

- Bir .gitignore şablonu oluştur:

`git ignore {{nesne_a,nesne_b,nesne_n}}`
