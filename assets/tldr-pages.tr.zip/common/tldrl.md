# tldrl

> `tldr-lint` komutunun aynısı.
> Daha fazla bilgi için: <https://github.com/tldr-pages/tldr-lint>.

- Orijinal komut için yardım sayfasını göster:

`tldr tldr-lint`
