# tldrl

> `tldr-lint` komutunun aynısı.

- Orijinal komut için yardım sayfasını göster:

`tldr tldr-lint`
