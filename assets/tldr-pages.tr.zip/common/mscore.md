# mscore

> Bu komut `musescore` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr musescore`
