# hx

> Bu komut `helix` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr helix`
