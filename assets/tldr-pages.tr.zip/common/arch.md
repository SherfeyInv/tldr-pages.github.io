# arch

> Sistem mimarisinin ismini göster.
> Ayrıca bakınız: `uname`.
> Daha fazla bilgi için: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Sistemin mimarisini göster:

`arch`
