# arch

> Sistem mimarisinin ismini göster.
> Ayrıca bakınız: `uname`.
> Daha fazla bilgi için: <https://www.gnu.org/software/coreutils/arch>.

- Sistemin mimarisini göster:

`arch`
