# vi

> Bu komut `vim` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr vim`
