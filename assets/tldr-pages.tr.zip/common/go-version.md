# go version

> Go sürümünü yazdır.
> Daha fazla bilgi için: <https://golang.org/cmd/go/#hdr-Print_Go_version>.

- Go sürümünü yazdır:

`go version`

- Belirtilen çalıştırılabilir dosyanın yapımı için kullanılan Go sürümünü yazdır:

`go version {{örnek/konum/çalıştırılabilir_dosya}}`
