# git ls-files

> İndex ve mevcut ağaçtaki dosyalar hakkında bilgi göster.
> Daha fazla bilgi için: <https://git-scm.com/docs/git-ls-files>.

- Silinen dosyaları göster:

`git ls-files --deleted`

- Düzenlenen ve silinen dosyaları göster:

`git ls-files --modified`

- Yoksayılmış ve izlenmeyen dosyaları göster:

`git ls-files --others`
