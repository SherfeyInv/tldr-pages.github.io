# arp

> Sistemin ARP önbelleğini görüntüle ve manipüle et.
> Daha fazla bilgi için: <https://manned.org/arp>.

- Mevcut ARP tablosunu göster:

`arp -a`

- Belirli bir girdiyi sil:

`arp -d {{adres}}`

- ARP tablosunda bir girdi oluştur:

`arp -s {{adres}} {{mac_adresi}}`
