# xzcat

> Bu komut `xz` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/xzcat>.

- Asıl komutun belgelerini görüntüleyin:

`tldr xz`
