# git stage

> Bu komut `git add` için bir takma addır.
> Daha fazla bilgi için: <https://git-scm.com/docs/git-stage>.

- Asıl komutun belgelerini görüntüleyin:

`tldr git add`
