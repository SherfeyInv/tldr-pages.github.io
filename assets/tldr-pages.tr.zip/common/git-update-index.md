# git update-index

> İndeksi manipüle etmeye yarayan bir Git komutu.
> Daha fazla bilgi için: <https://git-scm.com/docs/git-update-index>.

- Düzenlenmiş bir dosya değiştirilmemiş gibi davran (`git status` bunu değişmiş gibi göstermeyecek):

`git update-index --skip-worktree {{örnek/düzenlenen_dosya}}`
