# llvm-ar

> Bu komut `ar` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ar`
