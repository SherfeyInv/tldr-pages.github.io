# dmesg

> Kernel mesajlarını görüntüle.
> Daha fazla bilgi için: <https://www.unix.com/man-page/sunos/1m/dmesg>.

- Kernel mesajlarını görüntüle:

`dmesg`

- Sistemde ne kadar fiziksel hafıza kaldığını göster:

`dmesg | grep -i memory`

- Kernel mesajlarını terminal ekranına sığacak ve her satıra bir tane gelecek şekilde göster:

`dmesg | less`
