# cinst

> Ця команда є псевдонімом для `choco install`.

- Дивись документацію для оригінальної команди:

`tldr choco install`
