# pwsh where

> Ця команда є псевдонімом для `Where-Object`.

- Дивись документацію для оригінальної команди:

`tldr Where-Object`
