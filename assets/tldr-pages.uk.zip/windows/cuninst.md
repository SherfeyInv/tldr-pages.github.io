# cuninst

> Ця команда є псевдонімом для `choco uninstall`.
> Більше інформації: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Дивись документацію для оригінальної команди:

`tldr choco uninstall`
