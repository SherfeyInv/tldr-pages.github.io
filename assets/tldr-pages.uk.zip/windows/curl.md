# curl

> Ця команда є псевдонімом для `curl -p common`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Дивись документацію для оригінальної команди:

`tldr curl -p common`
