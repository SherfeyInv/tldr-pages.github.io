# dalvikvm

> Віртуальна машина Android Java.
> Більше інформації: <https://source.android.com/docs/core/runtime>.

- Запустити конкретну Java програму:

`dalvikvm -classpath {{шлях/до/файлу.jar}} {{ім'я_класу}}`
