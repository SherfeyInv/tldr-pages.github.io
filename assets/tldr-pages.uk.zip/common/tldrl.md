# tldrl

> Ця команда є псевдонімом для `tldr-lint`.
> Більше інформації: <https://github.com/tldr-pages/tldr-lint>.

- Дивись документацію для оригінальної команди:

`tldr tldr-lint`
