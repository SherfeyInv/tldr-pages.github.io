# platformio

> Ця команда є псевдонімом для `pio`.
> Більше інформації: <https://docs.platformio.org/en/latest/core/userguide/>.

- Дивись документацію для оригінальної команди:

`tldr pio`
