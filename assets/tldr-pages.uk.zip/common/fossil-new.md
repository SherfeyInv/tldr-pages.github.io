# fossil new

> Ця команда є псевдонімом для  `fossil init`.

- Дивись документацію для оригінальної команди:

`tldr fossil init`
