# gnmic sub

> Ця команда є псевдонімом для `gnmic subscribe`.

- Дивись документацію для оригінальної команди:

`tldr gnmic subscribe`
