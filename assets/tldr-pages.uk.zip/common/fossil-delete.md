# fossil delete

> Ця команда є псевдонімом для `fossil rm`.

- Дивись документацію для оригінальної команди:

`tldr fossil rm`
