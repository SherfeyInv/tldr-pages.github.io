# ip route list

> Ця команда є псевдонімом для `ip route show`.

- Дивись документацію для оригінальної команди:

`tldr ip route show`
