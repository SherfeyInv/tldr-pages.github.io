# archinstall

> Arch Linux 引导安装程序。
> 更多信息：<https://archinstall.readthedocs.io>.

- 启动交互式的安装程序：

`archinstall`

- 启动一个预设的安装程序：

`archinstall {{minimal|unattended}}`
