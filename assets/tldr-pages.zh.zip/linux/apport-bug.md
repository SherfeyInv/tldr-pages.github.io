# apport-bug

> 在 Ubuntu 上提交错误报告。
> 更多信息：<https://wiki.ubuntu.com/Apport>.

- 报告整个系统的错误：

`apport-bug`

- 报告某个软件包的错误：

`apport-bug {{包名}}`

- 报告某个可执行文件的错误：

`apport-bug {{可执行文件路径}}`

- 报告某个进程的错误：

`apport-bug {{PID}}`
