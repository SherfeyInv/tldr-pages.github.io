# lscpu

> 显示 CPU 架构信息。
> 更多信息：<https://manned.org/lscpu>.

- 显示所有 CPU 信息：

`lscpu`

- 以表格方式显示信息：

`lscpu --extended`

- 仅显示表中离线 CPU 的信息：

`lscpu --extended --offline`
