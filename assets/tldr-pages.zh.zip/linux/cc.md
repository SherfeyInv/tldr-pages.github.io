# cc

> 这是 `gcc` 命令的一个别名。
> 更多信息：<https://gcc.gnu.org>.

- 原命令的文档在：

`tldr gcc`
