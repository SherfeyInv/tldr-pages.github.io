# reboot

> 重新启动系统。
> 更多信息：<https://manned.org/reboot.8>.

- 立即重新启动：

`reboot`

- 立即重启，而无需正常关闭：

`reboot -f`
