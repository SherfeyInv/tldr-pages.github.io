# addpart

> 将特定分区的存在告知 Linux 内核。
> 这个命令是 `add partition` ioctl 的简单封装。
> 更多信息：<https://manned.org/addpart>.

- 将特定分区的存在告知 Linux 内核：

`addpart {{设备名}} {{分区名}} {{起始点}} {{长度}}`
