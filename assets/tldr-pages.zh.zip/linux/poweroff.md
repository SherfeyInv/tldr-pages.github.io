# poweroff

> 关闭系统。
> 更多信息：<https://www.manned.org/poweroff>.

- 关闭系统电源：

`sudo poweroff`
