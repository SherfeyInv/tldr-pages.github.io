# mkfs.minix

> 在分区内创建一个 Minix 文件系统。
> 更多信息：<https://manned.org/mkfs.minix>.

- 在设备 b 的分区 1 内创建一个 Minix 文件系统（`sdb1`）：

`mkfs.minix {{/dev/sdb1}}`
