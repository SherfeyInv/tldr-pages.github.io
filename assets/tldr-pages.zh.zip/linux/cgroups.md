# cgroups

> 这是 `cgclassify` 命令的一个别名。
> 更多信息：<https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- 原命令的文档在：

`tldr cgclassify`
