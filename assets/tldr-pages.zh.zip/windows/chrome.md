# chrome

> 这是 `chromium` 命令的一个别名。
> 更多信息：<https://chrome.google.com>.

- 原命令的文档在：

`tldr chromium`
