# mkdir

> 创建一个目录。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- 创建一个目录：

`mkdir {{目录名}}`

- 递归创建目录及子目录：

`mkdir {{子目录名}}`
