# vol

> 显示有关卷的信息。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/vol>.

- 显示当前驱动器的标签和序列号：

`vol`

- 显示指定驱动器的标签和序列号：

`vol {{D:}}`
