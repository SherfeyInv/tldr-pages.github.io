# cipher

> 加密或解密 NTFS 驱动器上的文件。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/cipher>.

- 加密文件或目录：

`cipher /e:{{路径/文件或目录}}`

- 解密文件或目录：

`cipher /d:{{路径/文件或目录}}`

- 安全地删除文件或目录：

`cipher /w:{{路径/文件或目录}}`
