# attrib

> 显示或修改文件和目录的属性。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/attrib>.

- 显示当前目录下所有文件的属性：

`attrib`
