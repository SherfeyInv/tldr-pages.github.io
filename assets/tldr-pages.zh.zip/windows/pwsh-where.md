# pwsh where

> 这是 `Where-Object` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- 原命令的文档在：

`tldr Where-Object`
