# title

> 设置命令提示符窗口的标题。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/title>.

- 设置当前的命令提示符窗口的标题：

`title {{新标题}}`
