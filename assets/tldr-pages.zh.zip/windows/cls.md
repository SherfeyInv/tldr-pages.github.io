# cls

> 清屏。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- 清屏：

`cls`
