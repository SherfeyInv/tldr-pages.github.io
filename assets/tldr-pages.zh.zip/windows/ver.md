# ver

> 显示当前 Windows 或 MS-DOS 的版本号。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- Display the current version number：

`ver`
