# explorer

> Windows 文件资源管理器。
> 更多信息：<https://ss64.com/nt/explorer.html>.

- 打开 Windows 文件资源管理器：

`explorer`

- 在当前目录打开 Windows 文件资源管理器：

`explorer .`

- 在指定目录打开 Windows 文件资源管理器：

`explorer {{path/to/directory}}`
