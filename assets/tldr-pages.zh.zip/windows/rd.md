# rd

> 这是 `rmdir` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- 原命令的文档在：

`tldr rmdir`
