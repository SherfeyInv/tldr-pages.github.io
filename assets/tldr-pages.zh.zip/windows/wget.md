# wget

> 这是 `wget -p common` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- 原命令的文档在：

`tldr wget -p common`
