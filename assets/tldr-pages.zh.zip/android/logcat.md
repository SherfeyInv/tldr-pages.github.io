# logcat

> 转储系统消息日志。
> 更多信息：<https://developer.android.com/tools/logcat>.

- 显示系统日志：

`logcat`

- 将系统日志写入文件：

`logcat -f {{文件路径}}`

- 显示与正则表达式匹配的行：

`logcat --regex {{正则表达式}}`
