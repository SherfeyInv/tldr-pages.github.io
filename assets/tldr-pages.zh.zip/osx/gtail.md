# gtail

> 这是 `-p linux tail` 命令的一个别名。

- 原命令的文档在：

`tldr -p linux tail`
