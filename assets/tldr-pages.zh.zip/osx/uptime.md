# uptime

> 告知当前系统运行多长时间和其他信息。
> 更多信息：<https://keith.github.io/xcode-man-pages/uptime.1.html>.

- 打印当前时间，运行时间，登录用户数量和其他信息：

`uptime`
