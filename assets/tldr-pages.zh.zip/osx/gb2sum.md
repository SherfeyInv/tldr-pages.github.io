# gb2sum

> 这是 `-p linux b2sum` 命令的一个别名。

- 原命令的文档在：

`tldr -p linux b2sum`
