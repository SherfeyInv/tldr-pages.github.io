# look

> 查找已排序的文件行（注意，必须是已排序的文件）。
> 更多信息：<https://keith.github.io/xcode-man-pages/look.1.html>.

- 它开始寻找一个给定的前缀：

`look {{前缀}} {{文件}}`

- 查找行，忽略大小写：

`look --ignore-case {{前缀}} {{文件}}`
