# launchd

> 这是 `launchctl` 命令的一个别名。
> 更多信息：<https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- 原命令的文档在：

`tldr launchctl`
