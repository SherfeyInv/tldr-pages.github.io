# gindent

> 这是 `-p linux indent` 命令的一个别名。

- 原命令的文档在：

`tldr -p linux indent`
