# ipconfig

> 查看和编辑网卡信息.
> 更多信息：<https://keith.github.io/xcode-man-pages/ipconfig.8.html>.

- 列出所有的网卡：

`ipconfig getiflist`

- 获取特定网卡的地址信息：

`ipconfig getifaddr {{接口名称}}`
