# reboot

> 重启系统。
> 更多信息：<https://keith.github.io/xcode-man-pages/reboot.8.html>.

- 立刻重启：

`sudo reboot`

- 立即重启，而无需正常关机：

`sudo reboot -q`
