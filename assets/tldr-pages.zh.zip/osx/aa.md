# aa

> 这是 `yaa` 命令的一个别名。

- 原命令的文档在：

`tldr yaa`
