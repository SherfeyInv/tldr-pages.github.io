# zeisstopnm

> 将 Zeiss 共聚焦文件转换为 Netbpm 格式。
> 更多信息：<https://manned.org/zeisstopnm.1>.

- 将 Zeiss 共聚焦文件转换为 `.pgm` 或 `.ppm` 格式：

`zeisstopnm {{路径/到/文件}}`

- 将 Zeiss 共聚焦文件转换为 Netbpm 格式，并明确指定目标文件类型：

`zeisstopnm -{{pgm|ppm}} {{路径/到/文件}}`
