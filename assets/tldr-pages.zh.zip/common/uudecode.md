# uudecode

> 解码被 `uuencode` 编码的文件。
> 更多信息：<https://manned.org/uudecode>.

- 解码用 `uuencode` 编码的文件，并将结果打印到 `stdout`：

`uudecode {{路径/到/编码文件}}`

- 解码用 `uuencode` 编码的文件，并将结果写入到一个文件中：

`uudecode -o {{路径/到/解码文件}} {{路径/到/编码文件}}`
