# nload

> 在终端中可视化查看网络流量。
> 更多信息：<https://github.com/rolandriegel/nload>.

- 查看所有网络接口的流量（使用方向键切换不同网口）：

`nload`

- 查看指定网络接口的流量（使用方向键切换网口）：

`nload devices {{网口1}} {{网口2}}`
