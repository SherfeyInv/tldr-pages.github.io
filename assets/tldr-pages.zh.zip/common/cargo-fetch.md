# cargo fetch

> 从网络获取包的依赖项。
> 更多信息：<https://doc.rust-lang.org/cargo/commands/cargo-fetch.html>.

- 获取 `Cargo.lock` 中指定的依赖项 (对所有目标)：

`cargo fetch`

- 为指定目标获取依赖项：

`cargo fetch --target {{目标三元组}}`
