# zstdless

> 打开一个 `zstd` 压缩文件进行交互式阅读，允许滚动和搜索。
> 请参阅：`zstd`，`less`。
> 更多信息：<https://manned.org/zstdless>.

- 打开一个 `zstd` 压缩文件：

`zstdless {{路径/到/文件.zst}}`
