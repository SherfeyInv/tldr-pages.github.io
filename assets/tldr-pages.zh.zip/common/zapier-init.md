# zapier init

> 初始化一个新的 Zapier 集成。
> 更多信息：<https://platform.zapier.com/reference/cli#init>.

- 初始化一个新的 Zapier 集成：

`zapier init {{路径/到/目录}}`

- 使用特定模板初始化一个新的 Zapier 集成：

`zapier init {{路径/到/目录}} {{-t|--template}} {{basic-auth|callback|custom-auth|digest-auth|dynamic-dropdown|files|minimal|oauth1-trello|oauth2|search-or-create|session-auth|typescript}}`

- 显示额外的调试输出：

`zapier init {{-d|--debug}}`
