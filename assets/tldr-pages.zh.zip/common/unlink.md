# unlink

> 从文件系统中删除对文件的链接。
> 如果链接是文件的最后一个，文件内容将丢失。
> 更多信息：<https://www.gnu.org/software/coreutils/unlink>.

- 如果是最后一个链接，则删除指定的文件：

`unlink {{路径/到/文件}}`
