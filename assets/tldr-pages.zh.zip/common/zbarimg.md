# zbarimg

> 扫描并解码图像文件中的条形码。
> 更多信息：<https://zbar.sourceforge.net>.

- 处理一个图像文件：

`zbarimg {{图像文件}}`
