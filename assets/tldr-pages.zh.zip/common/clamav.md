# ClamAV

> 这是 `clamdscan` 命令的一个别名。
> 更多信息：<https://www.clamav.net>.

- 原命令的文档在：

`tldr clamdscan`
