# unzstd

> 这是 `zstd --decompress` 命令的一个别名。

- 查看原命令的文档：

`tldr zstd`
