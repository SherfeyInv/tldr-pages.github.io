# piodebuggdb

> 这是 `pio debug` 命令的一个别名。

- 原命令的文档在：

`tldr pio debug`
