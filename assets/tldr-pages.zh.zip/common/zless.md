# zless

> 查看 `gzip` 和 `xz` 压缩文件。
> 更多信息：<https://manned.org/zless>.

- 使用 `less` 分页查看一个 `gzip` 压缩文件：

`zless {{文件.txt.gz}}`
