# users

> 显示已登录用户的列表。
> 请参阅：`useradd`，`userdel`，`usermod`。
> 更多信息：<https://www.gnu.org/software/coreutils/users>.

- 输出已登录的用户名：

`users`

- 根据指定的文件输出已登录的用户名：

`users {{/var/log/wmtp}}`
