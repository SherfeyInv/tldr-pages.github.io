# apropos

> 在 manpages 中搜索，例如查找一个新命令。
> 更多信息：<https://manned.org/apropos>.

- 搜索关键字：

`apropos {{正则表达式}}`

- 搜索时不限制输出到终端宽度：

`apropos -l {{正则表达式}}`
