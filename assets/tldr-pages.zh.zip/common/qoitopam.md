# qoitopam

> 将 QOI 图像（Quite OK Image 格式）转换为 Netpbm。
> 更多信息：<https://netpbm.sourceforge.net/doc/qoitopam.html>.

- 将 QOI 图像转换为 Netpbm：

`qoitopam {{路径/到/文件.qoi}} > {{路径/到/文件.pnm}}`
