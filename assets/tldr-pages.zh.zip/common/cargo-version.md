# cargo version

> 显示 `cargo` 版本信息。
> 更多信息：<https://doc.rust-lang.org/cargo/commands/cargo-version.html>.

- 显示版本：

`cargo version`

- 显示额外的构建信息：

`cargo version --verbose`
