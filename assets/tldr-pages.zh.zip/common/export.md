# export

> 命令为当前 shell 中的子进程进行环境变量设置。
> 更多信息：<https://manned.org/export.1posix>.

- 设置环境变量：

`export {{变量名}}={{值}}`

- 向环境变量 `PATH` 追加一个路径名：

`export PATH=$PATH:{{追加的 path 路径}}`
