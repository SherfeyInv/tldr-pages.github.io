# abduco

> 终端会话管理器。
> 更多信息：<https://www.brain-dump.org/projects/abduco/>.

- 列出会话：

`abduco`

- 附加到一个会话，如果不存在则新建它：

`abduco -A {{会话名}} {{终端}}`

- 使用`dvtm`附加到一个会话，如果不存在则新建它：

`abduco -A {{会话名}}`

- 从一个会话中分离：

`<Ctrl> + \`

- 以只读模式附加到一个会话：

`abduco -Ar {{会话名}}`
