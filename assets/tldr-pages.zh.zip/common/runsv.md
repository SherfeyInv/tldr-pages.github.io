# runsv

> 启动和管理 runit 服务。
> 更多信息：<https://manned.org/runsv.8>.

- 以当前用户身份启动 runit 服务：

`runsv {{路径/到/服务目录}}`

- 以 root 用户身份启动 runit 服务：

`sudo runsv {{路径/到/服务目录}}`
