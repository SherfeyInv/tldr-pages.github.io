# zopflipng

> PNG 压缩工具。
> 更多信息：<https://github.com/google/zopfli>.

- 优化一个 PNG 文件：

`zopflipng {{输入.png}} {{输出.png}}`

- 优化多个 PNG 文件并使用给定的前缀保存：

`zopflipng --prefix={{前缀}} {{图像1.png}} {{图像2.png}} {{图像3.png}}`
