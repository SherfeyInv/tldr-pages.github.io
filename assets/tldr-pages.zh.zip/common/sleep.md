# sleep

> 延迟指定的一段时间。
> 更多信息：<https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- 按秒数延迟：

`sleep {{seconds}}`

- 在20秒延迟后执行指定命令：

`sleep 20 && {{command}}`
