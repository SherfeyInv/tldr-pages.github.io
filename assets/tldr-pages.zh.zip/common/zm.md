# zm

> 一个管理报纸和博客文章的工具。
> 更多信息：<https://github.com/ZERMZeitung/zm2>.

- 创建一个新的草稿：

`zm new`

- 编辑草稿：

`zm edit`

- 发布草稿并使用 git 提交：

`zm publish`
