# zrun

> 透明地将压缩的参数文件解压缩并传递给某个命令。
> 更多信息：<https://joeyh.name/code/moreutils/>.

- 使用解压后的压缩参数文件运行指定命令：

`zrun {{cat 路径/到/文件1.gz 路径/到/文件2.bz2 ...}}`
