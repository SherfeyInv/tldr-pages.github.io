# gh cs

> 这是 `gh codespace`.命令的一个别名。

- 原命令的文档在：

`tldr gh codespace`
