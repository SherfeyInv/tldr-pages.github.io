# qrttoppm

> 将 QRT 光线追踪文件转换为 PPM 图像。
> 更多信息：<https://netpbm.sourceforge.net/doc/qrttoppm.html>.

- 将一个 QRT 文件转换为 PPM 图像：

`qrttoppm {{路径/到/文件.qrt}} > {{路径/到/图像.ppm}}`
