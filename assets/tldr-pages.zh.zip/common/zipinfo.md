# zipinfo

> 列出 Zip 文件内容的详细信息。
> 更多信息：<https://manned.org/zipinfo>.

- 以长格式（权限、所有权、大小和修改日期）列出 Zip 文件中的所有文件：

`zipinfo {{路径/到/压缩包.zip}}`

- 列出 Zip 文件中的所有文件：

`zipinfo -1 {{路径/到/压缩包.zip}}`
