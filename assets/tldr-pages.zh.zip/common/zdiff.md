# zdiff

> 对 `gzip` 压缩文件调用 `diff`。
> 更多信息：<https://manned.org/zdiff>.

- 比较两个文件，必要时解压它们：

`zdiff {{路径/到/文件1.gz}} {{路径/到/文件2.gz}}`

- 将文件与同名的 `gzip` 压缩文件进行比较：

`zdiff {{路径/到/文件}}`
