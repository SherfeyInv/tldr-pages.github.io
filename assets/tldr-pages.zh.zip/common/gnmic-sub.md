# gnmic sub

> 这是 `gnmic subscribe` 命令的一个别名。

- 原命令的文档在：

`tldr gnmic subscribe`
