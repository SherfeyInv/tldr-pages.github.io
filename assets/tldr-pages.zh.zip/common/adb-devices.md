# adb devices

> 列出已连接的 Android 设备。
> 更多信息：<https://manned.org/adb>.

- 列出设备：

`adb devices`

- 列出设备及其系统信息：

`adb devices -l`
