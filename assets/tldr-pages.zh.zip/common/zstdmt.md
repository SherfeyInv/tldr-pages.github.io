# zstdmt

> 这是 `zstd --threads 0` 命令的一个别名（该命令将工作线程数设置为物理 CPU 核心数）。

- 查看原始命令的文档：

`tldr zstd`
