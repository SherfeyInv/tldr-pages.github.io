# gwho

> Cette commande est un alias de `-p linux who`.

- Voir la documentation de la commande originale :

`tldr -p linux who`
