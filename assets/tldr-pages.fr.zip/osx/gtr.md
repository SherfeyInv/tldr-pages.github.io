# gtr

> Cette commande est un alias de `-p linux tr`.

- Voir la documentation de la commande originale :

`tldr -p linux tr`
