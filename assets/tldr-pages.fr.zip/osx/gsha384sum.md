# gsha384sum

> Cette commande est un alias de `-p linux sha384sum`.

- Voir la documentation de la commande originale :

`tldr -p linux sha384sum`
