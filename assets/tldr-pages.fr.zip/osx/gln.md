# gln

> Cette commande est un alias de `-p linux ln`.

- Voir la documentation de la commande originale :

`tldr -p linux ln`
