# gbasename

> Cette commande est un alias de `-p linux basename`.

- Voir la documentation de la commande originale :

`tldr -p linux basename`
