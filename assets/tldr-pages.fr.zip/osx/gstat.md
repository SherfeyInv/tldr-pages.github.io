# gstat

> Cette commande est un alias de `-p linux stat`.

- Voir la documentation de la commande originale :

`tldr -p linux stat`
