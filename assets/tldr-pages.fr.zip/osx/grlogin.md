# grlogin

> Cette commande est un alias de `-p linux rlogin`.

- Voir la documentation de la commande originale :

`tldr -p linux rlogin`
