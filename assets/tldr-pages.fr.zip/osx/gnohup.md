# gnohup

> Cette commande est un alias de `-p linux nohup`.

- Voir la documentation de la commande originale :

`tldr -p linux nohup`
