# genv

> Cette commande est un alias de `-p linux env`.

- Voir la documentation de la commande originale :

`tldr -p linux env`
