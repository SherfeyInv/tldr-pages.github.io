# glibtoolize

> Cette commande est un alias de `-p linux libtoolize`.

- Voir la documentation de la commande originale :

`tldr -p linux libtoolize`
