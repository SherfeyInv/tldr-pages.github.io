# gnl

> Cette commande est un alias de `-p linux nl`.

- Voir la documentation de la commande originale :

`tldr -p linux nl`
