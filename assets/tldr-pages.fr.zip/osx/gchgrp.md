# gchgrp

> Cette commande est un alias de `-p linux chgrp`.

- Voir la documentation de la commande originale :

`tldr -p linux chgrp`
