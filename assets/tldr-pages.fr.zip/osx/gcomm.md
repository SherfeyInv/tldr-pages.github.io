# gcomm

> Cette commande est un alias de `-p linux comm`.

- Voir la documentation de la commande originale :

`tldr -p linux comm`
