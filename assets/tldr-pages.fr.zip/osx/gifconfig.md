# gifconfig

> Cette commande est un alias de `-p linux ifconfig`.

- Voir la documentation de la commande originale :

`tldr -p linux ifconfig`
