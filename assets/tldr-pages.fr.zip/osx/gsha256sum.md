# gsha256sum

> Cette commande est un alias de `-p linux sha256sum`.

- Voir la documentation de la commande originale :

`tldr -p linux sha256sum`
