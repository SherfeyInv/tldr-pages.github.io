# gstdbuf

> Cette commande est un alias de `-p linux stdbuf`.

- Voir la documentation de la commande originale :

`tldr -p linux stdbuf`
