# gtftp

> Cette commande est un alias de `-p linux tftp`.

- Voir la documentation de la commande originale :

`tldr -p linux tftp`
