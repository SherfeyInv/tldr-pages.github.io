# gshred

> Cette commande est un alias de `-p linux shred`.

- Voir la documentation de la commande originale :

`tldr -p linux shred`
