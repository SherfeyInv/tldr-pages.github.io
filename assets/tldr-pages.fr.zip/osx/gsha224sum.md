# gsha224sum

> Cette commande est un alias de `-p linux sha224sum`.

- Voir la documentation de la commande originale :

`tldr -p linux sha224sum`
