# gkill

> Cette commande est un alias de `-p linux kill`.

- Voir la documentation de la commande originale :

`tldr -p linux kill`
