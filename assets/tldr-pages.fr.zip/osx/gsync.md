# gsync

> Cette commande est un alias de `-p linux sync`.

- Voir la documentation de la commande originale :

`tldr -p linux sync`
