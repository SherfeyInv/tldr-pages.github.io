# gwhoami

> Cette commande est un alias de `-p linux whoami`.

- Voir la documentation de la commande originale :

`tldr -p linux whoami`
