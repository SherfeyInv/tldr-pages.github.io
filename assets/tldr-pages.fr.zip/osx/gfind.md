# gfind

> Cette commande est un alias de `-p linux find`.

- Voir la documentation de la commande originale :

`tldr -p linux find`
