# gmktemp

> Cette commande est un alias de `-p linux mktemp`.

- Voir la documentation de la commande originale :

`tldr -p linux mktemp`
