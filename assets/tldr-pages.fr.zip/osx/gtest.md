# gtest

> Cette commande est un alias de `-p linux test`.

- Voir la documentation de la commande originale :

`tldr -p linux test`
