# ghead

> Cette commande est un alias de `-p linux head`.

- Voir la documentation de la commande originale :

`tldr -p linux head`
