# gsha1sum

> Cette commande est un alias de `-p linux sha1sum`.

- Voir la documentation de la commande originale :

`tldr -p linux sha1sum`
