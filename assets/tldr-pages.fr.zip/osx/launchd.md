# launchd

> Cette commande est un alias de `launchctl`.
> Plus d'informations : <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Voir la documentation de la commande originale :

`tldr launchctl`
