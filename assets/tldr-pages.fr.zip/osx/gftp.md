# gftp

> Cette commande est un alias de `-p linux ftp`.

- Voir la documentation de la commande originale :

`tldr -p linux ftp`
