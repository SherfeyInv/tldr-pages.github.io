# rd

> Cette commande est un alias de `rmdir`.

- Voir la documentation de la commande originale :

`tldr rmdir`
