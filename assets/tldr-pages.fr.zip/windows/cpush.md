# cpush

> Cette commande est un alias de `choco push`.

- Voir la documentation de la commande originale :

`tldr choco push`
