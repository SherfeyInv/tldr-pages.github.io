# iwr

> Cette commande est un alias de `invoke-webrequest`.

- Voir la documentation de la commande originale :

`tldr invoke-webrequest`
