# clist

> Cette commande est un alias de `choco list`.
> Plus d'informations : <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Voir la documentation de la commande originale :

`tldr choco list`
