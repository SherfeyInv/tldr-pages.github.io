# wget

> Cette commande est un alias de `wget -p common`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Voir la documentation de la commande originale :

`tldr wget -p common`
