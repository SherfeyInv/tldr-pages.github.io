# sls

> Cette commande est un alias de `Select-String`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Voir la documentation de la commande originale :

`tldr select-string`
