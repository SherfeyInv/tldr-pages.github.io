# sls

> Cette commande est un alias de `Select-String`.

- Voir la documentation de la commande originale :

`tldr select-string`
