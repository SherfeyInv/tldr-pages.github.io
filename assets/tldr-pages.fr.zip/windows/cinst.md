# cinst

> Cette commande est un alias de `choco install`.

- Voir la documentation de la commande originale :

`tldr choco install`
