# chrome

> Cette commande est un alias de `chromium`.
> Plus d'informations : <https://chrome.google.com>.

- Voir la documentation de la commande originale :

`tldr chromium`
