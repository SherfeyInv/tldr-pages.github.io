# pwsh where

> Cette commande est un alias de `Where-Object`.

- Voir la documentation de la commande originale :

`tldr Where-Object`
