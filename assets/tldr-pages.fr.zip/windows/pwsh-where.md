# pwsh where

> Cette commande est un alias de `Where-Object`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Voir la documentation de la commande originale :

`tldr Where-Object`
