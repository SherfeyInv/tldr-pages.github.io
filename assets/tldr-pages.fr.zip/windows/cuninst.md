# cuninst

> Cette commande est un alias de `choco uninstall`.

- Voir la documentation de la commande originale :

`tldr choco uninstall`
