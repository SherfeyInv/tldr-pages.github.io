# fossil ci

> Cette commande est un alias de `fossil commit`.

- Voir la documentation de la commande originale :

`tldr fossil commit`
