# matlab

> Environnement de calcul numérique créé par MathWorks.
> Plus d'informations : <https://uk.mathworks.com/help/matlab/>.

- Lance MATLAB sans afficher l'écran de démarrage :

`matlab -nosplash`

- Exécute une instruction MATLAB :

`matlab -r "{{instruction_matlab}}"`

- Exécute un script MATLAB :

`matlab -r "run({{chemin/vers/script.m}})"`
