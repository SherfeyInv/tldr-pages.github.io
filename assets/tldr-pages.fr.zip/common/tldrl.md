# tldrl

> Cette commande est un alias de `tldr-lint`.
> Plus d'informations : <https://github.com/tldr-pages/tldr-lint>.

- Voir la documentation de la commande originale :

`tldr tldr-lint`
