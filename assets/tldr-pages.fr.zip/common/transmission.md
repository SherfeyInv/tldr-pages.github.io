# transmission

> Cette commande est un alias de `transmission-daemon`.
> Plus d'informations : <https://transmissionbt.com/>.

- Voir la documentation de la commande originale :

`tldr transmission-daemon`
