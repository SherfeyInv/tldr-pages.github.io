# gh cs

> Cette commande est un alias de `gh codespace`.
> Plus d'informations : <https://cli.github.com/manual/gh_codespace>.

- Voir la documentation de la commande originale :

`tldr gh codespace`
