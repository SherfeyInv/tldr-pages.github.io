# fossil new

> Cette commande est un alias de `fossil init`.
> Plus d'informations : <https://fossil-scm.org/home/help/new>.

- Voir la documentation de la commande originale :

`tldr fossil init`
