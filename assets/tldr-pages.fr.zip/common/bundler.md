# bundler

> Gestionnaire de dépendances pour le langage de programmation Ruby.
> `bundler` est un nom commun pour la commande `bundle`, mais pas une commande elle-même.
> Plus d'informations : <https://bundler.io/man/bundle.1.html>.

- Voir la documentation de la commande originale :

`tldr bundle`
