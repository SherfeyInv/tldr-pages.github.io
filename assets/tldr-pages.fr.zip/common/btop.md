# btop

> Un moniteur de ressources qui affiche des informations sur le processeur, la mémoire, les disques, le réseau et les processus.
> Une version C++ de `bpytop`.
> Plus d'informations : <https://github.com/aristocratos/btop>.

- Démarre `btop` :

`btop`

- Démarre `btop` avec les réglages spécifiés :

`btop --preset {{0..9}}`
