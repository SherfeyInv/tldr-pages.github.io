# gnmic sub

> Cette commande est un alias de `gnmic subscribe`.
> Plus d'informations : <https://gnmic.kmrd.dev/cmd/subscribe>.

- Voir la documentation de la commande originale :

`tldr gnmic subscribe`
