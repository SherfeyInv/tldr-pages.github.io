# gnmic sub

> Cette commande est un alias de `gnmic subscribe`.

- Voir la documentation de la commande originale :

`tldr gnmic subscribe`
