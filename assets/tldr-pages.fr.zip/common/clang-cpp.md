# clang-cpp

> Cette commande est un alias de `clang++`.

- Voir la documentation de la commande originale :

`tldr clang++`
