# ripgrep

> Cette commande est un alias de `rg`.

- Voir la documentation de la commande originale :

`tldr rg`
