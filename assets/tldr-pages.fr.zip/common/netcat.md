# netcat

> Cette commande est un alias de `nc`.
> Plus d'informations : <https://manned.org/nc>.

- Voir la documentation de la commande originale :

`tldr nc`
