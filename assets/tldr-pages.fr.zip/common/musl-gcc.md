# musl-gcc

> Un adaptateur de `gcc` qui définit automatiquement les options pour l'édition de liens avec musl libc.
> Toutes les options spécifiées sont passées directement à `gcc`.
> Plus d'informations : <https://manned.org/musl-gcc>.

- Voir la documentation de `gcc` :

`tldr gcc`
