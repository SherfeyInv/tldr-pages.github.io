# zopflipng

> Utilitaire de compression d'images PNG.
> Plus d'informations : <https://github.com/google/zopfli>.

- Optimise une image PNG :

`zopflipng {{entrée.png}} {{sortie.png}}`

- Optimise plusieurs images PNG et sauvegarde avec préfixe donné :

`zopflipng --prefix={{prefix}} {{image1.png}} {{image2.png}} {{image3.png}}`
