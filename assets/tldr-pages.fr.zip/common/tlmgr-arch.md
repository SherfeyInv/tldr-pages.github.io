# tlmgr arch

> Cette commande est un alias de `tlmgr platform`.

- Voir la documentation de la commande originale :

`tldr tlmgr platform`
