# azure-cli

> Cette commande est un alias de `az`.
> Plus d'informations : <https://learn.microsoft.com/cli/azure>.

- Voir la documentation de la commande originale :

`tldr az`
