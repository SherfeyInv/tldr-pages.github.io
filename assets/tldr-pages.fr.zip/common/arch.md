# arch

> Affiche le nom de l'architecture système.
> Voir aussi `uname`.
> Plus d'informations : <https://www.gnu.org/software/coreutils/arch>.

- Affiche l'architecture système :

`arch`
