# rcat

> Cette commande est un alias de `rc`.

- Voir la documentation de la commande originale :

`tldr rc`
