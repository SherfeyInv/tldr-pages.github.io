# hping

> Cette commande est un alias de `hping3`.
> Plus d'informations : <https://github.com/antirez/hping>.

- Voir la documentation de la commande originale :

`tldr hping3`
