# ubuntu-bug

> Cette commande est un alias de `apport-bug`.
> Plus d'informations : <https://manned.org/ubuntu-bug>.

- Voir la documentation de la commande originale :

`tldr apport-bug`
