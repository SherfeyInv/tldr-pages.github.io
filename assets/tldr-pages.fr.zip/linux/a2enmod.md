# a2enmod

> Active un module Apache sur une distribution Debian.
> Plus d'informations : <https://manned.org/a2enmod.8>.

- Active un module :

`sudo a2enmod {{module}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2enmod --quiet {{module}}`
