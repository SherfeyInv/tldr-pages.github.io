# batcat

> Cette commande est un alias de `bat`.
> Plus d'informations : <https://github.com/sharkdp/bat>.

- Voir la documentation de la commande originale :

`tldr bat`
