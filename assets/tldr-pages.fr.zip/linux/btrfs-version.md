# btrfs version

> Afficher les informations de version des outils btrfs, et accéder aux pages d'aide.
> Plus d'informations : <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Afficher les informations de version des outils btrfs :

`btrfs version`

- Afficher l'aide :

`btrfs version --help`
