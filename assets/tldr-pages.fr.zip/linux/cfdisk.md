# cfdisk

> Un programme pour gérer les tables de partitions et les partitions sur un disque dur en utilisant une interface utilisateur de type "curses".
> Plus d'informations : <https://manned.org/cfdisk>.

- Lance le manipulateur de partitions sur un appareil spécifique :

`cfdisk {{/dev/sdX}}`

- Crée une nouvelle table de partitions pour un appareil spécifique et la gère :

`cfdisk --zero {{/dev/sdX}}`
