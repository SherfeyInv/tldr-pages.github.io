# ip route list

> Denne kommando er et alias af  `ip route show`.

- Se dokumentation for den oprindelige kommando:

`tldr ip-route-show`
