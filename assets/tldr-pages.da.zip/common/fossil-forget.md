# fossil forget

> Denne kommando er et alias af `fossil rm`.
> Mere information: <https://fossil-scm.org/home/help/forget>.

- Se dokumentation for den oprindelige kommando:

`tldr fossil rm`
