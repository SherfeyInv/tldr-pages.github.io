# gh cs

> Denne kommando er et alias af  `gh codespace`.

- Se dokumentation for den oprindelige kommando:

`tldr gh-codespace`
