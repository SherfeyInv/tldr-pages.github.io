# fossil new

> Denne kommando er et alias af `fossil init`.

- Se dokumentation for den oprindelige kommando:

`tldr fossil init`
