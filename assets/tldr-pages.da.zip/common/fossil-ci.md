# fossil ci

> Denne kommando er et alias af `fossil commit`.

- Se dokumentation for den oprindelige kommando:

`tldr fossil commit`
