# chsh

> Skift brugerens login shell.
> Mere information: <https://manned.org/chsh>.

- Skift shell:

`chsh -s {{sti/til/shell_program}} {{brugernavn}}`
