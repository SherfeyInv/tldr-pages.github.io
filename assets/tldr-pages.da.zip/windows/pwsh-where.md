# pwsh where

> Denne kommando er et alias af `Where-Object`.

- Se dokumentation for den oprindelige kommando:

`tldr Where-Object`
