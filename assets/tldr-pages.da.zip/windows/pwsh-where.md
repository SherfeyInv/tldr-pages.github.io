# pwsh where

> Denne kommando er et alias af `Where-Object`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Se dokumentation for den oprindelige kommando:

`tldr Where-Object`
