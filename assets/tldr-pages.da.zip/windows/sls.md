# sls

> Denne kommando er et alias af `Select-String`.

- Se dokumentation for den oprindelige kommando:

`tldr select-string`
