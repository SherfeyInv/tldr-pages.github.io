# gh cs

> Aquest comandament és un àlies de `gh codespace`.

- Veure documentació pel comandament original:

`tldr gh codespace`
