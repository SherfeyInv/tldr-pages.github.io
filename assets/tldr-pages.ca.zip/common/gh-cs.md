# gh cs

> Aquest comandament és un àlies de  `gh codespace`.
> Més informació: <https://cli.github.com/manual/gh_codespace>.

- Veure documentació pel comandament original:

`tldr gh-codespace`
