# fossil new

> Aquest comandament és un àlies de `fossil init`.

- Veure documentació pel comandament original:

`tldr fossil init`
