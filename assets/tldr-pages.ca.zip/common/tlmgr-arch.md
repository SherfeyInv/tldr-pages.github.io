# tlmgr arch

> Aquest comandament és un àlies de `tlmgr platform`.

- Veure documentació pel comandament original:

`tldr tlmgr platform`
