# fossil delete

> Aquest comandament és un àlies de `fossil rm`.

- Veure documentació pel comandament original:

`tldr fossil rm`
