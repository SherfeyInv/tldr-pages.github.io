# gnmic sub

> Aquest comandament és un àlies de `gnmic subscribe`.

- Veure documentació pel comandament original:

`tldr gnmic subscribe`
