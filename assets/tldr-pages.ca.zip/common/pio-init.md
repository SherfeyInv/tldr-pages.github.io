# pio init

> Aquest comandament és un àlies de `pio project`.

- Veure documentació pel comandament original:

`tldr pio project`
