# calc

> Una calculadora de precisió arbitrària en la terminal.
> Més informació: <https://github.com/lcn2/calc>.

- Iniciar calc en mode interactiu:

`calc`

- Realizar un càlcul  en mode no-interactiu:

`calc -p '{{85 * (36 / 4)}}'`
