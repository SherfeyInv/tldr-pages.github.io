# ubuntu-bug

> Aquest commandament és un àlies de `apport-bug`.

- Veure documentació per el commandament original:

`tldr apport-bug`
