# ubuntu-bug

> Aquest commandament és un àlies de `apport-bug`.
> Més informació: <https://manned.org/ubuntu-bug>.

- Veure documentació per el commandament original:

`tldr apport-bug`
