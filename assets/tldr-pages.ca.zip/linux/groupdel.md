# groupdel

> Elimina del sistema grups d'usuaris existents.
> Més informació: <https://manned.org/groupdel>.

- Borra un grup existent:

`sudo groupdel {{nom_del_grup}}`
