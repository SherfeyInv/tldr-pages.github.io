# archey

> Eina senzilla per mostrar informació del sistema amb estil.
> Més informació: <https://lclarkmichalek.github.io/archey3/>.

- Mostra informació del sistema:

`archey`
