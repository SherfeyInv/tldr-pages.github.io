# a2enmod

> Activa un mòdul d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manned.org/a2enmod.8>.

- Activa un mòdul:

`sudo a2enmod {{mòdul}}`

- No mostris missatges informatius:

`sudo a2enmod --quiet {{mòdul}}`
