# snake4scores

> Mostra les màximes puntuacions del joc snake4.
> Més informació: <https://manpages.debian.org/snake4/snake4.6.en.html>.

- Mostra les màximes puntuacions:

`snake4scores`
