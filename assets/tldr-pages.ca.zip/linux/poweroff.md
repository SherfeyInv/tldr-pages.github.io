# poweroff

> Apaga la màquina.
> Més informació: <https://www.manned.org/poweroff>.

- Apaga la màquina:

`poweroff`

- Atura el sistema (el mateix que `halt`):

`poweroff --halt`

- Reinicia el ssitema (el mateix que `reboot`):

`poweroff --reboot`

- Apaga el sistema sense contactar l'administrador del sistema:

`poweroff --force --force`

- Escriu l'entrada de wtpm shutdown sense apagar l'ordinador:

`poweroff --wtmp-only`
