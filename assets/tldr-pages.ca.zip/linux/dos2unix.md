# dos2unix

> Canvia salts de línia amb format DOS a salts de línia amb format Unix.
> Reemplaça CRLF amb LF.
> Més informació: <https://manned.org/dos2unix>.

- Canvia els salts de línia en un arxiu:

`dos2unix {{nom_del_arxiu}}`

- Crea una còpia amb salts de línia en format Unix:

`dos2unix -n {{nom_del_arxiu}} {{nou_nom_del_arxiu}}`
