# a2ensite

> Activa un host virtual d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manned.org/a2ensite.8>.

- Activa un host virtual:

`sudo a2ensite {{host_virtual}}`

- No mostris missatges informatius:

`sudo a2ensite --quiet {{host_virtual}}`
