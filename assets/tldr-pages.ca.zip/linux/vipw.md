# vipw

> Edita l'arxiu de contrasenyes.
> Més informació: <https://manned.org/vipw>.

- Edita l'arxiu de contrasenyes:

`vipw`

- Mostra la versió instal·lada de `vipw`:

`vipw --version`
