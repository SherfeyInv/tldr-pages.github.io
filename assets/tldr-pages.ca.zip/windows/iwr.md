# iwr

> Aquest comandament és un àlies de `invoke-webrequest`.

- Veure documentació pel comandament original:

`tldr invoke-webrequest`
