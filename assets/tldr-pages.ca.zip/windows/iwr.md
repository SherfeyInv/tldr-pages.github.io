# iwr

> Aquest comandament és un àlies de `invoke-webrequest`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Veure documentació pel comandament original:

`tldr invoke-webrequest`
