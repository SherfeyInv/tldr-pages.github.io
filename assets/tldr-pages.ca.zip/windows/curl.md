# curl

> Aquest comandament és un àlies de `curl -p common`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Veure documentació pel comandament original:

`tldr curl -p common`
