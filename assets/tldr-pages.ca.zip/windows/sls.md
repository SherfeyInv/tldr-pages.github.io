# sls

> Aquest comandament és un àlies de `Select-String`.

- Veure documentació pel comandament original:

`tldr select-string`
