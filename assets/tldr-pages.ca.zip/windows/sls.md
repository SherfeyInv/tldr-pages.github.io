# sls

> Aquest comandament és un àlies de `Select-String`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Veure documentació pel comandament original:

`tldr select-string`
