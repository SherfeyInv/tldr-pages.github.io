# wget

> Aquest comandament és un àlies de `wget -p common`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Veure documentació pel comandament original:

`tldr wget -p common`
