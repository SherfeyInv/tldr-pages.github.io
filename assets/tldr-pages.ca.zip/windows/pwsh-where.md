# pwsh where

> Aquest comandament és un àlies de `Where-Object`.

- Veure documentació pel comandament original:

`tldr Where-Object`
