# nmcli monitor

> Monitor veranderingen van de NetworkManager connectie status.
> Dit subcommando kan ook aangeroepen worden met `nmcli m`.
> Meer informatie: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Start het monitoren van NetworkManager's veranderingen:

`nmcli monitor`
