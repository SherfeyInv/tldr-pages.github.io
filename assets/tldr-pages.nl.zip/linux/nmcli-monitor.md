# nmcli monitor

> Monitor veranderingen van de NetworkManager connectie status.
> Dit subcommando kan ook aangeroepen worden met `nmcli m`.
> Meer informatie: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- Start het monitoren van NetworkManager's veranderingen:

`nmcli monitor`
