# ip6tables

> Dit commando is een alias van `iptables`.

- Bekijk de documentatie van het originele commando:

`tldr iptables`
