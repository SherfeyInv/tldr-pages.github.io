# bspwm

> Een tegelvensterbeheerder gebaseerd op binaire ruimtepartitionering.
> Bekijk ook: `bspc`, voor het aansturen.
> Meer informatie: <https://github.com/baskerville/bspwm>.

- Start `bspwm` (houd er rekening mee dat een reeds bestaande vensterbeheerder niet geopend mag zijn wanneer dit commando wordt uitgevoerd):

`bspwm -c {{pad/naar/config}}`
