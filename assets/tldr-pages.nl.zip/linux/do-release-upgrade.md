# do-release-upgrade

> De Ubuntu release upgrader.
> Meer informatie: <https://ubuntu.com/server/docs/upgrade-introduction>.

- Upgrade naar de laatste release:

`sudo do-release-upgrade`

- Upgrade naar de laatste development release:

`sudo do-release-upgrade --devel-release`

- Upgrade naar de laatste voorgestelde release:

`sudo do-release-upgrade --proposed`
