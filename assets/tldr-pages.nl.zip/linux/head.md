# head

> Geef het eerste deel van bestanden weer.
> Meer informatie: <https://www.gnu.org/software/coreutils/head>.

- Geef de eerste paar regels van een bestand weer:

`head --lines {{aantal}} {{pad/naar/bestand}}`

- Geef de eerste paar bytes van een bestand weer:

`head --bytes {{aantal}} {{pad/naar/bestand}}`

- Geef alles behalve de laatste paar regels van een bestand weer:

`head --lines -{{aantal}} {{pad/naar/bestand}}`

- Geef alles behalve de laatste paar bytes van een bestand weer:

`head --bytes -{{aantal}} {{pad/naar/bestand}}`
