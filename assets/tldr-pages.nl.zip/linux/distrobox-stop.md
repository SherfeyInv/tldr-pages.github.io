# distrobox-stop

> Stop een Distrobox container. Bekijk ook: `tldr distrobox`.
> Meer informatie: <https://distrobox.it/usage/distrobox-stop>.

- Stop een Distrobox container:

`distrobox-stop {{container_name}}`

- Stop een Distrobox container zonder bevestiging:

`distrobox-stop --name {{container_name}} --yes`
