# yum config-manager

> Dit commando is een alias van `dnf config-manager`.

- Bekijk de documentatie van het originele commando:

`tldr dnf config-manager`
