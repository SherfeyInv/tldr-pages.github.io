# tailf

> Dit commando is vervangen door `tail -f`.
> Meer informatie: <https://manned.org/tailf.1>.

- Bekijk de documentatie voor de aanbevolen vervanging:

`tldr tail`
