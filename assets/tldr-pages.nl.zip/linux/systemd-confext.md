# systemd-confext

> Dit commando is een alias van `systemd-sysext`.
> Het volgt hetzelfde principe als `systemd-sysext`, maar in plaats van werken in `/usr` en `/opt`, `confext` zal alleen werken op `/etc`.
> Meer informatie: <https://www.freedesktop.org/software/systemd/man/latest/systemd-sysext.html>.

- Bekijk de documentatie van het originele commando:

`tldr systemd-sysext`
