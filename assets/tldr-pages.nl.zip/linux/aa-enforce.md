# aa-enforce

> Stel een AppArmor-profiel in op afdwingmodus.
> Bekijk ook: `aa-complain`, `aa-disable`, `aa-status`.
> Meer informatie: <https://gitlab.com/apparmor/apparmor/-/wikis/manpage_aa-enforce.8>.

- Schakel een profiel in:

`sudo aa-enforce {{pad/naar/profiel1 pad/naar/profiel2 ...}}`

- Schakel profielen in:

`sudo aa-enforce --dir {{pad/naar/profiel}}`
