# distrobox-list

> Toon alle Distrobox containers. Bekijk ook: `tldr distrobox`.
> Distrobox containers worden los van de rest van de normale Podman of Docker containers weergegeven.
> Meer informatie: <https://distrobox.it/usage/distrobox-list>.

- Toon alle Distrobox containers:

`distrobox-list`

- Toon alle Distrobox containers met verbose informatie:

`distrobox-list --verbose`
