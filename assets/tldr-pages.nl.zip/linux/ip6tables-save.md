# ip6tables-save

> Dit commando is een alias van `iptables-save`.

- Bekijk de documentatie van het originele commando:

`tldr iptables-save`
