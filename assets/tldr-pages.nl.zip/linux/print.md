# print

> Een alias voor de `run-mailcap`-actie print.
> Oorspronkelijk wordt `run-mailcap` gebruikt om mime-typen/bestanden te verwerken.
> Meer informatie: <https://manned.org/print>.

- De print-actie kan worden gebruikt om elk bestand af te drukken met de standaard `run-mailcap`-tool:

`print {{bestandsnaam}}`

- Met `run-mailcap`:

`run-mailcap --action=print {{bestandsnaam}}`
