# more

> Toon een bestand interactief, met de mogelijkheid om te scrollen en te zoeken.
> Zie ook: `less`.
> Meer informatie: <https://manned.org/more>.

- Open een bestand:

`more {{pad/naar/bestand}}`

- Toon een specifieke regel:

`more +{{regelnummer}} {{pad/naar/bestand}}`

- Ga naar de volgende pagina:

`<Spatie>`

- Zoek naar een string (druk op `n` om naar de volgende overeenkomst te gaan):

`/{{iets}}`

- Afsluiten:

`q`

- Toon hulp over interactieve commando's:

`h`
