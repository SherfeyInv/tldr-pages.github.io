# lid

> Let op: deze pagina is op dit moment een verwijzing. Als je bekend bent met dit programma, mag je een pull request openen.
> Query ID database en rappoteer resultaten.
> In Fedora en Arch Linux is de binary naam `lid` in gebruik door een ander programma. Bekijk hiervoor `tldr libuser-lid`.
> Meer informatie: <https://www.gnu.org/software/idutils/>.

- Bekijk documentatie voor `libuser-lid`:

`tldr libuser-lid`
