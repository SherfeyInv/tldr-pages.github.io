# cgroups

> Cgroups aka Control Groups is een Linux-kernelfunctie voor het beperken, meten en beheersen van het gebruik van hulpbronnen door processen.
> Cgroups is echter geen commando, maar eerder een verzameling van commando's, zie de relevante pagina's hieronder.
> Meer informatie: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Toon de tldr pagina voor `cgclassify`:

`tldr cgclassify`

- Toon de tldr pagina voor `cgcreate`:

`tldr cgcreate`

- Toon de tldr pagina voor `cgexec`:

`tldr cgexec`
