# cc

> Dit commando is een alias van `gcc`.
> Meer informatie: <https://gcc.gnu.org>.

- Bekijk de documentatie van het originele commando:

`tldr gcc`
