# dnsdomainname

> Toon de DNS-domeinnaam van het systeem.
> Let op: de tool gebruikt `gethostname` om de hostnaam van het systeem op te halen en vervolgens `getaddrinfo` om deze om te zetten in een gecanoniseerde naam.
> Meer informatie: <https://www.gnu.org/software/inetutils/manual/html_node/dnsdomainname-invocation.html>.

- Toon de DNS-domeinnaam van het systeem:

`dnsdomainname`
