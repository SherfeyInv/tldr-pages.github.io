# apx

> Pakketbeheerhulpprogramma met ondersteuning voor meerdere bronnen, zodat u pakketten in subsystemen kunt installeren.
> Meer informatie: <https://github.com/Vanilla-OS/apx>.

- Bekijk de documentatie voor het beheren van pakketmanagers:

`tldr apx pkgmanagers`

- Bekijk de documentatie voor het beheren van stapels:

`tldr apx stacks`

- Bekijk de documentatie voor het beheren van subsystemen:

`tldr apx subsystems`
