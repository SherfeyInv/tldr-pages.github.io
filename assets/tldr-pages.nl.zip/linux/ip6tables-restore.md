# ip6tables-restore

> Dit commando is een alias van `iptables-restore`.

- Bekijk de documentatie van het originele commando:

`tldr iptables-restore`
