# apparmor_status

> Dit commando is een alias van `aa-status`.

- Bekijk de documentatie van het originele commando:

`tldr aa-status`
