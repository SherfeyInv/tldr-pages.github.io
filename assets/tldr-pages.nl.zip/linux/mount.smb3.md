# mount.smb3

> Dit commando is een alias van `mount.cifs`.
> Let op: voor SMB versies vóór 3, dien je `mount.cifs` te gebruiken.

- Bekijk de documentatie van het originele commando:

`tldr mount.cifs`
