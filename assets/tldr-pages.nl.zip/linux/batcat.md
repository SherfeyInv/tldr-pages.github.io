# batcat

> Dit commando is een alias van `bat`.
> Meer informatie: <https://github.com/sharkdp/bat>.

- Bekijk de documentatie van het originele commando:

`tldr bat`
