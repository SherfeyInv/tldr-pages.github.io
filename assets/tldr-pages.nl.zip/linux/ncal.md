# ncal

> Dit commando is een alias van `cal`.
> Meer informatie: <https://manned.org/ncal>.

- Bekijk de documentatie van het originele commando:

`tldr cal`
