# distrobox-rm

> Verwijder een Distrobox container. Bekijk ook: `tldr distrobox`.
> Meer informatie: <https://distrobox.it/usage/distrobox-rm>.

- Verwijder een Distrobox container (Tip: Stop the container voordat je hem verwijdert):

`distrobox-rm {{container_name}}`

- Verwijder een Distrobox container geforceerd:

`distrobox-rm {{container_name}} --force`
