# qm move disk

> Dit commando is een alias van `qm disk move`.
> Meer informatie: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Bekijk de documentatie van het originele commando:

`tldr qm disk move`
