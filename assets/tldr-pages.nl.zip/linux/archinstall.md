# archinstall

> Begeleidende Arch Linux installatie met een twist.
> Meer informatie: <https://archinstall.readthedocs.io>.

- Start de interactieve installatie:

`archinstall`

- Start de template installatie:

`archinstall {{minimal|unattended}}`
