# chrome

> Dit commando is een alias van `chromium`.
> Meer informatie: <https://chrome.google.com>.

- Bekijk de documentatie van het originele commando:

`tldr chromium`
