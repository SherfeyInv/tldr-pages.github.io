# date

> Toon of stel de systeemdatum in.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/date>.

- Toon de huidige systeemdatum en vraag voor een nieuwe datum (laat leeg om niet te veranderen):

`date`

- Toon de huidige systeemdatum zonder te vragen voor een nieuwe datum:

`date /t`

- Verander de huidige systeemdatum naar een specifieke datum:

`date {{maand}}-{{dag}}-{{jaar}}`
