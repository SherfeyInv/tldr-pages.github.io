# mkdir

> Maak een map aan.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Maak een map aan:

`mkdir {{pad\naar\map}}`

- Maak een geneste mappenstructuur recursief aan:

`mkdir {{pad\naar\sub_map}}`
