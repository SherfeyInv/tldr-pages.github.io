# sdelete64

> Dit commando is de 64 bit versie van `sdelete`.

- Bekijk de documentatie van het originele commando:

`tldr sdelete`
