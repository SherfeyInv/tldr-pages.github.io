# cpush

> Dit commando is een alias van `choco-push`.
> Meer informatie: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Bekijk de documentatie van het originele commando:

`tldr choco-push`
