# clist

> Dit commando is een alias van `choco list`.
> Meer informatie: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Bekijk de documentatie van het originele commando:

`tldr choco list`
