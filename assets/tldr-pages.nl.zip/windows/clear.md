# clear

> In PowerShell is dit commando een alias van `Clear-Host`.

- Bekijk de documentatie van het originele commando:

`tldr clear-host`
