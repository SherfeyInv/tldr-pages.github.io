# cls

> Wist het scherm.
> In PowerShell is dit commando een alias van `Clear-Host`. Deze documentatie is gebaseerd op de Command Prompt (`cmd`) versie van `cls`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Bekijk de documentatie van het equivalente PowerShell commando:

`tldr clear-host`

- Wis het scherm:

`cls`
