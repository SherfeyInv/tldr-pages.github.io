# cuninst

> Dit commando is een alias van `choco uninstall`.
> Meer informatie: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Bekijk de documentatie van het originele commando:

`tldr choco uninstall`
