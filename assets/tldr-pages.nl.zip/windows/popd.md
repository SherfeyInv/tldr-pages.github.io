# popd

> Wijzigt de huidige map naar de map die is opgeslagen met het `pushd`-commando.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/popd>.

- Ga naar de map bovenaan de stapel:

`popd`
