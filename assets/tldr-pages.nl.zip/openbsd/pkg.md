# pkg

> OpenBSD pakketbeheerder hulpprogramma.
> Meer informatie: <https://www.openbsd.org/faq/faq15.html>.

- Bekijk de documentatie voor installeren/updaten van pakketten:

`tldr pkg_add`

- Bekijk de documentatie voor het verwijderen van pakketen:

`tldr pkg_delete`

- Bekijk de documentatie voor het bekijken van informatie over pakketen:

`tldr pkg_info`
