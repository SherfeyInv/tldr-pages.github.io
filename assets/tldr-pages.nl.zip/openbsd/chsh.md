# chsh

> Dit commando is een alias van `chpass`.

- Bekijk de documentatie van het originele commando:

`tldr chpass`
