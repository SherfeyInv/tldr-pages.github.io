# npm-name

> Controleer of een pakket- of organisatienaam beschikbaar is op npm.
> Meer informatie: <https://github.com/sindresorhus/npm-name-cli>.

- Controleer of een specifieke pakketnaam beschikbaar is in het npm-register:

`npm-name {{pakket}}`

- Vind vergelijkbare pakketnamen in het npm-register:

`npm-name --similar {{pakket}}`
