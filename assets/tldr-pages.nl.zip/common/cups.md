# CUPS

> Open source print systeem.
> CUPS is geen commando, maar een set van commando's.
> Meer informatie: <https://www.cups.org/index.html>.

- Bekijk de documentatie voor het draaien van de CUPS daemon:

`tldr cupsd`

- Bekijk de documentatie voor het beheren van printers:

`tldr lpadmin`

- Bekijk de documentatie voor het printen van bestanden:

`tldr lp`

- Bekijk de documentatie voor het bekijken van de status informatie over de huidige klasses, taken en printers:

`tldr lpstat`

- Bekijk de documentatie voor het annuleren van printtaken:

`tldr lprm`
