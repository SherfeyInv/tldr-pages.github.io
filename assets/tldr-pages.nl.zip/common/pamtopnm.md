# pamtopnm

> Converteer een PAM afbeelding naar een equivalente PNM afbeelding.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamtopnm.html>.

- Converteer een PAM afbeelding naar een equivalente PNM afbeelding, i.e. een PBM, PGM of PPM afbeelding:

`pamtopnm {{pad/naar/afbeelding.pam}} > {{pad/naar/uitvoer.pbm|pgm|ppm}}`

- Toon de versie:

`pamtopnm -version`
