# crane blob

> Lees een blob uit een registry.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_blob.md>.

- Lees de blob uit een registry:

`crane blob {{blob_identifier}}`

- Toon help:

`crane blob {{-h|--help}}`
