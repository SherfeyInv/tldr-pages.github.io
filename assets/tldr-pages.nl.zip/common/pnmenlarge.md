# pnmenlarge

> Dit commando is vervangen door `pamenlarge`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmenlarge.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamenlarge`
