# ruff

> Een extreem snelle Python linter en code formatter, geschreven in Rust.
> Meer informatie: <https://docs.astral.sh/ruff/tutorial>.

- Bekijk de documentatie voor de Ruff linter:

`tldr ruff check`

- Bekijk de documentatie voor de Ruff code formatter:

`tldr ruff format`
