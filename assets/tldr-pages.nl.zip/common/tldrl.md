# tldrl

> Dit commando is een alias van `tldr-lint`.

- Bekijk de documentatie van het originele commando:

`tldr tldr-lint`
