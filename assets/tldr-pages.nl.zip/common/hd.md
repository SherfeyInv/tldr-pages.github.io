# hd

> Dit commando is een alias van `hexdump`.

- Bekijk de documentatie van het originele commando:

`tldr hexdump`
