# pnmtopnm

> Dit commando is een alias van `pamtopnm`.

- Bekijk de documentatie van het originele commando:

`tldr pamtopnm`
