# hx

> Dit commando is een alias van `helix`.

- Bekijk de documentatie van het originele commando:

`tldr helix`
