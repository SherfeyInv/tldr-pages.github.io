# llvm-strings

> Dit commando is een alias van `strings`.

- Bekijk de documentatie van het originele commando:

`tldr strings`
