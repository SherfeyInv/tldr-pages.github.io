# docker container rename

> Dit commando is een alias van `docker rename`.
> Meer informatie: <https://docs.docker.com/reference/cli/docker/container/rename/>.

- Bekijk de documentatie van het originele commando:

`tldr docker rename`
