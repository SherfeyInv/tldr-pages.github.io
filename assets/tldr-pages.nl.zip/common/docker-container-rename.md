# docker container rename

> Dit commando is een alias van `docker rename`.

- Bekijk de documentatie van het originele commando:

`tldr docker rename`
