# npm stop

> Dit commando is een alias van `npm run stop`.

- Bekijk de documentatie van het originele commando:

`tldr npm run`
