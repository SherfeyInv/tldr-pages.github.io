# pnmarith

> Dit commando is vervangen door `pamarith`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmarith.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamarith`
