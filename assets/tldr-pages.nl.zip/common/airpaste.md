# airpaste

> Deel berichten en bestanden op hetzelfde netwerk met behulp van mDNS.
> Meer informatie: <https://github.com/mafintosh/airpaste>.

- Wacht op een bericht en geef het weer wanneer het wordt ontvangen:

`airpaste`

- Stuur tekst:

`echo {{tekst}} | airpaste`

- Stuur een bestand:

`airpaste < {{pad/naar/bestand}}`

- Ontvang een bestand:

`airpaste > {{pad/naar/bestand}}`

- Maak of word lid van een kanaal:

`airpaste {{kanaal_naam}}`
