# vimtutor

> Vim tutor leert de basis `vim` commando's.
> Bekijk ook: `vim`, `vimdiff`, `nvim`.
> Meer informatie: <https://manned.org/vimtutor>.

- Start de vim tutor voor de opgegeven taal (en, fr, de, ...):

`vimtutor {{taal}}`

- Verlaat de tutor:

`<Esc> :q <Enter>`
