# ntl

> Dit commando is een alias van `netlify`.
> Meer informatie: <https://cli.netlify.com>.

- Bekijk de documentatie van het originele commando:

`tldr netlify`
