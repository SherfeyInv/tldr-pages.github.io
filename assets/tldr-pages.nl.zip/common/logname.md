# logname

> Toont de inlognaam van de gebruiker.
> Meer informatie: <https://www.gnu.org/software/coreutils/logname>.

- Geef de momenteel aangemelde gebruikersnaam weer:

`logname`
