# pnmdepth

> Dit commando is een alias van `pamdepth`.

- Bekijk de documentatie van het originele commando:

`tldr pamdepth`
