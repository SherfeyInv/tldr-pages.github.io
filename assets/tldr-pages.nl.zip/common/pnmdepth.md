# pnmdepth

> Dit commando is een alias van `pamdepth`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmdepth.html>.

- Bekijk de documentatie van het originele commando:

`tldr pamdepth`
