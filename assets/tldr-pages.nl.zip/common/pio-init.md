# pio init

> Dit commando is een alias van `pio project init`.

- Bekijk de documentatie van het originele commando:

`tldr pio project`
