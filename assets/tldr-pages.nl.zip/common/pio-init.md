# pio init

> Dit commando is een alias van `pio project`.

- Bekijk de documentatie van het originele commando:

`tldr pio project`
