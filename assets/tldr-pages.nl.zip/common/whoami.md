# whoami

> Toon de gebruikersnaam die is gekoppeld aan de huidige effectieve gebruikers-ID.
> Meer informatie: <https://www.gnu.org/software/coreutils/whoami>.

- Toon de momenteel ingelogde gebruikersnaam:

`whoami`

- Toon de gebruikersnaam na een wijziging in de gebruikers-ID:

`sudo whoami`
