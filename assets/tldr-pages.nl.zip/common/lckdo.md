# lckdo

> Dit commando is verouderd en vervangen door `flock`.
> Meer informatie: <https://joeyh.name/code/moreutils/>.

- Bekijk de documentatie van de aanbevolen vervanging:

`tldr flock`
