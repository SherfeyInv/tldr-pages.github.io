# cksum

> Bereken de CRC checksums en het aantal bytes van een bestand.
> Let op: op oudere UNIX systemen kan de CRC implementatie verschillen.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/cksum-invocation.html>.

- Toon een 32-bit checksum, grootte in bytes en bestandsnaam:

`cksum {{pad/naar/bestand}}`
