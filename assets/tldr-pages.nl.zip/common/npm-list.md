# npm list

> Dit commando is een alias van `npm ls`.

- Bekijk de documentatie van het originele commando:

`tldr npm ls`
