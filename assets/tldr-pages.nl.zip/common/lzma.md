# lzma

> Dit commando is een alias van `xz --format=lzma`.

- Bekijk de documentatie van het originele commando:

`tldr xz`
