# vivaldi

> Dit commando is een alias van `chromium`.
> Meer informatie: <https://vivaldi.com>.

- Bekijk de documentatie van het originele commando:

`tldr chromium`
