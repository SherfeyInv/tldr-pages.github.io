# exec

> Voer een commando uit zonder een child-proces te creëren.
> Meer informatie: <https://manned.org/exec.1posix>.

- Voer een specifiek commando uit met behulp van de huidige omgevingsvariabelen:

`exec {{commando -with -flags}}`
