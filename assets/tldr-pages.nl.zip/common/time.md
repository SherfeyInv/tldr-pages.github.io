# time

> Meet hoe lang het uitvoeren van een commando duurt.
> Let op: `time` kan ofwel bestaan als een shell builtin, een op zichzelf staand programma of beide.
> Meer informatie: <https://manned.org/time>.

- Voer het `commando` uit en print de tijdmetingen naar `stdout`::

`time {{commando}}`

- Maak een eenvoudige stopwatch (werkt alleen in Bash):

`time read`
