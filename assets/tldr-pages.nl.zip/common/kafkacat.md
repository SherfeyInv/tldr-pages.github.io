# kafkacat

> Dit commando is een alias van `kcat`.

- Bekijk de documentatie van het originele commando:

`tldr kcat`
