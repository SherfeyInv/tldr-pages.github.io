# jobs

> Toon de status van jobs in de huidige sessie.
> Meer informatie: <https://manned.org/jobs>.

- Toon de status van alle jobs:

`jobs`

- Toon de status van een specifieke job:

`jobs %{{job_id}}`

- Toon de status en proces-ID's van alle jobs:

`jobs -l`

- Toon de proces-ID's van alle jobs:

`jobs -p`
