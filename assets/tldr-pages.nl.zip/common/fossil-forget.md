# fossil forget

> Dit commando is een alias van `fossil rm`.
> Meer informatie: <https://fossil-scm.org/home/help/forget>.

- Bekijk de documentatie van het originele commando:

`tldr fossil rm`
