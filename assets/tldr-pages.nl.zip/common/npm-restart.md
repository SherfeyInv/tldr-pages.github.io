# npm restart

> Dit commando is een alias van `npm run restart`.

- Bekijk de documentatie van het originele commando:

`tldr npm run`
