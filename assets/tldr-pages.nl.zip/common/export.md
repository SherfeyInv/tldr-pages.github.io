# export

> Exporteer shellvariabelen naar child-processen.
> Meer informatie: <https://manned.org/export.1posix>.

- Stel een omgevingsvariabele in:

`export {{VARIABELE}}={{waarde}}`

- Voeg een pad toe aan de omgevingsvariabele `PATH`:

`export PATH=$PATH:{{pad/om/toe_te_voegen}}`
