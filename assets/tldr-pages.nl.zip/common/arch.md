# arch

> Geef de naam van de systeemarchitectuur weer.
> Bekijk ook `uname`.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Geef de architectuur van het systeem weer:

`arch`
