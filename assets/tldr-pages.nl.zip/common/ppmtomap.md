# ppmtomap

> Dit commando is vervangen door `pnmcolormap`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtomap.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pnmcolormap`
