# fossil ci

> Dit commando is een alias van `fossil commit`.

- Bekijk de documentatie van het originele commando:

`tldr fossil-commit`
