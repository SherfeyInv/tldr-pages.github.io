# fossil ci

> Dit commando is een alias van `fossil commit`.
> Meer informatie: <https://fossil-scm.org/home/help/commit>.

- Bekijk de documentatie van het originele commando:

`tldr fossil-commit`
