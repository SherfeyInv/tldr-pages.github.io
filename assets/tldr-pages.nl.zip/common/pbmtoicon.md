# pbmtoicon

> Dit commando is vervangen door `pbmtosunicon`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pbmtoicon.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pbmtosunicon`
