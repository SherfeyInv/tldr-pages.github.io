# git stage

> Dit commando is een alias van `git add`.

- Bekijk de documentatie van het originele commando:

`tldr git add`
