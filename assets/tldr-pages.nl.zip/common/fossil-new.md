# fossil new

> Dit commando is een alias van `fossil init`.
> Meer informatie: <https://fossil-scm.org/home/help/new>.

- Bekijk de documentatie van het originele commando:

`tldr fossil-init`
