# fossil new

> Dit commando is een alias van `fossil init`.

- Bekijk de documentatie van het originele commando:

`tldr fossil init`
