# todoman

> Een simpele, gestandaardiseerde, cli todo manager.
> `todoman` is een gebruikelijke naam voor het commando `todo`, maar niet een commando op zichzelf.
> Meer informatie: <https://todoman.readthedocs.io/>.

- Bekijk de documentatie van het originele commando:

`tldr todo`
