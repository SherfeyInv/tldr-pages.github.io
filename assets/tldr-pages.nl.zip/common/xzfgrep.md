# xzfgrep

> Dit commando is een alias van `xzgrep --fixed-strings`.
> Bekijk ook: `fgrep`.

- Bekijk de documentatie van het originele commando:

`tldr xzgrep`
