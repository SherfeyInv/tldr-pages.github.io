# sleep

> Wacht voor een gespecificeerde hoeveelheid tijd.
> Meer informatie: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- Wacht in seconden:

`sleep {{seconden}}`

- Voer een specifiek commando uit na een wachttijd van 20 seconden:

`sleep 20 && {{commando}}`
