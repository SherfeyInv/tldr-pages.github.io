# trash-cli

> Dit commando is een alias van `trash`.
> Meer informatie: <https://github.com/andreafrancia/trash-cli>.

- Bekijk de documentatie van het originele commando:

`tldr trash`
