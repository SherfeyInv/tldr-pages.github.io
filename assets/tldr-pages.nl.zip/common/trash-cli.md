# trash-cli

> Dit commando is een alias van `trash`.

- Bekijk de documentatie van het originele commando:

`tldr trash`
