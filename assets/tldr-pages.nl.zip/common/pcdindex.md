# pcdindex

> Dit commando is hernoemd naar `pcdovtoppm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pcdindex.html>.

- Bekijk de documentatie voor het commando onder zijn huidige naam:

`tldr pcdovtoppm`
