# bird

> BIRD Internet Routing Daemon.
> Routingdaemon met ondersteuning voor BGP, OSPF, Babel en anderen.
> Meer informatie: <https://bird.network.cz/>.

- Start Bird met een specifiek configuratiebestand:

`bird -c {{pad/naar/bird.conf}}`

- Start Bird als een specifieke gebruiker en groep:

`bird -u {{gebruikersnaam}} -g {{groep}}`
