# zstdcat

> Dit commando is een alias van `zstd --decompress --stdout`.

- Bekijk de documentatie van het originele commando:

`tldr zstd`
