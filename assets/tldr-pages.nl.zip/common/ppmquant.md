# ppmquant

> Dit commando is vervangen met `pnmquant` en `pnmremap`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmquant.html>.

- Bekijk de documentatie voor `pnmquant`:

`tldr pnmquant`

- Bekijk de documentatie voor `pnmremap`:

`tldr pnmremap`
