# pngtopnm

> Dit commando is vervangen door `pngtopam`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pngtopnm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pngtopam`
