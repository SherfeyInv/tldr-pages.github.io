# lzegrep

> Dit commando is een alias van `xzgrep --extended-regexp`.
> Bekijk ook: `egrep`.

- Bekijk de documentatie van het originele commando:

`tldr xzgrep`
