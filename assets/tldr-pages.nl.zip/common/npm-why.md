# npm why

> Identificeert waarom een npm-pakket is geïnstalleerd.
> Meer informatie: <https://github.com/amio/npm-why>.

- Toon waarom een npm-pakket is geïnstalleerd:

`npm-why {{pakket}}`
