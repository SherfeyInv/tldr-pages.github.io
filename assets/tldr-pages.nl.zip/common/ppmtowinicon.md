# ppmtowinicon

> Dit commando is vervangen door `pamtowinicon`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtowinicon.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtowinicon`
