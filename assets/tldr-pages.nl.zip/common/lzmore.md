# lzmore

> Dit commando is een alias van `xzmore`.

- Bekijk de documentatie van het originele commando:

`tldr xzmore`
