# ac

> Toon statistieken over hoe lang gebruikers verbonden zijn geweest.
> Meer informatie: <https://man.openbsd.org/ac>.

- Toon hoe lang de huidige gebruiker verbonden is in uren:

`ac`

- Toon hoe lang gebruikers verbonden zijn in uren:

`ac -p`

- Toon hoe lang een bepaalde gebruiker verbonden is in uren:

`ac -p {{gebruikersnaam}}`

- Toon hoe lang een bepaalde gebruiker verbonden is in uren per dag (met totaal):

`ac -dp {{gebruikersnaam}}`
