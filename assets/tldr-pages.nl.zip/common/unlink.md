# unlink

> Verwijder een link naar een bestand van het bestandssysteem.
> De inhoud van het bestand gaat verloren als de link de laatste is naar het bestand.
> Meer informatie: <https://www.gnu.org/software/coreutils/unlink>.

- Verwijder het opgegeven bestand als het de laatste link is:

`unlink {{pad/naar/bestand}}`
