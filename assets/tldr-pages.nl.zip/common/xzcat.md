# xzcat

> Dit commando is een alias van `xz --decompress --stdout`.

- Bekijk de documentatie van het originele commando:

`tldr xz`
