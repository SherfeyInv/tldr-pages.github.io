# platformio

> Dit commando is een alias van `pio`.

- Bekijk de documentatie van het originele commando:

`tldr pio`
