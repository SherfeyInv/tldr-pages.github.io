# pamshadedrelief

> Genereer een schaduwwerking van een hoogtekaart.
> Bekijk ook: `pamcrater`, `ppmrelief`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamshadedrelief.html>.

- Genereer een schaduwwerking afbeelding met de invoer-afbeelding als een hoogtekaart:

`pamshadedrelief < {{pad/naar/invoer.pam}} > {{pad/naar/uitvoer.pam}}`

- Pas de gamma aan van een afbeelding met de gespecificeerde factor:

`pamshadedrelief -gamma {{factor}} < {{pad/naar/invoer.pam}} > {{pad/naar/uitvoer.pam}}`
