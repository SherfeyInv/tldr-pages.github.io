# ppmtogif

> Dit commando is vervangen door `pamtogif`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtogif.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtogif`
