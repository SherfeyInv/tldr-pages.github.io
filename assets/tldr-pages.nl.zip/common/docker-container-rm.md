# docker container rm

> Dit commando is een alias van `docker rm`.
> Meer informatie: <https://docs.docker.com/reference/cli/docker/container/rm/>.

- Bekijk de documentatie van het originele commando:

`tldr docker rm`
