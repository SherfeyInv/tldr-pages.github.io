# afconvert

> Converteren tussen AFF en onbewerkte bestandsindelingen.
> Meer informatie: <https://manned.org/afconvert.1>.

- Gebruik een specifieke extensie (standaard: `aff`):

`afconvert -a {{verlenging}} {{pad/naar/invoer_bestand}} {{pad/naar/uitvoer_bestand1 pad/naar/uitvoer_bestand2 ...}}`

- Gebruik een specifiek compressieniveau (standaard: `7`):

`afconvert -X{{0..7}} {{pad/naar/invoer_bestand}} {{pad/naar/uitvoer_bestand1 pad/naar/uitvoer_bestand2 ...}}`
