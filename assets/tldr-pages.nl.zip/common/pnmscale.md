# pnmscale

> Dit commando is vervangen door `pamscale`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmscale.html>.

- Bekijk documentatie voor `pamscale`:

`tldr pamscale`
