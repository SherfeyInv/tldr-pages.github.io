# gcrane help

> Help biedt hulp voor elk commando in de applicatie.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/gcrane/README.md>.

- Toon help voor een subcommando:

`gcrane help {{command}}`

- Toon help:

`gcrane help {{-h|--help}}`
