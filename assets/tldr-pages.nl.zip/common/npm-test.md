# npm test

> Dit commando is een alias van `npm run test`.

- Bekijk de documentatie van het originele commando:

`tldr npm run`
