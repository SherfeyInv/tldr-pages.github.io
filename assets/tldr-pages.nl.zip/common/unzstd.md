# unzstd

> Dit commando is een alias van `zstd`.

- Bekijk de documentatie van het originele commando:

`tldr zstd`
