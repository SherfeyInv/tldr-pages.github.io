# unzstd

> Dit commando is een alias van `zstd --decompress`.

- Bekijk de documentatie van het originele commando:

`tldr zstd`
