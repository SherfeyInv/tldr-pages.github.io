# gnmic sub

> Dit commando is een alias van `gnmic subscribe`.

- Bekijk de documentatie van het originele commando:

`tldr gnmic subscribe`
