# azure-cli

> Dit commando is een alias van `az`.

- Bekijk de documentatie van het originele commando:

`tldr az`
