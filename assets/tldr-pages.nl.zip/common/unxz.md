# unxz

> Dit commando is een alias van `xz --decompress`.

- Bekijk de documentatie van het originele commando:

`tldr xz`
