# unxz

> Dit commando is een alias van `xz`.
> Meer informatie: <https://manned.org/unxz>.

- Bekijk de documentatie van het originele commando:

`tldr xz`
