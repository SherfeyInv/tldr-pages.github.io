# ppmbrighten

> Dit commando is vervangen door `pambrighten`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmbrighten.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pambrighten`
