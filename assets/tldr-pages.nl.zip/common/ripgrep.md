# ripgrep

> `ripgrep` is de algemene naam voor het commando `rg`.

- Bekijk de documentatie van het originele commando:

`tldr rg`
