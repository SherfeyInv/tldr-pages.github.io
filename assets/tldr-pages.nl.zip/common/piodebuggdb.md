# piodebuggdb

> Dit commando is een alias van `pio debug --interface=gdb`.

- Bekijk de documentatie van het originele commando:

`tldr pio debug`
