# piodebuggdb

> Dit commando is een alias van `pio debug`.

- Bekijk de documentatie van het originele commando:

`tldr pio debug`
