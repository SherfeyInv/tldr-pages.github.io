# rcat

> Dit commando is een alias van `rc`.

- Bekijk de documentatie van het originele commando:

`tldr rc`
