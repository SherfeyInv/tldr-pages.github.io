# tlmgr arch

> Dit commando is een alias van `tlmgr platform`.

- Bekijk de documentatie van het originele commando:

`tldr tlmgr platform`
