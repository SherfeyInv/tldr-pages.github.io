# fossil init

> Initialiseer een nieuwe repository voor een project.
> Bekijk ook: `fossil clone`.
> Meer informatie: <https://fossil-scm.org/home/help/init>.

- Maak een nieuwe repository in een opgegeven bestand:

`fossil init {{pad/naar/bestand}}`
