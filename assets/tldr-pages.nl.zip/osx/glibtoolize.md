# glibtoolize

> Dit commando is een alias van `-p linux libtoolize`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux libtoolize`
