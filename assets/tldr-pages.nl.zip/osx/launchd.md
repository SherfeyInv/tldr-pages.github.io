# launchd

> Dit beheert processen, zowel voor het systeem als voor de gebruiker.
> `launchd` kan niet manueel gestart worden, gebruik `launchctl` om ermee te interacteren.
> Meer informatie: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Draai initialisatie:

`/sbin/launchd`

- Bekijk de documentatie van het originele commando:

`tldr launchctl`
