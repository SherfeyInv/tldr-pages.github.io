# gtimeout

> Dit commando is een alias van `-p linux timeout`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux timeout`
