# gsleep

> Dit commando is een alias van `-p linux sleep`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sleep`
