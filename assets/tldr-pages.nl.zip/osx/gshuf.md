# gshuf

> Dit commando is een alias van `-p linux shuf`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux shuf`
