# gftp

> Dit commando is een alias van `-p linux ftp`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ftp`
