# gupdatedb

> Dit commando is een alias van `-p linux updatedb`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux updatedb`
