# gdirname

> Dit commando is een alias van `-p linux dirname`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux dirname`
