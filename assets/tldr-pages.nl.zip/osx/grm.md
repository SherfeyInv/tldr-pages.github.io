# grm

> Dit commando is een alias van `-p linux rm`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux rm`
