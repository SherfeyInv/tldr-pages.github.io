# gstat

> Dit commando is een alias van `-p linux stat`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux stat`
