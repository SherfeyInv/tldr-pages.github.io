# gegrep

> Dit commando is een alias van `-p linux egrep`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux egrep`
