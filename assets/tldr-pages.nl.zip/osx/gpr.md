# gpr

> Dit commando is een alias van `-p linux pr`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux pr`
