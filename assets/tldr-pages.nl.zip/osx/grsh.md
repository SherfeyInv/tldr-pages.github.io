# grsh

> Dit commando is een alias van `-p linux rsh`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux rsh`
