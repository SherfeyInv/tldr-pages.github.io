# gdircolors

> Dit commando is een alias van `-p linux dircolors`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux dircolors`
