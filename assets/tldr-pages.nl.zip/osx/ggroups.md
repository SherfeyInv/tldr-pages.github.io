# ggroups

> Dit commando is een alias van `-p linux groups`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux groups`
