# gtee

> Dit commando is een alias van `-p linux tee`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tee`
