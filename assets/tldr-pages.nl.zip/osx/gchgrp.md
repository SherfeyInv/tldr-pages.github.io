# gchgrp

> Dit commando is een alias van `-p linux chgrp`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux chgrp`
