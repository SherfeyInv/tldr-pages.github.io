# gindent

> Dit commando is een alias van `-p linux indent`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux indent`
