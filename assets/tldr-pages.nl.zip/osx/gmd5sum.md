# gmd5sum

> Dit commando is een alias van `-p linux md5sum`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux md5sum`
