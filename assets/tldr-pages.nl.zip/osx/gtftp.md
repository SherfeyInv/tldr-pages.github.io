# gtftp

> Dit commando is een alias van `-p linux tftp`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tftp`
