# gsort

> Dit commando is een alias van `-p linux sort`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sort`
