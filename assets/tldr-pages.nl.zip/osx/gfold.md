# gfold

> Dit commando is een alias van `-p linux fold`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux fold`
