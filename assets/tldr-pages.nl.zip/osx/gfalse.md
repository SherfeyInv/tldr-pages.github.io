# gfalse

> Dit commando is een alias van `-p linux false`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux false`
