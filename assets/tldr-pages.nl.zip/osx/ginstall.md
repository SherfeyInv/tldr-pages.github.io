# ginstall

> Dit commando is een alias van `-p linux install`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux install`
