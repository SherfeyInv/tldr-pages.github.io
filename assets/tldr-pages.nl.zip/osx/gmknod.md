# gmknod

> Dit commando is een alias van `-p linux mknod`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux mknod`
