# gfactor

> Dit commando is een alias van `-p linux factor`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux factor`
