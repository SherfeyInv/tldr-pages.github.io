# ggrep

> Dit commando is een alias van `-p linux grep`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux grep`
