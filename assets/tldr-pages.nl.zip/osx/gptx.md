# gptx

> Dit commando is een alias van `-p linux ptx`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ptx`
