# archey

> Stijlvol weergeven van systeeminformatie.
> Meer informatie: <https://github.com/joshfinnie/archey-osx>.

- Toon systeeminformatie:

`archey`

- Toon systeeminformatie zonder gekleurde output:

`archey --nocolor`

- Toon systeeminformatie met gebruik van MacPorts in plaats van Homebrew:

`archey --macports`

- Toon systeeminformatie zonder IP-adrescontrole:

`archey --offline`
