# gprintenv

> Dit commando is een alias van `-p linux printenv`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux printenv`
