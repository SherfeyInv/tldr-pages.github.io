# glogname

> Dit commando is een alias van `-p linux logname`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux logname`
