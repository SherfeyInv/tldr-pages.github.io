# llvm-lipo

> Dit commando is een alias van `lipo`.

- Bekijk de documentatie van het originele commando:

`tldr lipo`
