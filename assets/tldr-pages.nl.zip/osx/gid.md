# gid

> Dit commando is een alias van `-p linux id`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux id`
