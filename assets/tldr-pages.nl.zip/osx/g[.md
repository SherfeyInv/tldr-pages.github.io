# g[

> Dit commando is een alias van `-p linux [`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux [`
