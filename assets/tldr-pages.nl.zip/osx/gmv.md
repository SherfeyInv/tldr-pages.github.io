# gmv

> Dit commando is een alias van `-p linux mv`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux mv`
