# aa

> Dit commando is een alias van `yaa`.

- Bekijk de documentatie van het originele commando:

`tldr yaa`
