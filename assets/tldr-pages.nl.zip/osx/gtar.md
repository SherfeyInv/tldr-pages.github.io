# gtar

> Dit commando is een alias van `-p linux tar`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tar`
