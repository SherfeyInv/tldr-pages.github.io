# gls

> Dit commando is een alias van `-p linux ls`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ls`
