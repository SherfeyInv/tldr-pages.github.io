# gsync

> Dit commando is een alias van `-p linux sync`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sync`
