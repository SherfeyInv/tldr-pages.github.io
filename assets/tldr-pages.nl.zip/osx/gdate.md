# gdate

> Dit commando is een alias van `-p linux date`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux date`
