# ged

> Dit commando is een alias van `-p linux ed`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ed`
