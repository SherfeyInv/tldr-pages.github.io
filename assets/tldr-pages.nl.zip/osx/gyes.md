# gyes

> Dit commando is een alias van `-p linux yes`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux yes`
