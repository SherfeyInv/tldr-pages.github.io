# gchroot

> Dit commando is een alias van `-p linux chroot`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux chroot`
