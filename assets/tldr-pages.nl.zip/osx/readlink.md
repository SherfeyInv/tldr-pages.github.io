# readlink

> Volg symlinks en verkrijg symlink-informatie.
> Meer informatie: <https://www.gnu.org/software/coreutils/readlink>.

- Toon het absolute pad waarnaar de symlink verwijst:

`readlink {{pad/naar/symlink_bestand}}`
