# gtsort

> Dit commando is een alias van `-p linux tsort`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tsort`
