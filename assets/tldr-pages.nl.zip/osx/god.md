# god

> Dit commando is een alias van `-p linux od`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux od`
