# gkill

> Dit commando is een alias van `-p linux kill`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux kill`
