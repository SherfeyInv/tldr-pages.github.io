# bugreportz

> Genereer een gezipt Android-bugrapport.
> Dit commando kan alleen worden gebruikt via `adb shell`.
> Meer informatie: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- Genereer een compleet gezipt bugrapport van een Android-apparaat:

`bugreportz`

- Toon de voortgang van een lopende `bugreportz` actie:

`bugreportz -p`

- Toon de help:

`bugreportz -h`

- Toon de versie:

`bugreportz -v`
