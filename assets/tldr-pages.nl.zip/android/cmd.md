# cmd

> Android service manager.
> Meer informatie: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- Toon een [l]ijst met alle draaiende services:

`cmd -l`

- Roep een specifieke service aan:

`cmd {{service}}`

- Roep een specifieke service aan met specifieke argumenten:

`cmd {{service}} {{argument1 argument2 ...}}`
