# title

> কমান্ড প্রম্পট উইন্ডোর শিরোনাম সেট করুন।
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/administration/windows-commands/title>।

- বর্তমান কমান্ড প্রম্পট উইন্ডোর শিরোনাম সেট করুন:

`title {{নতুন_শিরোনাম}}`
