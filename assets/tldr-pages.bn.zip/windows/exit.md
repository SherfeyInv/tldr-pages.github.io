# exit

> বর্তমান CMD ইনস্ট্যান্স বা বর্তমান ব্যাচ ফাইল থেকে বাহির হোন।
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>।

- বর্তমান CMD উদাহরণ থেকে বাহির হোন:

`exit`

- বর্তমান ব্যাচ স্ক্রিপ্ট থেকে বাহির হোন:

`exit /b`

- নির্দিষ্ট প্রস্থান কোড ব্যবহার করে বন্ধ করুন:

`exit {{2}}`
