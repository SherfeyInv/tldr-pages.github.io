# sc_warts2text

> Einfache Ausgabe der in einer `warts`-Datei enthaltenen Informationen.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Gib die Informationen in einer `warts`-Datei als Text aus:

`sc_warts2text {{path/to/file1.warts path/to/file2.warts ...}}`
