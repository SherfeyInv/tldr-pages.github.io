# exit

> Verlasse die Shell.
> Weitere Informationen: <https://manned.org/exit.1posix>.

- Beende die Shell mit dem Exitcode des zuletzt ausgeführten Befehls:

`exit`

- Beende die Shell mit dem angegebenen Exitcode:

`exit {{exitcode}}`
