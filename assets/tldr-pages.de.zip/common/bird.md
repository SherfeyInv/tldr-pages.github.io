# bird

> BIRD Internet Routing Daemon.
> Routing-Daemon mit Unterstützung für BGP, OSPF, Babel und weitere.
> Weitere Informationen: <https://bird.network.cz/>.

- Starte `bird` mit einer bestimmten Konfigurationsdatei:

`bird -c {{pfad/zu/bird.conf}}`

- Starte `bird` als spezifischer Benutzer und Gruppe:

`bird -u {{benutzername}} -g {{gruppe}}`
