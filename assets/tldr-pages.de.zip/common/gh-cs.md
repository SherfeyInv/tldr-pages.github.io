# gh cs

> Dieser Befehl ist ein Alias von  `gh codespace`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr gh codespace`
