# platformio

> Dieser Befehl ist ein Alias von `pio`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr pio`
