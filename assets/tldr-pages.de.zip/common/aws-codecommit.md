# aws codecommit

> AWS CodeCommit ist ein verwalteter Versionskontrolldienst, der private Git Repositories hostet.
> Weitere Informationen: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Zeige Hilfe für einen bestimmten Befehl an:

`aws codecommit {{befehl}} help`

- Zeige Hilfe an:

`aws codecommit help`
