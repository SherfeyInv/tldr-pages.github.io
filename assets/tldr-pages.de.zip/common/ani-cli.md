# ani-cli

> Ein Cli zum Stöbern und Anschauen von Anime.
> Weitere Informationen: <https://github.com/pystardust/ani-cli>.

- Anime nach Namen suchen:

`ani-cli "{{anime_name}}"`

- Folge herunterladen:

`ani-cli -d "{{anime_name}}"`

- VLC als Medienspieler verwenden:

`ani-cli -v "{{anime_name}}"`

- Anzuschauende Episode angeben:

`ani-cli -e {{episoden_nummer}} "{{anime_name}}"`

- Anime aus Verlauf weiterschauen:

`ani-cli -c`

- Aktualisiere `ani-cli`:

`ani-cli -U`
