# llvm-g++

> Dieser Befehl ist ein Alias von `clang++`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr clang++`
