# lzma

> Dieser Befehl ist ein Alias von `xz`.
> Weitere Informationen: <https://manned.org/lzma>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr xz`
