# cal

> Zeige einen Kalender mit dem aktuellen Tag hervorgehoben an.
> Siehe auch: `gcal`.
> Weitere Informationen: <https://manned.org/cal.1p>.

- Zeige einen Kalender für den aktuellen Monat an:

`cal`

- Zeige einen Kalender für ein bestimmtes Jahr an:

`cal {{Jahr}}`

- Zeige einen Kalender für einen bestimmten Monat und Jahr an:

`cal {{Monat}} {{Jahr}}`
