# pystun3

> Classic STUN-Client, geschrieben in Python.
> Weitere Informationen: <https://github.com/talkiq/pystun3>.

- Stelle eine STUN-Anfrage:

`pystun3`

- Stelle eine STUN-Anfrage und spezifiziere den STUN-Server:

`pystun3 --stun-host {{stun.1und1.de}}`

- Stelle eine STUN-Anfrage und spezifiziere den Quellport:

`pystun3 --source-port {{7932}}`
