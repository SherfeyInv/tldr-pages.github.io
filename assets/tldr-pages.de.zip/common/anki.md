# anki

> Leistungsstarkes, intelligentes Lernkartenprogramm.
> Weitere Informationen: <https://docs.ankiweb.net>.

- Starte `anki`:

`anki`

- Starte `anki` mit einem bestimmten Profil:

`anki -p {{profil_name}}`

- Starte `anki` in einer bestimmten Sprache:

`anki -l {{sprache}}`

- Starte `anki` von einem bestimmten Verzeichneis anstelle des Standardverzeichnis (`~/Anki`):

`anki -b {{pfad/zu/verzeichnis}}`
