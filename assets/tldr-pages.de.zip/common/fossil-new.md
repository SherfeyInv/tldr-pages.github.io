# fossil new

> Dieser Befehl ist ein Alias von `fossil init`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fossil init`
