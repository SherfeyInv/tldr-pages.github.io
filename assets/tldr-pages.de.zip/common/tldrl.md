# tldrl

> Dieser Befehl ist ein Alias von `tldr-lint`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr tldr-lint`
