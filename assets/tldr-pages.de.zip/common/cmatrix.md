# cmatrix

> Zeigt einen scrollenden, Matrix-ähnlichen Bildschirm im Terminal an.
> Weitere Informationen: <https://github.com/abishekvashok/cmatrix>.

- Aktiviere [a]synchrones Scrollen:

`cmatrix -a`

- Ändere die Text[C]olor (standardmäßig grün):

`cmatrix -C {{red}}`

- Aktiviere den [r]egenbogen-Modus:

`cmatrix -r`

- Verwende eine Bildschirm[u]pdate-Verzögerung von 100 Zentisekunden (1 Sekunde):

`cmatrix -u 100`
