# ripgrep

> Dieser Befehl ist ein Alias von `rg`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr rg`
