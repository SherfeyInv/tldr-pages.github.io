# vimtutor

> Vim-Tutor zum Erlernen grundlegender Vim-Befehle.
> Weitere Informationen: <https://manned.org/vimtutor>.

- Öffne den Vim-Tutor in der gegebenen Sprache (de, en, fr, ...):

`vimtutor {{sprache}}`

- Beende den Vim-Tutor:

`<Esc> :q <Enter>`
