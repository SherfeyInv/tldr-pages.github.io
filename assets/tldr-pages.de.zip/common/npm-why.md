# npm why

> Identifiziert, warum ein npm Paket installiert ist.
> Weitere Informationen: <https://github.com/amio/npm-why>.

- Zeige, warum ein npm Paket installiert ist:

`npm-why {{paket_name}}`
