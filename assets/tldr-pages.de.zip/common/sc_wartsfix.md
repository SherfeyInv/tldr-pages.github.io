# sc_wartsfix

> Rettet beschädigte `warts`-Dateien.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Speichere alle Datensätze (in einer separaten Datei) bis zum letzten intakten Datensatz:

`sc_wartsfix {{path/to/file1.warts path/to/file2.warts ...}}`
