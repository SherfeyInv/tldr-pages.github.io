# sc_ttlexp

> Ausgabe der Quelladressen von ICMP TTL expire-Nachrichten in `warts`-Dateien.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Gib die Quelladressen von ICMP TTL expire-Nachrichten in einer `warts`-Datei nacheinander aus:

`sc_ttlexp {{path/to/file1.warts path/to/file2.warts ...}}`
