# vi

> Dieser Befehl ist ein Alias von `vim`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr vim`
