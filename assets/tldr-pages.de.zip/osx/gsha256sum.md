# gsha256sum

> Dieser Befehl ist ein Alias von `-p linux sha256sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux sha256sum`
