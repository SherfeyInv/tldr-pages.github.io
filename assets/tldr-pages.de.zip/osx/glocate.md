# glocate

> Dieser Befehl ist ein Alias von `-p linux locate`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux locate`
