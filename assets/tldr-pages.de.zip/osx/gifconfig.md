# gifconfig

> Dieser Befehl ist ein Alias von `-p linux ifconfig`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux ifconfig`
