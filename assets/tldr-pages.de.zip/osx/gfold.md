# gfold

> Dieser Befehl ist ein Alias von `-p linux fold`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux fold`
