# gcut

> Dieser Befehl ist ein Alias von `-p linux cut`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux cut`
