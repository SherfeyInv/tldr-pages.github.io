# gpaste

> Dieser Befehl ist ein Alias von `-p linux paste`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux paste`
