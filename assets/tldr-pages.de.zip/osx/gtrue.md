# gtrue

> Dieser Befehl ist ein Alias von `-p linux true`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux true`
