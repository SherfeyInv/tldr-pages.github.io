# launchd

> Dieser Befehl ist ein Alias von `launchctl`.
> Weitere Informationen: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr launchctl`
