# gtelnet

> Dieser Befehl ist ein Alias von `-p linux telnet`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux telnet`
