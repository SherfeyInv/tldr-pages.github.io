# glibtool

> Dieser Befehl ist ein Alias von `-p linux libtool`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux libtool`
