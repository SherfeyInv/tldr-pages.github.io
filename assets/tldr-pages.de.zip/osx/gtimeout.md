# gtimeout

> Dieser Befehl ist ein Alias von `-p linux timeout`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux timeout`
