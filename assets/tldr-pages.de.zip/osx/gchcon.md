# gchcon

> Dieser Befehl ist ein Alias von `-p linux chcon`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux chcon`
