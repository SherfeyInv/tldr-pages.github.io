# ggroups

> Dieser Befehl ist ein Alias von `-p linux groups`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux groups`
