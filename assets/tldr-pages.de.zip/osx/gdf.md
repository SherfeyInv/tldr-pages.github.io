# gdf

> Dieser Befehl ist ein Alias von `-p linux df`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux df`
