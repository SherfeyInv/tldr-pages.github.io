# ghead

> Dieser Befehl ist ein Alias von `-p linux head`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux head`
