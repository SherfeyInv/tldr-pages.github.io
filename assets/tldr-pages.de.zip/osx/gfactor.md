# gfactor

> Dieser Befehl ist ein Alias von `-p linux factor`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux factor`
