# gbasename

> Dieser Befehl ist ein Alias von `-p linux basename`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux basename`
