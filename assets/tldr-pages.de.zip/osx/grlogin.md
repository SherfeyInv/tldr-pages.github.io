# grlogin

> Dieser Befehl ist ein Alias von `-p linux rlogin`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux rlogin`
