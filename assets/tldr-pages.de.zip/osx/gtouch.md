# gtouch

> Dieser Befehl ist ein Alias von `-p linux touch`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux touch`
