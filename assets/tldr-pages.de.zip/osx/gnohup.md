# gnohup

> Dieser Befehl ist ein Alias von `-p linux nohup`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux nohup`
