# gmd5sum

> Dieser Befehl ist ein Alias von `-p linux md5sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux md5sum`
