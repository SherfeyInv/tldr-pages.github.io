# gping6

> Dieser Befehl ist ein Alias von `-p linux ping6`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux ping6`
