# gkill

> Dieser Befehl ist ein Alias von `-p linux kill`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux kill`
