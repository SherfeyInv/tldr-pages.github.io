# gstty

> Dieser Befehl ist ein Alias von `-p linux stty`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux stty`
