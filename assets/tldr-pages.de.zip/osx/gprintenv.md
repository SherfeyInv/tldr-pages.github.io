# gprintenv

> Dieser Befehl ist ein Alias von `-p linux printenv`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux printenv`
