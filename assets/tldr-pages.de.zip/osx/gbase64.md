# gbase64

> Dieser Befehl ist ein Alias von `-p linux base64`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux base64`
