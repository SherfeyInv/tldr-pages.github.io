# gegrep

> Dieser Befehl ist ein Alias von `-p linux egrep`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux egrep`
