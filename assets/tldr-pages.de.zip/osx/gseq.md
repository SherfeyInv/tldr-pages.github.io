# gseq

> Dieser Befehl ist ein Alias von `-p linux seq`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux seq`
