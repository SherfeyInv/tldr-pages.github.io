# gbasenc

> Dieser Befehl ist ein Alias von `-p linux basenc`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux basenc`
