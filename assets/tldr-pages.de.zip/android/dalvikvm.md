# dalvikvm

> Androids Java Virtual Machine.
> Weitere Informationen: <https://source.android.com/docs/core/runtime>.

- Starte ein Java-Programm:

`dalvikvm -classpath {{pfad/zu/datei.jar}} {{klassenname}}`
