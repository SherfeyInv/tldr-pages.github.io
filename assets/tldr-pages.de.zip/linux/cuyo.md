# cuyo

> Tetris-ähnliches Spiel.
> Weitere Informationen: <https://www.karimmi.de/cuyo/>.

- Starte ein neues Spiel:

`cuyo`

- Verschiebe die Teile horizontal:

`{{A|D|Pfeiltaste Links|Pfeiltaste Rechts}}`

- Drehe die Teile:

`{{W|Pfeiltaste nach oben}}`

- Lasse die Teile schnell fallen:

`{{S|Pfeiltaste nach unten}}`
