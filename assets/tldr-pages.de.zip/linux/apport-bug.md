# apport-bug

> Reiche einen Fehlerbericht über Ubuntu ein.
> Weitere Informationen: <https://wiki.ubuntu.com/Apport>.

- Reiche einen Fehlerbericht über das gesamte System ein:

`apport-bug`

- Reiche einen Fehlerbericht über ein bestimmtes Paket ein:

`apport-bug {{paket}}`

- Reiche einen Fehlerbericht über eine bestimmte ausführbare Datei ein:

`apport-bug {{pfad/zum/executable}}`

- Reiche einen Fehlerbericht über einen bestimmten Prozess ein:

`apport-bug {{PID}}`
