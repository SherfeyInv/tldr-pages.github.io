# anbox

> Führe Android-Anwendungen auf jedem Linux-Betriebssystem aus.
> Weitere Informationen: <https://manned.org/anbox>.

- Starte Anbox im App Manager:

`anbox launch --package={{org.anbox.appmgr}} --component={{org.anbox.appmgr.AppViewActivity}}`
