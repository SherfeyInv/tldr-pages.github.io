# batcat

> Dieser Befehl ist ein Alias von `bat`.
> Weitere Informationen: <https://github.com/sharkdp/bat>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr bat`
