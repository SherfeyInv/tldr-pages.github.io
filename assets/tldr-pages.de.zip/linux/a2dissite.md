# a2dissite

> Deaktiviert einen Apache virtuellen Host auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2dissite.8>.

- Deaktiviere einen virtuellen Host:

`sudo a2dissite {{virtueller_host}}`

- Zeige keine Informationsnachrichten an:

`sudo a2dissite --quiet {{virtueller_host}}`
