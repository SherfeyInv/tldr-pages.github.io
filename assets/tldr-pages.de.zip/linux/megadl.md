# megadl

> Dieser Befehl ist ein Alias von `megatools-dl`.
> Weitere Informationen: <https://megatools.megous.com/man/megatools-dl.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr megatools-dl`
