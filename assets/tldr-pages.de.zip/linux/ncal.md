# ncal

> Dieser Befehl ist ein Alias von `cal`.
> Weitere Informationen: <https://manned.org/ncal>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cal`
