# iwr

> Dieser Befehl ist ein Alias von `invoke-webrequest`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr invoke-webrequest`
