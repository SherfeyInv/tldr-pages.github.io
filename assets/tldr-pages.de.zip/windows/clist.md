# clist

> Dieser Befehl ist ein Alias von `choco list`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco list`
