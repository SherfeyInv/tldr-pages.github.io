# cinst

> Dieser Befehl ist ein Alias von `choco install`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco install`
