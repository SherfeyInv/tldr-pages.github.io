# sls

> Dieser Befehl ist ein Alias von `Select-String`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr select-string`
