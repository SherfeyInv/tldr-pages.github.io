# rd

> Dieser Befehl ist ein Alias von `rmdir`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr rmdir`
