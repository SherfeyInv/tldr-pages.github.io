# pwsh where

> Dieser Befehl ist ein Alias von `Where-Object`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr Where-Object`
