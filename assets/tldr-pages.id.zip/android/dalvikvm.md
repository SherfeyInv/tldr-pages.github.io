# dalvikvm

> Mesin virtual Java untuk Android.
> Informasi lebih lanjut: <https://source.android.com/docs/core/runtime>.

- Jalankan sebuah program Java:

`dalvikvm -classpath {{jalan/menuju/file.jar}} {{nama_kelas}}`
