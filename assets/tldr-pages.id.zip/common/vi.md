# vi

> Perintah ini merupakan alias dari `vim`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr vim`
