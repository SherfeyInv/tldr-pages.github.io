# banner

> Cetak argumen perintah ini sebagai suatu seni teks ASCII (ASCII art).
> Informasi lebih lanjut: <https://manned.org/banner>.

- Tampilkan sebuah pesan teks sebagai teks spanduk teks ASCII besar (penggunaan tanda petik bersifat opsional):

`banner "{{Halo Dunia}}"`

- Tampilkan pesan dengan ukuran lebar ([w]idth) sebesar 50 karakter:

`banner -w 50 "{{Halo Dunia}}"`

- Baca teks dari `stdin`:

`banner`
