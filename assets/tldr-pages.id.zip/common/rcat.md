# rcat

> Perintah ini merupakan alias dari `rc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr rc`
