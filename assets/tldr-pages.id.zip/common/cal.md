# cal

> Tampilkan kalender dengan menyorot tanggal saat ini.
> Lihat juga: `gcal`.
> Informasi lebih lanjut: <https://manned.org/cal.1p>.

- Tampilkan kalender untuk bulan saat ini:

`cal`

- Tampilkan kalender untuk suatu tahun:

`cal {{tahun}}`

- Tampilkan kalender untuk suatu bulan dalam tahun:

`cal {{bulan}} {{tahun}}`
