# tlmgr arch

> Perintah ini merupakan alias dari `tlmgr platform`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr tlmgr platform`
