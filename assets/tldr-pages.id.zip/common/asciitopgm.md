# asciitopgm

> Ubah format gambar ASCII menuju suatu berkas PGM.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/asciitopgm.html>.

- Baca data ASCII sebagai input dan hasilkan gambar PGM dengan nilai piksel yang merupakan perkiraan "kecerahan" karakter ASCII:

`asciitopgm {{jalan/menuju/input}} > {{jalan/menuju/output.pgm}}`

- Tampilkan informasi versi:

`asciitopgm -version`
