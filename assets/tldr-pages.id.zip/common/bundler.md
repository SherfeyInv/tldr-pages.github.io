# bundler

> Perintah ini merupakan alias dari `bundle`.
> Informasi lebih lanjut: <https://bundler.io/man/bundle.1.html>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr bundle`
