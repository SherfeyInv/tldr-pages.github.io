# open

> `open` dapat merujuk ke beberapa perintah dengan nama yang sama.

- Lihat dokumentasi perintah `open` yang disediakan dalam macOS:

`tldr open -p osx`

- Lihat dokumentasi perintah `open` yang disediakan dalam fish:

`tldr open.fish`
