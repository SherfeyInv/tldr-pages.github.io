# apktool

> Me-reverse engineer berkas APK.
> Informasi lebih lanjut: <https://ibotpeaches.github.io/Apktool/>.

- Bongkar isi ([d]ekode) berkas APK:

`apktool d {{berkas.apk}}`

- [b]angun kode sumber dalam suatu direktori menjadi berkas APK:

`apktool b {{jalan/menuju/direktori}}`

- Pasang ([i]nstal) dan simpan komponen [f]rameworks dari suatu berkas APK:

`apktool if {{framework.apk}}`
