# pbmtoatk

> Ubah suatu gambar PBM menjadi suatu objek raster Andrew Toolkit.
> Lihat juga: `atktopbm`.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/pbmtoatk.html>.

- Ubah suatu gambar PBM menjadi suatu objek raster Andrew Toolkit:

`pbmtoatk {{jalan/menuju/gambar.pbm}} > {{jalan/menuju/output.atk}}`
