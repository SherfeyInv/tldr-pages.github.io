# vue serve

> Sub-perintah yang disediakan oleh `@vue/cli` dan `@vue/cli-service-global` yang memungkinkan prototipe cepat.
> Informasi lebih lanjut: <https://cli.vuejs.org/guide/prototyping.html>.

- Sajikan berkas `.js` or `.vue` pada mode pengembangan tanpa konfigurasi:

`vue serve {{nama_file}}`
