# fossil delete

> Perintah ini merupakan alias dari `fossil rm`.
> Informasi lebih lanjut: <https://fossil-scm.org/home/help/delete>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fossil rm`
