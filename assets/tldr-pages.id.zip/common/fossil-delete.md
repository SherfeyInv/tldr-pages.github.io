# fossil delete

> Perintah ini merupakan alias dari `fossil rm`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fossil rm`
