# freshclam

> Mutakhirkan basis data (database) definisi virus untuk program antivirus ClamAV.
> Informasi lebih lanjut: <https://www.clamav.net>.

- Mutakhirkan basis data (database) definisi virus:

`freshclam`
