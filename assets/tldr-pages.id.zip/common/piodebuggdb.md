# piodebuggdb

> Perintah ini merupakan alias dari `pio debug`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pio debug`
