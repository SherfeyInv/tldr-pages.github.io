# aria2

> Perintah ini merupakan alias dari `aria2c`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr aria2c`
