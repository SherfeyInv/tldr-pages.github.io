# gnmic sub

> Perintah ini merupakan alias dari `gnmic subscribe`.
> Informasi lebih lanjut: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gnmic subscribe`
