# gnmic sub

> Perintah ini merupakan alias dari `gnmic subscribe`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gnmic subscribe`
