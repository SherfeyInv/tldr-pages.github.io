# anki

> Program manajemen flashcard (kartu pintar) yang kuat dan cerdas.
> Informasi lebih lanjut: <https://docs.ankiweb.net>.

- Jalankan program GUI:

`anki`

- Gunakan [p]rofil tertentu untuk mengakses flashcard:

`anki -p {{nama_profil}}`

- Gunakan suatu bahasa ([l]anguage):

`anki -l {{bahasa}}`

- Gunakan direktori non-default untuk memuat data flashcard (tersimpan secara default dalam `~/Anki`):

`anki -b {{jalan/menuju/direktori}}`
