# antibody

> Program manajemen plugin syel "si paling cepat".
> Informasi lebih lanjut: <https://getantibody.github.io>.

- Gabungkan semua plugin untuk dimuat dalam syel secara statis:

`antibody bundle < {{~/.zsh_plugins.txt}} > {{~/.zsh_plugins.sh}}`

- Mutakhirkan seluruh bundel:

`antibody update`

- Tampilkan seluruh plugin yang terpasang:

`antibody list`
