# llvm-objdump

> Perintah ini merupakan alias dari `objdump`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr objdump`
