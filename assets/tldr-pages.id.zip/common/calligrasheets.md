# calligrasheets

> Aplikasi pengolah lembar kerja (spreadsheet), bagian dari Calligra.
> Lihat juga: `calligraflow`, `calligrastage`, `calligrawords`.
> Informasi lebih lanjut: <https://manned.org/calligrasheets>.

- Buka aplikasi pengolah lembar kerja (spreadsheet):

`calligrasheets`

- Buka suatu berkas:

`calligrasheets {{jalan/menuju/berkas}}`

- Tampilkan informasi bantuan atau versi aplikasi:

`calligrasheets --{{help|version}}`
