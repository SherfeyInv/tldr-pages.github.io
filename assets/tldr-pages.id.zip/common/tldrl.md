# tldrl

> Perintah ini merupakan alias dari `tldr-lint`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr tldr-lint`
