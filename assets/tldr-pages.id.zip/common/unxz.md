# unxz

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/unxz>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr xz`
