# unxz

> Perintah ini merupakan alias dari `xz`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr xz`
