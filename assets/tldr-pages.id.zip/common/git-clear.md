# git clear

> Bersihkan isi direktori kerja Git menuju kondisi semula (seperti disalin melalui `git clone`) pada cabang saat ini, termasuk berkas-berkas yang dikecualikan menurut daftar `.gitignore`.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-clear>.

- Setel ulang seluruh isi berkas yang dilacak oleh Git, serta hapus seluruh berkas yang tak dilacak meskipun dikecualikan menurut daftar `.gitignore`:

`git clear`
