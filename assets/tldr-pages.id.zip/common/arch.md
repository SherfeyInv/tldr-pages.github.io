# arch

> Tampilkan nama arsitektur sistem saat ini.
> Lihat juga: `uname`.
> Informasi lebih lanjut: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Tampilkan informasi arsitektur sistem saat ini:

`arch`
