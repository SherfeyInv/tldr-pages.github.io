# git credential-cache

> Pembantu Git untuk menyimpan kata sandi secara sementara pada memori.
> Informasi lebih lanjut: <https://git-scm.com/docs/git-credential-cache>.

- Simpan kredensial Git untuk jangka waktu yang ditentukan:

`git config credential.helper 'cache --timeout={{waktu_dalam_hitungan_detik}}'`
