# cola

> Perintah ini merupakan alias dari `git-cola`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr git-cola`
