# git abort

> Batalkan proses penyatuan melalui rebase, merge, atau cherry-pick yang sedang berlangsung.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-abort>.

- Batalkan proses penyatuan (rebase, merge, atau cherry-pick) yang sedang berlangsung:

`git abort`
