# git browse

> Lihat isi repositori dalam aplikasi peramban web (web browser) default.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-browse>.

- Buka repositori dalam sumber/hulu jauh (upstream remote) utama pada peramban web default:

`git browse`

- Buka repositori dalam sumber/hulu jauh (upstream remote) tertentu pada peramban web default:

`git browse {{hulu_jauh}}`
