# git credential-store

> Pembantu Git untuk menyimpan kata sandi pada perangkat penyimpanan.
> Informasi lebih lanjut: <https://git-scm.com/docs/git-credential-store>.

- Simpan kredensial-kredensial Git pada suatu berkas:

`git config credential.helper 'store --file={{jalan/menuju/berkas}}'`
