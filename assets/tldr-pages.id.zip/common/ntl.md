# ntl

> Perintah ini merupakan alias dari `netlify`.
> Informasi lebih lanjut: <https://cli.netlify.com>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr netlify`
