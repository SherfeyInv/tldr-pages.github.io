# platformio

> Perintah ini merupakan alias dari `pio`.
> Informasi lebih lanjut: <https://docs.platformio.org/en/latest/core/userguide/>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pio`
