# platformio

> Perintah ini merupakan alias dari `pio`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pio`
