# fossil new

> Perintah ini merupakan alias dari `fossil init`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fossil init`
