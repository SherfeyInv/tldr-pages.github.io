# atktopbm

> Ubah suatu objek raster Andrew Toolkit menjadi suatu gambar PBM.
> Lihat juga: `pbmtoatk`.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/atktopbm.html>.

- Ubah suatu objek raster Andrew Toolkit menjadi suatu gambar PBM:

`atktopbm {{jalan/menuju/gambar.atk}} > {{jalan/menuju/output.pbm}}`
