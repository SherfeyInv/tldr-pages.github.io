# gh cs

> Perintah ini merupakan alias dari  `gh codespace`.
> Informasi lebih lanjut: <https://cli.github.com/manual/gh_codespace>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gh codespace`
