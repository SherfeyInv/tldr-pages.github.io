# abduco

> Manajer sesi Terminal.
> Informasi lebih lanjut: <https://www.brain-dump.org/projects/abduco/>.

- Tampilkan sesi-sesi yang sedang aktif:

`abduco`

- Buk[A] sesi saat ini, atau buka baru jika tidak ditemukan, dengan nama yang ditentukan:

`abduco -A {{nama}} {{bash}}`

- Buk[A] sesi baru atau saat ini menggunakan `dvtm`:

`abduco -A {{nama}}`

- Keluar dari sesi:

`<Ctrl> + \`

- Buk[A] sesi saat ini dalam mode non-interaktif alias [r]ead-only:

`abduco -Ar {{name}}`
