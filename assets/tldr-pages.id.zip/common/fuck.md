# fuck

> Mengoreksi perintah konsol sebelumnya.
> Informasi lebih lanjut: <https://github.com/nvbn/thefuck>.

- Memasang `fuck` alias ke alat `thefuck`:

`eval "$(thefuck --alias)"`

- Mencoba mencocokkan aturan untuk perintah sebelumnya:

`fuck`

- Langsung memilih pilihan pertama (argumen yang benar tergantung dari tingkat kejengkelan):

`fuck --{{yes|yeah|hard}}`
