# laravel-zero

> Pasang framework Laravel Zero dari command-line.
> Informasi lebih lanjut: <https://laravel-zero.com>.

- Buat aplikasi Laravel Zero baru:

`laravel-zero new {{nama}}`

- Perbarui pemasang ke versi terkini:

`laravel-zero self-update`

- Lihat daftar perintah yang tersedia:

`laravel-zero list`
