# ptpython3

> Perintah ini merupakan alias dari `ptpython`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ptpython`
