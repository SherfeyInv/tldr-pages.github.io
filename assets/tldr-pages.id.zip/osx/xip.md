# xip

> Kompres atau ekstrak file dari/dalam arsip xip yang .
> Jangan gunakan alat ini untuk membuat arsip baru, karena macOS hanya menerima arsip xip yang berasal atau ditandatangani oleh Apple.
> Informasi lebih lanjut: <https://keith.github.io/xcode-man-pages/xip.1.html>.

- Ekstrak arsip xip ke dalam direktori saat ini:

`xip --expand {{jalan/menuju/file.xip}}`
