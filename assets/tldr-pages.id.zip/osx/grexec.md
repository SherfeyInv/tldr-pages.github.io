# grexec

> Perintah ini merupakan alias dari `-p linux rexec`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux rexec`
