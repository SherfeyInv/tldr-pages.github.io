# gtalk

> Perintah ini merupakan alias dari `-p linux talk`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux talk`
