# gpr

> Perintah ini merupakan alias dari `-p linux pr`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux pr`
