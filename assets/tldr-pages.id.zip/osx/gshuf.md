# gshuf

> Perintah ini merupakan alias dari `-p linux shuf`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux shuf`
