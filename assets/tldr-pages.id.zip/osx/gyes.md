# gyes

> Perintah ini merupakan alias dari `-p linux yes`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux yes`
