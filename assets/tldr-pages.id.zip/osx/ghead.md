# ghead

> Perintah ini merupakan alias dari `-p linux head`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux head`
