# gfind

> Perintah ini merupakan alias dari `-p linux find`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux find`
