# gdirname

> Perintah ini merupakan alias dari `-p linux dirname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux dirname`
