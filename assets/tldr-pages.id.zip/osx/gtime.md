# gtime

> Perintah ini merupakan alias dari `-p linux time`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux time`
