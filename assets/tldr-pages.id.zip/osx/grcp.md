# grcp

> Perintah ini merupakan alias dari `-p linux rcp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux rcp`
