# gtar

> Perintah ini merupakan alias dari `-p linux tar`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tar`
