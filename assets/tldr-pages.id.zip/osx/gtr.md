# gtr

> Perintah ini merupakan alias dari `-p linux tr`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tr`
