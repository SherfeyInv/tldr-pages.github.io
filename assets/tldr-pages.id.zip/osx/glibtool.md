# glibtool

> Perintah ini merupakan alias dari `-p linux libtool`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux libtool`
