# gchown

> Perintah ini merupakan alias dari `-p linux chown`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux chown`
