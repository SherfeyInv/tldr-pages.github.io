# glogger

> Perintah ini merupakan alias dari `-p linux logger`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux logger`
