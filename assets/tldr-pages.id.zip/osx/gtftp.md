# gtftp

> Perintah ini merupakan alias dari `-p linux tftp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tftp`
