# ghostname

> Perintah ini merupakan alias dari `-p linux hostname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux hostname`
