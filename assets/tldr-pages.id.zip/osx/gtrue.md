# gtrue

> Perintah ini merupakan alias dari `-p linux true`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux true`
