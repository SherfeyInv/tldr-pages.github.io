# gb2sum

> Perintah ini merupakan alias dari `-p linux b2sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux b2sum`
