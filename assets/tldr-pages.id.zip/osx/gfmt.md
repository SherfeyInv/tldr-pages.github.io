# gfmt

> Perintah ini merupakan alias dari `-p linux fmt`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux fmt`
