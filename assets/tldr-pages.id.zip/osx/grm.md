# grm

> Perintah ini merupakan alias dari `-p linux rm`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux rm`
