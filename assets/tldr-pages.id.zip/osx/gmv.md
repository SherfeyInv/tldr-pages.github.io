# gmv

> Perintah ini merupakan alias dari `-p linux mv`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux mv`
