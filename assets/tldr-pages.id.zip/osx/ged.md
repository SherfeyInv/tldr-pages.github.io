# ged

> Perintah ini merupakan alias dari `-p linux ed`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux ed`
