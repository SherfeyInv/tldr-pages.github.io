# gunexpand

> Perintah ini merupakan alias dari `-p linux unexpand`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux unexpand`
