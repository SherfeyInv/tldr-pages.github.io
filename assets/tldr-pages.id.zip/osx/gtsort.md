# gtsort

> Perintah ini merupakan alias dari `-p linux tsort`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tsort`
