# gsort

> Perintah ini merupakan alias dari `-p linux sort`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux sort`
