# gsed

> Perintah ini merupakan alias dari `-p linux sed`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux sed`
