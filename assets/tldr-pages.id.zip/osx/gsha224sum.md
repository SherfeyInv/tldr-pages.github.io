# gsha224sum

> Perintah ini merupakan alias dari `-p linux sha224sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux sha224sum`
