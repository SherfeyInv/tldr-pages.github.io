# gsha384sum

> Perintah ini merupakan alias dari `-p linux sha384sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux sha384sum`
