# gcp

> Perintah ini merupakan alias dari `-p linux cp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux cp`
