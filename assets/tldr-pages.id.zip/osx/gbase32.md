# gbase32

> Perintah ini merupakan alias dari `-p linux base32`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux base32`
