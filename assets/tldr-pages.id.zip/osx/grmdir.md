# grmdir

> Perintah ini merupakan alias dari `-p linux rmdir`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux rmdir`
