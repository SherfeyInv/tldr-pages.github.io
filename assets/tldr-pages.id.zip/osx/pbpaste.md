# pbpaste

> Kirim isi papan klip (clipboard) ke output standar.
> Informasi lebih lanjut: <https://keith.github.io/xcode-man-pages/pbpaste.1.html>.

- Tulis konten papan klip ke dalam sebuah file:

`pbpaste > {{file}}`

- Gunakan konten papan klip sebagai input bagi sebuah perintah:

`pbpaste | grep foo`
