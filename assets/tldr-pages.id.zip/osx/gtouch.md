# gtouch

> Perintah ini merupakan alias dari `-p linux touch`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux touch`
