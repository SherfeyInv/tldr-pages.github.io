# pkg

> Manajer paket untuk OpenBSD.
> Informasi lebih lanjut: <https://www.openbsd.org/faq/faq15.html>.

- Lihat dokumentasi untuk memasang/memperbarui paket:

`tldr pkg_add`

- Lihat dokumentasi untuk menghapus paket:

`tldr pkg_delete`

- Lihat dokumentasi untuk melihat informasi paket yang tersedia atau terpasang:

`tldr pkg_info`
