# cinst

> Perintah ini merupakan alias dari `choco install`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco install`
