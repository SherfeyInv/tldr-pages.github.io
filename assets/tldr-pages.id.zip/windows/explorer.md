# explorer

> Windows File Explorer: penjelajah file pada Windows.
> Informasi lebih lanjut: <https://ss64.com/nt/explorer.html>.

- Membuka Windows Explorer:

`explorer`

- Membuka Windows Explorer di direktori saat ini:

`explorer .`

- Membuka Windows Explorer di direktori tertentu:

`explorer {{jalan/menuju/direktori}}`
