# iwr

> Perintah ini merupakan alias dari `Invoke-WebRequest` di PowerShell.

- Tampilkan dokumentasi untuk perintah asli:

`tldr invoke-webrequest`
