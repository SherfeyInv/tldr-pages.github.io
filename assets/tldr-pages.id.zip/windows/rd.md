# rd

> Perintah ini merupakan alias dari `rmdir` dalam Command Prompt, serta `Remove-Item` dalam PowerShell.

- Tampilkan dokumentasi untuk perintah asli Command Prompt:

`tldr rmdir`

- Tampilkan dokumentasi untuk perintah asli PowerShell:

`tldr remove-item`
