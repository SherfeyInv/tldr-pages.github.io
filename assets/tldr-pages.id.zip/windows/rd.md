# rd

> Perintah ini merupakan alias dari `rmdir` dalam Command Prompt, serta `Remove-Item` dalam PowerShell.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Tampilkan dokumentasi untuk perintah asli Command Prompt:

`tldr rmdir`

- Tampilkan dokumentasi untuk perintah asli PowerShell:

`tldr remove-item`
