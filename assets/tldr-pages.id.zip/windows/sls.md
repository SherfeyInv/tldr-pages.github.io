# sls

> Perintah ini merupakan alias dari `Select-String`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr select-string`
