# cpush

> Perintah ini merupakan alias dari `choco push`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco push`
