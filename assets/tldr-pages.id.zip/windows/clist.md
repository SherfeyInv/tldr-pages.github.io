# clist

> Perintah ini merupakan alias dari `choco list`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco list`
