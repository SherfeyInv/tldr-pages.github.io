# clist

> Perintah ini merupakan alias dari `choco list`.
> Informasi lebih lanjut: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco list`
