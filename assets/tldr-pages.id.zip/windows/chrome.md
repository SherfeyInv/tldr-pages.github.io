# chrome

> Perintah ini merupakan alias dari `chromium`.
> Informasi lebih lanjut: <https://chrome.google.com>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chromium`
