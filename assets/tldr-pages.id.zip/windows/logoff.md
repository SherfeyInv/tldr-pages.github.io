# logoff

> Akhiri sesi masuk.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/logoff>.

- Akhiri sesi saat ini:

`logoff`

- Akhiri sesi dengan nama atau id-nya:

`logoff {{nama_sesi|id_sesi}}`

- Akhiri sesi pada server tertentu yang terhubung melalui RDP:

`logoff {{nama_sesi|id_sesi}} /server:{{namaserver}}`
