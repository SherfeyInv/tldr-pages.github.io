# cuninst

> Perintah ini merupakan alias dari `choco uninstall`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco uninstall`
