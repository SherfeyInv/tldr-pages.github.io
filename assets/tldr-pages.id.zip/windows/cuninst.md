# cuninst

> Perintah ini merupakan alias dari `choco uninstall`.
> Informasi lebih lanjut: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr choco uninstall`
