# pwsh where

> Perintah ini merupakan alias dari `Where-Object`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr Where-Object`
