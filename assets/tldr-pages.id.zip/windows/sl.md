# sl

> Perintah ini merupakan alias dari `Set-Location` di PowerShell.

- Tampilkan dokumentasi untuk perintah asli:

`tldr set-location`
