# batcat

> Perintah ini merupakan alias dari `bat`.
> Informasi lebih lanjut: <https://github.com/sharkdp/bat>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr bat`
