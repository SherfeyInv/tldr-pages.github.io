# cc

> Perintah ini merupakan alias dari `gcc`.
> Informasi lebih lanjut: <https://gcc.gnu.org>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gcc`
