# megadl

> Perintah ini merupakan alias dari `megatools-dl`.
> Informasi lebih lanjut: <https://megatools.megous.com/man/megatools-dl.html>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr megatools-dl`
