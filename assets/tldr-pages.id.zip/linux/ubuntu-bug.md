# ubuntu-bug

> Perintah ini merupakan alias dari `apport-bug`.
> Informasi lebih lanjut: <https://manned.org/ubuntu-bug>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr apport-bug`
