# cgroups

> Perintah ini merupakan alias dari `cgclassify`.
> Informasi lebih lanjut: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr cgclassify`
