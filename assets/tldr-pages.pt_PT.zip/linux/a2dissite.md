# a2dissite

> Desactiva um host virtual do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manned.org/a2dissite.8>.

- Desactiva um host virtual:

`sudo a2dissite {{virtual_host}}`

- Desactiva um host virtual, sem mostrar as mensagens informativas:

`sudo a2dissite --quiet {{virtual_host}}`
