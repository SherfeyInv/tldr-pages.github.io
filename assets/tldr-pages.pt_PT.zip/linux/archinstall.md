# archinstall

> Instalador com instruções para Arch Linux.
> Mais informações: <https://archinstall.readthedocs.io>.

- Inicia o instalador guiado:

`archinstall`

- Inicia um instalador predefenido:

`archinstall {{minimal|unattended}}`
