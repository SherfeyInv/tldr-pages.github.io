# ncal

> Este comando é um alias de `cal`.

- Exibe documentação do comando original:

`tldr cal`
