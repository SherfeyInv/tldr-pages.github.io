# a2ensite

> Activa um host virtual do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manned.org/a2ensite.8>.

- Activa um host virtual:

`sudo a2ensite {{virtual_host}}`

- Activa um host virtual, sem mostrar as mensagens informativas:

`sudo a2ensite --quiet {{virtual_host}}`
