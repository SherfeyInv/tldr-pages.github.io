# ip route list

> Este comando é um alias de  `ip route show`.

- Exibe documentação do comando original:

`tldr ip-route-show`
