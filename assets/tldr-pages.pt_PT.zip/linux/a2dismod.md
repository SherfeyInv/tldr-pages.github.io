# a2dismod

> Desactiva um módulo do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manned.org/a2dismod.8>.

- Desactiva um módulo:

`sudo a2dismod {{módulo}}`

- Desactiva um módulo, sem mostrar as mensagens informativas:

`sudo a2dismod --quiet {{módulo}}`
