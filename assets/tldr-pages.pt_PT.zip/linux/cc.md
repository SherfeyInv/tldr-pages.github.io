# cc

> Este comando é um alias de `gcc`.

- Exibe documentação do comando original:

`tldr gcc`
