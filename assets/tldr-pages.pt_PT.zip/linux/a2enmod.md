# a2enmod

> Activa um módulo do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manned.org/a2enmod.8>.

- Activa um módulo:

`sudo a2enmod {{módulo}}`

- Activa um módulo, sem mostrar as mensagens informativas:

`sudo a2enmod --quiet {{módulo}}`
