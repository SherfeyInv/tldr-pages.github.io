# rd

> Este comando é um alias de `rmdir`.

- Exibe documentação do comando original:

`tldr rmdir`
