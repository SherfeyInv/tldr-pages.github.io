# cuninst

> Este comando é um alias de `choco uninstall`.

- Exibe documentação do comando original:

`tldr choco uninstall`
