# clist

> Este comando é um alias de `choco list`.

- Exibe documentação do comando original:

`tldr choco list`
