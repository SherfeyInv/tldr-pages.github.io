# clist

> Este comando é um alias de `choco list`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Exibe documentação do comando original:

`tldr choco list`
