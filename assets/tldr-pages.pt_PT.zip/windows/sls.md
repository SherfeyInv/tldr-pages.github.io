# sls

> Este comando é um alias de `Select-String`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Exibe documentação do comando original:

`tldr select-string`
