# sls

> Este comando é um alias de `Select-String`.

- Exibe documentação do comando original:

`tldr select-string`
