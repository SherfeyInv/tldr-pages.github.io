# pwsh where

> Este comando é um alias de `Where-Object`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Exibe documentação do comando original:

`tldr Where-Object`
