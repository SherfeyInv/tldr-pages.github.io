# cpush

> Este comando é um alias de `choco push`.

- Exibe documentação do comando original:

`tldr choco push`
