# python3

> Este comando é um alias de `python`.

- Exibe documentação do comando original:

`tldr python`
