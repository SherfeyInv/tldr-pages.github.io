# piodebuggdb

> Este comando é um alias de `pio debug`.

- Exibe documentação do comando original:

`tldr pio debug`
