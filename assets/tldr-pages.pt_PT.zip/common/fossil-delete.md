# fossil delete

> Este comando é um alias de `fossil rm`.
> Mais informações: <https://fossil-scm.org/home/help/delete>.

- Exibe documentação do comando original:

`tldr fossil rm`
