# kafkacat

> Este comando é um alias de `kcat`.

- Exibe documentação do comando original:

`tldr kcat`
