# lzcat

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/lzcat>.

- Exibe documentação do comando original:

`tldr xz`
