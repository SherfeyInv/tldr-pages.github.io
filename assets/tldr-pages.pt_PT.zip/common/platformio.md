# platformio

> Este comando é um alias de `pio`.

- Exibe documentação do comando original:

`tldr pio`
