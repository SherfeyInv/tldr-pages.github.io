# ntl

> Este comando é um alias de `netlify`.

- Exibe documentação do comando original:

`tldr netlify`
