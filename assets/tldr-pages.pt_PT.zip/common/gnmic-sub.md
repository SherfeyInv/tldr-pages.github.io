# gnmic sub

> Este comando é um alias de `gnmic subscribe`.
> Mais informações: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Exibe documentação do comando original:

`tldr gnmic subscribe`
