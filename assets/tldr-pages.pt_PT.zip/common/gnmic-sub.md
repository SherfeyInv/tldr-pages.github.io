# gnmic sub

> Este comando é um alias de `gnmic subscribe`.

- Exibe documentação do comando original:

`tldr gnmic subscribe`
