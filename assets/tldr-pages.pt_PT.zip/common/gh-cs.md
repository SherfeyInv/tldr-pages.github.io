# gh cs

> Este comando é um alias de  `gh codespace`.
> Mais informações: <https://cli.github.com/manual/gh_codespace>.

- Exibe documentação do comando original:

`tldr gh-codespace`
