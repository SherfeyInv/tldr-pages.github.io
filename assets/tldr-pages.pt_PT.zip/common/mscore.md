# mscore

> Este comando é um alias de `musescore`.

- Exibe documentação do comando original:

`tldr musescore`
