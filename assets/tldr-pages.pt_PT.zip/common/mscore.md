# mscore

> Este comando é um alias de `musescore`.
> Mais informações: <https://musescore.org/handbook/command-line-options>.

- Exibe documentação do comando original:

`tldr musescore`
