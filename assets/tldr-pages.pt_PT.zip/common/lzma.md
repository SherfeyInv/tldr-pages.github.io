# lzma

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/lzma>.

- Exibe documentação do comando original:

`tldr xz`
