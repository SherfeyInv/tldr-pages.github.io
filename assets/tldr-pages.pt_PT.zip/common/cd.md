# cd

> Mudar o diretório atual.
> Mais informações: <https://manned.org/cd>.

- Vai para um dado diretório:

`cd {{caminho/para/diretório}}`

- Vai para o diretório base do utilizador atual:

`cd`

- Vai para o diretório pai do diretório atual:

`cd ..`

- Vai para o diretório anteriormente escolhido:

`cd -`
