# ptpython3

> Este comando é um alias de `ptpython`.

- Exibe documentação do comando original:

`tldr ptpython`
