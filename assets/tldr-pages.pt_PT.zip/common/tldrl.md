# tldrl

> Este comando é um alias de `tldr-lint`.
> Mais informações: <https://github.com/tldr-pages/tldr-lint>.

- Exibe documentação do comando original:

`tldr tldr-lint`
