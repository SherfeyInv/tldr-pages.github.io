# tldrl

> Este comando é um alias de `tldr-lint`.

- Exibe documentação do comando original:

`tldr tldr-lint`
