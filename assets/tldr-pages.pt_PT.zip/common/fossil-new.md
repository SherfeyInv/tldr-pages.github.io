# fossil new

> Este comando é um alias de `fossil init`.

- Exibe documentação do comando original:

`tldr fossil init`
