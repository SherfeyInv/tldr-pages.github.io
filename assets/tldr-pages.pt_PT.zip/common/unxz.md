# unxz

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/unxz>.

- Exibe documentação do comando original:

`tldr xz`
