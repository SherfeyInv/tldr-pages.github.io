# llvm-objdump

> Este comando é um alias de `objdump`.

- Exibe documentação do comando original:

`tldr objdump`
