# fossil ci

> Este comando é um alias de  `fossil commit`.
> Mais informações: <https://fossil-scm.org/home/help/commit>.

- Exibe documentação do comando original:

`tldr fossil-commit`
