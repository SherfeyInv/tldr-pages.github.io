# fossil ci

> Este comando é um alias de `fossil commit`.

- Exibe documentação do comando original:

`tldr fossil commit`
