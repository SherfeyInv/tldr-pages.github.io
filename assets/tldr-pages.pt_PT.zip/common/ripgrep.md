# ripgrep

> Este comando é um alias de `rg`.

- Exibe documentação do comando original:

`tldr rg`
