# rcat

> Este comando é um alias de `rc`.

- Exibe documentação do comando original:

`tldr rc`
