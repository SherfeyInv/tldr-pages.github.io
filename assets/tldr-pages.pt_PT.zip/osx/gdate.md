# gdate

> Este comando é um alias de `-p linux date`.

- Exibe documentação do comando original:

`tldr -p linux date`
