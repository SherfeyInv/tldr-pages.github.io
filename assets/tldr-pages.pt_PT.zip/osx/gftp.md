# gftp

> Este comando é um alias de `-p linux ftp`.

- Exibe documentação do comando original:

`tldr -p linux ftp`
