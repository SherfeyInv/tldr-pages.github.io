# aa

> Este comando é um alias de `yaa`.

- Exibe documentação do comando original:

`tldr yaa`
