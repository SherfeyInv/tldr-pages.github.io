# grlogin

> Este comando é um alias de `-p linux rlogin`.

- Exibe documentação do comando original:

`tldr -p linux rlogin`
