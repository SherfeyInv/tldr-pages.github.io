# glibtool

> Este comando é um alias de `-p linux libtool`.

- Exibe documentação do comando original:

`tldr -p linux libtool`
