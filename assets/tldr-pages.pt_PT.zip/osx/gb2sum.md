# gb2sum

> Este comando é um alias de `-p linux b2sum`.

- Exibe documentação do comando original:

`tldr -p linux b2sum`
