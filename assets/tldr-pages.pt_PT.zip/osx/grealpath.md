# grealpath

> Este comando é um alias de `-p linux realpath`.

- Exibe documentação do comando original:

`tldr -p linux realpath`
