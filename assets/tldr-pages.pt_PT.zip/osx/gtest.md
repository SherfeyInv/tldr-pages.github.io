# gtest

> Este comando é um alias de `-p linux test`.

- Exibe documentação do comando original:

`tldr -p linux test`
