# gcat

> Este comando é um alias de `-p linux cat`.

- Exibe documentação do comando original:

`tldr -p linux cat`
