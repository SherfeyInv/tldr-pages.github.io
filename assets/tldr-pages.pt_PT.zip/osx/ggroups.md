# ggroups

> Este comando é um alias de `-p linux groups`.

- Exibe documentação do comando original:

`tldr -p linux groups`
