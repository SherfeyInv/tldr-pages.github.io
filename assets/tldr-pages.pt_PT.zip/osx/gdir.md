# gdir

> Este comando é um alias de `-p linux dir`.

- Exibe documentação do comando original:

`tldr -p linux dir`
