# gpaste

> Este comando é um alias de `-p linux paste`.

- Exibe documentação do comando original:

`tldr -p linux paste`
