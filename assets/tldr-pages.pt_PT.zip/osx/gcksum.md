# gcksum

> Este comando é um alias de `-p linux cksum`.

- Exibe documentação do comando original:

`tldr -p linux cksum`
