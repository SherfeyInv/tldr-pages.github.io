# gexpr

> Este comando é um alias de `-p linux expr`.

- Exibe documentação do comando original:

`tldr -p linux expr`
