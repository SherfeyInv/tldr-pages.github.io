# gprintf

> Este comando é um alias de `-p linux printf`.

- Exibe documentação do comando original:

`tldr -p linux printf`
