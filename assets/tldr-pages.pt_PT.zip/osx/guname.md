# guname

> Este comando é um alias de `-p linux uname`.

- Exibe documentação do comando original:

`tldr -p linux uname`
