# gnohup

> Este comando é um alias de `-p linux nohup`.

- Exibe documentação do comando original:

`tldr -p linux nohup`
