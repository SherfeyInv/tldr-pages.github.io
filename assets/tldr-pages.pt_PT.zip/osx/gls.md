# gls

> Este comando é um alias de `-p linux ls`.

- Exibe documentação do comando original:

`tldr -p linux ls`
