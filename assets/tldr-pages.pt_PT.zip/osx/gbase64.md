# gbase64

> Este comando é um alias de `-p linux base64`.

- Exibe documentação do comando original:

`tldr -p linux base64`
