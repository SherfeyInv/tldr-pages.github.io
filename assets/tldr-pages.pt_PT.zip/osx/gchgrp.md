# gchgrp

> Este comando é um alias de `-p linux chgrp`.

- Exibe documentação do comando original:

`tldr -p linux chgrp`
