# gsort

> Este comando é um alias de `-p linux sort`.

- Exibe documentação do comando original:

`tldr -p linux sort`
