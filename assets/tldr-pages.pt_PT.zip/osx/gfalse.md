# gfalse

> Este comando é um alias de `-p linux false`.

- Exibe documentação do comando original:

`tldr -p linux false`
