# gegrep

> Este comando é um alias de `-p linux egrep`.

- Exibe documentação do comando original:

`tldr -p linux egrep`
