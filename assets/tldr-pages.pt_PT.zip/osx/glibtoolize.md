# glibtoolize

> Este comando é um alias de `-p linux libtoolize`.

- Exibe documentação do comando original:

`tldr -p linux libtoolize`
