# gsha224sum

> Este comando é um alias de `-p linux sha224sum`.

- Exibe documentação do comando original:

`tldr -p linux sha224sum`
