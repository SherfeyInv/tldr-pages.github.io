# gxargs

> Este comando é um alias de `-p linux xargs`.

- Exibe documentação do comando original:

`tldr -p linux xargs`
