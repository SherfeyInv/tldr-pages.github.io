# gtr

> Este comando é um alias de `-p linux tr`.

- Exibe documentação do comando original:

`tldr -p linux tr`
