# gsha384sum

> Este comando é um alias de `-p linux sha384sum`.

- Exibe documentação do comando original:

`tldr -p linux sha384sum`
