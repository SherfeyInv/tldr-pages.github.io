# gtimeout

> Este comando é um alias de `-p linux timeout`.

- Exibe documentação do comando original:

`tldr -p linux timeout`
