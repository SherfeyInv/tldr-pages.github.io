# gwho

> Este comando é um alias de `-p linux who`.

- Exibe documentação do comando original:

`tldr -p linux who`
