# gcomm

> Este comando é um alias de `-p linux comm`.

- Exibe documentação do comando original:

`tldr -p linux comm`
