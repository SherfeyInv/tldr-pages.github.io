# gsum

> Este comando é um alias de `-p linux sum`.

- Exibe documentação do comando original:

`tldr -p linux sum`
