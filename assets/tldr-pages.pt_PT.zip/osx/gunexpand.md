# gunexpand

> Este comando é um alias de `-p linux unexpand`.

- Exibe documentação do comando original:

`tldr -p linux unexpand`
