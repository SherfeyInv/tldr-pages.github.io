# gunits

> Este comando é um alias de `-p linux units`.

- Exibe documentação do comando original:

`tldr -p linux units`
