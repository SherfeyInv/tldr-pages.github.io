# guniq

> Este comando é um alias de `-p linux uniq`.

- Exibe documentação do comando original:

`tldr -p linux uniq`
