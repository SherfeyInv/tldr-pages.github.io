# gptx

> Este comando é um alias de `-p linux ptx`.

- Exibe documentação do comando original:

`tldr -p linux ptx`
