# gtraceroute

> Este comando é um alias de `-p linux traceroute`.

- Exibe documentação do comando original:

`tldr -p linux traceroute`
