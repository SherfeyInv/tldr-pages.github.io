# arch

> Mostra o nome da arquitetura do sistema, ou executa um comando utilizando uma arquitetura escolhida.
> Ver também: `uname`.
> Mais informações: <https://keith.github.io/xcode-man-pages/arch.1.html>.

- Mostra o nome da arquitetura do sistema:

`arch`

- Executa um comando utilizando a arquitetura x86_64:

`arch -x86_64 {{comando}}`
