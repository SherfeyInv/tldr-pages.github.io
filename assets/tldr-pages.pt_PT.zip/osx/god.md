# god

> Este comando é um alias de `-p linux od`.

- Exibe documentação do comando original:

`tldr -p linux od`
