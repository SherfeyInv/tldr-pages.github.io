# gyes

> Este comando é um alias de `-p linux yes`.

- Exibe documentação do comando original:

`tldr -p linux yes`
