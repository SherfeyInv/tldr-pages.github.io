# bugreport

> Mostra um relatório de bugs do Android.
> Este comando só pode ser utilizado com a `adb shell`.
> Mais informações: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Mostra um relatório completo de bugs de um dispositivo Android:

`bugreport`
