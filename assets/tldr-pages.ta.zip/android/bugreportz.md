# bugreportz

> ஜிப் செய்யப்பட்ட ஆண்ட்ராய்டு பிழை அறிக்கையை உருவாக்கவும்.
> இந்தக் கட்டளையை `adb shell` மூலம் மட்டுமே பயன்படுத்த முடியும்.
> மேலும் விவரத்திற்கு: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- ஒரு ஆண்ட்ராய்டு சாதனத்தின் முழுமையான ஜிப் செய்யப்பட்ட பிழை அறிக்கையை உருவாக்கவும்:

`bugreportz`

- இயங்கும் `bugreportz` செயல்பாட்டின் முன்னேற்றத்தைக் காட்டு:

`bugreportz -p`

- உதவியைக் காட்டு:

`bugreportz -h`

- `bugreportz` பதிப்பைக் காட்டு:

`bugreportz -v`
