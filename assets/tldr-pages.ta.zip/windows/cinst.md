# cinst

> இக்கட்டளை `choco install` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr choco install`
