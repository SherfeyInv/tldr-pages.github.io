# cpush

> இக்கட்டளை `choco push` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://docs.chocolatey.org/en-us/create/commands/push>.

- அசல் கட்டளைக்கான ஆவணங்களைப் பார்க்கவும்:

`tldr choco-push`
