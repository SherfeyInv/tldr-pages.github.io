# gnome-calculator

> GNOME டெஸ்க்டாப் சூழலுக்கான அதிகாரப்பூர்வ கால்குலேட்டர்.
> மேலும் விவரத்திற்கு: <https://wiki.gnome.org/Apps/Calculator>.

- GNOME கால்குலேட்டர் GUI ஐ துவக்கவும்:

`gnome-calculator`

- டெஸ்க்டாப் பயன்பாட்டைத் தொடங்காமல் கட்டளை வரியில் குறிப்பிடப்பட்ட சமன்பாட்டைத் தீர்க்கவும்:

`gnome-calculator --solve {{2^5 * 2 + 5}}`

- பதிப்பைக் காட்டு:

`gnome-calculator --version`
