# alternatives

> இக்கட்டளை `update-alternatives` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://manned.org/alternatives>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr update-alternatives`
