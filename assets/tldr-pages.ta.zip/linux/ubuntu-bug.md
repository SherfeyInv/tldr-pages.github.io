# ubuntu-bug

> இக்கட்டளை `apport-bug` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://manned.org/ubuntu-bug>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr apport-bug`
