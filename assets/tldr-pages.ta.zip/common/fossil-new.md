# fossil new

> இக்கட்டளை  `fossil init`.கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://fossil-scm.org/home/help/new>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr fossil-init`
