# tlmgr arch

> இக்கட்டளை `tlmgr platform` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://www.tug.org/texlive/tlmgr.html>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr tlmgr platform`
