# tldrl

> இக்கட்டளை `tldr-lint` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://github.com/tldr-pages/tldr-lint>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr tldr-lint`
