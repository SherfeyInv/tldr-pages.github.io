# sc delete

> This command is an alias of `sc.exe delete`.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- View documentation for the original command:

`tldr sc`
