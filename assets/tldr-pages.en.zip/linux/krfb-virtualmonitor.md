# krfb-virtualmonitor

> Create a virtual monitor and allow that monitor to be used with VNC.
> More information: <https://invent.kde.org/network/krfb>.

- Create a virtual monitor:

`krfb-virtualmonitor --resolution {{1920}}x{{1080}} --name {{monitor_name}} --password {{password}} --port {{5900}}`
