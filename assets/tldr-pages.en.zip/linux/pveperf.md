# pveperf

> A benchmarking tool in Proxmox Server. Gather CPU and hard disk performance data for the hard disk.
> More information: <https://pve.proxmox.com/pve-docs/pveperf.1.html>.

- Show CPU and hard disk performance data for the hard disk mounted at `/`:

`pveperf`
