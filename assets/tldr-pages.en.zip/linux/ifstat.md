# ifstat

> View network interface statistics.
> More information: <https://manned.org/ifstat>.

- View network interface statistics since last query:

`ifstat`

- View network interface statistics since last boot:

`ifstat {{-a|--ignore}}`

- View error rate:

`ifstat {-e|--errors}}`
