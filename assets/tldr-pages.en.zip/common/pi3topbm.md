# pi3topbm

> Convert an Atari Degas PI3 image to PBM image.
> See also: `pbmtopi3`.
> More information: <https://netpbm.sourceforge.net/doc/pi3topbm.html>.

- Convert an Atari Degas PI3 image to PBM image:

`pi1topbm {{path/to/atari_image.pi3}} > {{path/to/output_image.pbm}}`
