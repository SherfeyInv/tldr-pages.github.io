# mgrtopbm

> Convert a MGR bitmap into a PBM file.
> See also: `pbmtomgr`.
> More information: <https://netpbm.sourceforge.net/doc/mgrtopbm.html>.

- Convert a MGR bitmap into a PBM file:

`mgrtopbm {{path/to/image.mgr}} > {{path/to/output.pbm}}`
