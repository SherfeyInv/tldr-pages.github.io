# gyes

> This command is an alias of GNU `yes`.

- View documentation for the original command:

`tldr -p linux yes`
