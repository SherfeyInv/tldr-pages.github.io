# sc create

> This command is an alias of `sc.exe create`.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- View documentation for the original command:

`tldr sc`
