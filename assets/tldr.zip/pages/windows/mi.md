# mi

> In PowerShell, this command is an alias of `Move-Item`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/move-item>.

- View documentation for the original command:

`tldr move-item`
