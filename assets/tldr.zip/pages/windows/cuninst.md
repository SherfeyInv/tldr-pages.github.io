# cuninst

> This command is an alias of `choco uninstall`.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- View documentation for the original command:

`tldr choco uninstall`
