# gl

> In PowerShell, this command is an alias of `Get-Location`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/get-location>.

- View documentation for the original command:

`tldr get-location`
