# sdelete64

> This command is the 64 bit version of `sdelete`.

- View documentation for the original command:

`tldr sdelete`
