# qm mtunnel

> Used by `qmigrate`.
> It should not be invoked manually.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Command used by `qmigrate` during data migration from a VM to another host:

`qm mtunnel`
