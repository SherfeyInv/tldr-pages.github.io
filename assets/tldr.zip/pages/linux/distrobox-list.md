# distrobox-list

> List all Distrobox containers. See also: `tldr distrobox`.
> Distrobox containers are listed separately from the rest of normal Podman or Docker containers.
> More information: <https://distrobox.it/usage/distrobox-list>.

- List all Distrobox containers:

`distrobox-list`

- List all Distrobox containers with verbose information:

`distrobox-list --verbose`
