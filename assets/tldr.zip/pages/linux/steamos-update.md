# steamos-update

> Update SteamOS.
> More information: <https://gitlab.com/users/evlaV/projects>.

- Update the operating system:

`steamos-update`

- Check if there is an update available:

`steamos-update check`
