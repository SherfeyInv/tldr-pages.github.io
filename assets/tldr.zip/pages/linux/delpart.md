# delpart

> Ask the Linux kernel to forget about a partition.
> More information: <https://manned.org/delpart>.

- Tell the kernel to forget about the first partition of `/dev/sda`:

`sudo delpart {{/dev/sda}} {{1}}`
