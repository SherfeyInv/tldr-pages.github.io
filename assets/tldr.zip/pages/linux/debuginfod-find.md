# debuginfod-find

> Request debuginfo-related data.
> More information: <https://manned.org/debuginfod-find>.

- Request data based on the `build_id`:

`debuginfod-find -vv debuginfo {{build_id}}`
