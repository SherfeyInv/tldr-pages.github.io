# goobook

> Access Google contacts from `mutt` or the command-line.
> More information: <https://manned.org/goobook>.

- Allow `goobook` to access Google contacts using OAuth2:

`goobook authenticate`

- Dump all contacts to XML (`stdout`):

`goobook dump_contacts`
