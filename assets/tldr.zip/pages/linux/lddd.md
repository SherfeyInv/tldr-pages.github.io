# lddd

> Find broken library links on the system.
> This tool is only available on Arch Linux.
> More information: <https://manned.org/lddd>.

- Scan directories to find and list packages with broken library links that need to be rebuilt:

`lddd`
