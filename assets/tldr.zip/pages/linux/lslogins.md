# lslogins

> Show information about users on a Linux system.
> More information: <https://manned.org/lslogins>.

- Display users in the system:

`lslogins`

- Display users belonging to a specific group:

`lslogins --groups={{groups}}`

- Display user accounts:

`lslogins --user-accs`

- Display last logins:

`lslogins --last`

- Display system accounts:

`lslogins --system-accs`

- Display supplementary groups:

`lslogins --supp-groups`
