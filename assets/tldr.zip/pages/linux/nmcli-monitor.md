# nmcli monitor

> Monitor changes to the NetworkManager connection status.
> This subcommand can also be called with `nmcli m`.
> More information: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- Start monitoring NetworkManager changes:

`nmcli monitor`
