# rpi-otp-private-key

> Display the One-Time Programmable (OTP) private key of a Raspberry Pi.
> More information: <https://www.raspberrypi.com/documentation/computers/raspberry-pi.html#program-a-key-into-otp-with-rpi-otp-private-key>.

- Read the OTP private key:

`rpi-otp-private-key`
