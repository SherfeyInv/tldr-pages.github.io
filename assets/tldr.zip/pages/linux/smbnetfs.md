# smbnetfs

> Mount SMB shares interactively.
> More information: <https://sourceforge.net/projects/smbnetfs/>.

- Make shares available at `mountpoint`:

`smbnetfs {{mountpoint}}`
