# a2enmod

> Enable an Apache module on Debian-based OSes.
> More information: <https://manned.org/a2enmod.8>.

- Enable a module:

`sudo a2enmod {{module}}`

- Don't show informative messages:

`sudo a2enmod --quiet {{module}}`
