# steamos-dump-info

> View SteamOS system information.
> More information: <https://gitlab.com/users/evlaV/projects>.

- View SteamOS system information:

`sudo steamos-dump-info`
