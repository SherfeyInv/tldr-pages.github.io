# insmod

> Dynamically load modules into the Linux Kernel.
> More information: <https://manned.org/insmod>.

- Insert a kernel module into the Linux kernel:

`insmod {{path/to/module.ko}}`
