# nmtui-connect

> This command is an alias of `nmtui connect`.

- View documentation for the original command:

`tldr nmtui`
