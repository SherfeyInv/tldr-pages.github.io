# esa snap

> Sentinel Application Platform (SNAP) for processing satellite data from the European Space Agency (ESA).
> More information: <https://step.esa.int/main/download/snap-download/>.

- Display all updates:

`snap --nosplash --nogui --modules --list --refresh`

- Display help:

`snap --help`
