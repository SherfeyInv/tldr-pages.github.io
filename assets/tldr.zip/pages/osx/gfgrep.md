# gfgrep

> This command is an alias of GNU `fgrep`.

- View documentation for the original command:

`tldr -p linux fgrep`
