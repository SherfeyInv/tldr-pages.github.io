# grlogin

> This command is an alias of GNU `rlogin`.

- View documentation for the original command:

`tldr -p linux rlogin`
