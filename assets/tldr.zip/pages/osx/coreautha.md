# coreautha

> A system agent providing the `LocalAuthentication` framework.
> It should not be invoked manually. See also: `coreauthd`.
> More information: <https://keith.github.io/xcode-man-pages/coreautha.8.html>.

- Start the agent:

`coreautha`
