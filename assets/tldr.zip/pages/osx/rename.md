# rename

> Rename a file or group of files with a regular expression.
> More information: <https://keith.github.io/xcode-man-pages/rename.2.html>.

- Replace `from` with `to` in the filenames of the specified files:

`rename 's/{{from}}/{{to}}/' {{*.txt}}`
