# gunlink

> This command is an alias of GNU `unlink`.

- View documentation for the original command:

`tldr -p linux unlink`
