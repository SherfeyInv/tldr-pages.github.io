# wps

> Assists AirPort in connecting to a network using Wireless Protected Setup.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/wps.8.html>.

- Start the daemon:

`wps`
