# ocspd

> This retrieves and caches Certificate Revocation Lists (CRLs) and Online Certificate Status Protocol (OCSP) responses for certificate verification.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/ocspd.1.html>.

- Start the daemon:

`ocspd`
