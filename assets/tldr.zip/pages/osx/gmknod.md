# gmknod

> This command is an alias of GNU `mknod`.

- View documentation for the original command:

`tldr -p linux mknod`
