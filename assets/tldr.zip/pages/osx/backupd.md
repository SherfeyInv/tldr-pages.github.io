# backupd

> Create Time Machine backups and manages its backup history.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/backupd.8.html>.

- Start the daemon:

`backupd`
