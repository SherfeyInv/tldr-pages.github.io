# gftp

> This command is an alias of GNU `ftp`.

- View documentation for the original command:

`tldr -p linux ftp`
