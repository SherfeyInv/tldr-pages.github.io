# gawk

> This command is an alias of GNU `awk`.

- View documentation for the original command:

`tldr -p linux awk`
