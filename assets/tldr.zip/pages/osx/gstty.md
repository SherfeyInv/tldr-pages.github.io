# gstty

> This command is an alias of GNU `stty`.

- View documentation for the original command:

`tldr -p linux stty`
