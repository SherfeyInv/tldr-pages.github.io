# xzfgrep

> This command is an alias of `xzgrep --fixed-strings`.
> See also: `fgrep`.

- View documentation for the original command:

`tldr xzgrep`
