# ppmquant

> This command has been replaced by `pnmquant` and `pnmremap`.
> More information: <https://netpbm.sourceforge.net/doc/ppmquant.html>.

- View documentation for `pnmquant`:

`tldr pnmquant`

- View documentation for `pnmremap`:

`tldr pnmremap`
