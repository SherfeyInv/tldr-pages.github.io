# pnmarith

> This command has been superseded by `pamarith`.
> More information: <https://netpbm.sourceforge.net/doc/pnmarith.html>.

- View documentation for the current command:

`tldr pamarith`
