# dvc destroy

> Remove all DVC files and directories from a DVC project.
> More information: <https://dvc.org/doc/command-reference/destroy>.

- Destroy the current project:

`dvc destroy`

- Force destroy the current project:

`dvc destroy --force`
