# fstopgm

> Convert a Usenix FaceSaver file into a PGM image.
> See also: `pgmtofs`.
> More information: <https://netpbm.sourceforge.net/doc/fstopgm.html>.

- Convert the specified Usenix FaceSaver file into a PGM image:

`fstopgm {{path/to/input.fs}} > {{path/to/output.pgm}}`
