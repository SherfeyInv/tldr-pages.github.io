# identify

> This command is an alias of `magick identify`.

- View documentation for the original command:

`tldr magick identify`
