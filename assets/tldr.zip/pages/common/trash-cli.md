# trash-cli

> This command is an alias of `trash`.

- View documentation for the original command:

`tldr trash`
