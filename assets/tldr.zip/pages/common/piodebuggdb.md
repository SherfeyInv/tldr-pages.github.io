# piodebuggdb

> This command is an alias of `pio debug --interface=gdb`.

- View documentation for the original command:

`tldr pio debug`
