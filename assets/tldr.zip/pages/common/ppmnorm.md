# ppmnorm

> This command is superseded by `pnmnorm`.
> More information: <https://netpbm.sourceforge.net/doc/ppmnorm.html>.

- View documentation for the current command:

`tldr pnmnorm`
