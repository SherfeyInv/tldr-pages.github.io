# npm test

> This command is an alias of `npm run test`.

- View documentation for the original command:

`tldr npm run`
