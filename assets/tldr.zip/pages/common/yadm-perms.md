# yadm-perms

> Update permissions.
> It is usually unnecessary to run this command, as `yadm` automatically processes permissions by default. This automatic behavior can be disabled by setting the configuration `yadm.auto-perms` to `"false"`.
> More information: <https://github.com/TheLocehiliosan/yadm/blob/master/yadm.md#permissions>.

- Change file permissions:

`yadm perms`
