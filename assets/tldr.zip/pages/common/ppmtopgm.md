# ppmtopgm

> Convert a PPM image to a PGM image.
> More information: <https://netpbm.sourceforge.net/doc/ppmtopgm.html>.

- Convert PPM image to PGM image:

`ppmtopgm {{path/to/file.ppm}} > {{path/to/file.pgm}}`

- Display version:

`ppmtopgm -version`
