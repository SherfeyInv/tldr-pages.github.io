# sc_warts2text

> Simple dump of information contained in a `warts` file.
> More information: <https://www.caida.org/catalog/software/scamper/>.

- Output the information in `warts` files as text:

`sc_warts2text {{path/to/file1.warts path/to/file2.warts ...}}`
