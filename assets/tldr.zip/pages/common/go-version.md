# go version

> Display Go version.
> More information: <https://golang.org/cmd/go/#hdr-Print_Go_version>.

- Display version:

`go version`

- Display the Go version used to build a specific executable file:

`go version {{path/to/executable}}`
