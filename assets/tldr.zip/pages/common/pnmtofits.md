# pnmtofits

> This command has been superseded by `pamtofits`.
> More information: <https://netpbm.sourceforge.net/doc/pnmtofits.html>.

- View documentation for the current command:

`tldr pamtofits`
