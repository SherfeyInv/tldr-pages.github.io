# lzma

> This command is an alias of `xz --format=lzma`.

- View documentation for the original command:

`tldr xz`
