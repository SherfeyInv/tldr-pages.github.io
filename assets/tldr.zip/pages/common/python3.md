# python3

> This command is an alias of `python`.

- View documentation for the original command:

`tldr python`
