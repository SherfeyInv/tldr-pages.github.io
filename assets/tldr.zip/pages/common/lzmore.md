# lzmore

> This command is an alias of `xzmore`.

- View documentation for the original command:

`tldr xzmore`
