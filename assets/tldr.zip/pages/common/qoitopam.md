# qoitopam

> Convert a QOI image (Quite OK Image format) to Netpbm.
> More information: <https://netpbm.sourceforge.net/doc/qoitopam.html>.

- Convert a QOI image to Netpbm:

`qoitopam {{path/to/image.qoi}} > {{path/to/output.pnm}}`
