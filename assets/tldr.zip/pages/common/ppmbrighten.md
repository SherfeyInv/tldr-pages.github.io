# ppmbrighten

> This command has been superseded by `pambrighten`.
> More information: <https://netpbm.sourceforge.net/doc/ppmbrighten.html>.

- View documentation for the current command:

`tldr pambrighten`
