# sam2p

> Raster (bitmap) image converter with smart PDF and PostScript (EPS) output.
> More information: <https://github.com/pts/sam2p>.

- Concatenate all PDF files into one:

`sam2p *.pdf {{path/to/output.pdf}}`
