# npm root

> Display path to `node_modules` directory.
> More information: <https://docs.npmjs.com/cli/commands/npm-root>.

- Display path to the local `node_modules` directory:

`npm root`

- Display path to the global `node_modules` directory:

`npm root --global`
