# bugreportz

> जिप गरिएको एन्ड्रोइड बग रिपोर्ट उत्पन्न गर्नुहोस्।
> यो आदेश `adb shell` मार्फत मात्र प्रयोग गर्न सकिन्छ।
> थप जानकारी: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>।

- एन्ड्रोइड उपकरणको पूर्ण जिप गरिएको बग रिपोर्ट उत्पन्न गर्नुहोस्:

`bugreportz`

- चलिरहेको `bugreportz` सञ्चालनको प्रगति देखाउनुहोस्:

`bugreportz -p`

- `bugreportz` को संस्करण देखाउनुहोस्:

`bugreportz -v`

- प्रदर्शन मद्दत:

`bugreportz -h`
