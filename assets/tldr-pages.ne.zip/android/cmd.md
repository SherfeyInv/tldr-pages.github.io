# cmd

> एन्ड्रोइड सेवा प्रबन्धक।
> थप जानकारी: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>।

- [l] सबै चलिरहेको सेवाहरू छन्:

`cmd -l`

- एक विशेष सेवा कल गर्नुहोस्:

`cmd {{सेवा}}`

- विशिष्ट तर्क संग सेवा कल गर्नुहोस्:

`cmd {{सेवा}} {{तर्क1 तर्क2 ...}}`
