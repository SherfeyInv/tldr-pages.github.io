# mscore

> यो आदेश `musescore` को उपनाम हो |
> थप जानकारी: <https://musescore.org/handbook/command-line-options>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr musescore`
