# transmission

> यो आदेश `transmission-daemon` को उपनाम हो |
> थप जानकारी: <https://transmissionbt.com/>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr transmission-daemon`
