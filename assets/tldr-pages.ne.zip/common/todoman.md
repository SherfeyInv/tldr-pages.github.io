# todoman

> यो आदेश `todo` को उपनाम हो |
> थप जानकारी: <https://todoman.readthedocs.io/>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr todo`
