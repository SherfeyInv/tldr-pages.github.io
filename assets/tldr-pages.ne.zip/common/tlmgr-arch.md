# tlmgr arch

> यो आदेश `tlmgr platform` को उपनाम हो |
> थप जानकारी: <https://www.tug.org/texlive/tlmgr.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr tlmgr platform`
