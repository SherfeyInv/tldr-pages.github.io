# cpush

> यो आदेश `choco-push` को उपनाम हो |
> थप जानकारी: <https://docs.chocolatey.org/en-us/create/commands/push>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr choco-push`
