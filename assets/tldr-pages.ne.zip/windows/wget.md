# wget

> यो आदेश `wget -p common` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr wget -p common`
