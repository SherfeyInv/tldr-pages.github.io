# cinst

> यो आदेश `choco install` को उपनाम हो |
> थप जानकारी: <https://docs.chocolatey.org/en-us/choco/commands/install>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr choco install`
