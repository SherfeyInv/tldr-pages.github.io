# megadl

> यो आदेश `megatools-dl` को उपनाम हो |
> थप जानकारी: <https://megatools.megous.com/man/megatools-dl.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr megatools-dl`
