# cgroups

> यो आदेश `cgclassify` को उपनाम हो |
> थप जानकारी: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr cgclassify`
