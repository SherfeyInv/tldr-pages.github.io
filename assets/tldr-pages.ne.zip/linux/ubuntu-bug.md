# ubuntu-bug

> यो आदेश `apport-bug` को उपनाम हो |
> थप जानकारी: <https://manned.org/ubuntu-bug>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr apport-bug`
