# fossil delete

> هذا الأمر هو اسم مستعار لـ `fossil rm`.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil rm`
