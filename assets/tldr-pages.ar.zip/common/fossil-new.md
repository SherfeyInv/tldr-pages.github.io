# fossil new

> هذا الأمر هو اسم مستعار لـ  `fossil init`.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil-init`
