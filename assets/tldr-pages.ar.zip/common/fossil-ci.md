# fossil ci

> هذا الأمر هو اسم مستعار لـ `fossil commit`.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil commit`
