# ip route list

> هذا الأمر هو اسم مستعار لـ `ip route show`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ip route show`
