# curl

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `curl -p common`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr curl -p common`
