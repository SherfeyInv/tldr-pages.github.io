# pwsh where

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `Where-Object`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr Where-Object`
