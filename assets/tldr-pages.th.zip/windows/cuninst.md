# cuninst

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `choco uninstall`
> ข้อมูลเพิ่มเติม: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr choco uninstall`
