# clist

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `choco list`
> ข้อมูลเพิ่มเติม: <https://docs.chocolatey.org/en-us/choco/commands/list>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr choco list`
