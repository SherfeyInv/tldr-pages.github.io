# cls

> ล้างตัวอักษรทั้งหมดที่อยู่บนหน้าต่าง
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>

- ล้างตัวอักษรทั้งหมดบนหน้าจอ:

`cls`
