# cpush

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `choco-push`
> ข้อมูลเพิ่มเติม: <https://docs.chocolatey.org/en-us/create/commands/push>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr choco-push`
