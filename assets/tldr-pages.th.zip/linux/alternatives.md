# alternatives

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `update-alternatives`
> ข้อมูลเพิ่มเติม: <https://manned.org/alternatives>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr update-alternatives`
