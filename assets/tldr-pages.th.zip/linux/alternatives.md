# alternatives

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `update-alternatives`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr update-alternatives`
