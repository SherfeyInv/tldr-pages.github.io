# megadl

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `megatools-dl`
> ข้อมูลเพิ่มเติม: <https://megatools.megous.com/man/megatools-dl.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr megatools-dl`
