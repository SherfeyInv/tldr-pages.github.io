# ubuntu-bug

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `apport-bug`
> ข้อมูลเพิ่มเติม: <https://manned.org/ubuntu-bug>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr apport-bug`
