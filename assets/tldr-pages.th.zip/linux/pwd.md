# pwd

> แสดงชื่อของไดเรกทอรีที่ทำงานอยู่
> ข้อมูลเพิ่มเติม: <https://www.gnu.org/software/coreutils/pwd>

- แสดงชื่อของไดเรกทอรีที่ทำงานอยู่:

`pwd`

- แสดงชื่อของไดเรกทอรีที่ทำงานอยู่ โดยไม่รวม symlinks:

`pwd --physical`

- แสดงชื่อของไดเรกทอรีที่ทำงานอยู่ โดยใช้ PWD จาก environment ถึงแม้ว่าจะรวม symlinks:

`pwd --logical`
