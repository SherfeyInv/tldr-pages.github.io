# gexpand

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `-p linux expand`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr -p linux expand`
