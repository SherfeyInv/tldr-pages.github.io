# transmission

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `transmission-daemon`
> ข้อมูลเพิ่มเติม: <https://transmissionbt.com/>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr transmission-daemon`
