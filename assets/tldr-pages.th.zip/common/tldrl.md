# tldrl

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `tldr-lint`
> ข้อมูลเพิ่มเติม: <https://github.com/tldr-pages/tldr-lint>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr tldr-lint`
