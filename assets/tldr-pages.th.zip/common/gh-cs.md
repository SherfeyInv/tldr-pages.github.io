# gh cs

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `gh-codespace`
> ข้อมูลเพิ่มเติม: <https://cli.github.com/manual/gh_codespace>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr gh-codespace`
