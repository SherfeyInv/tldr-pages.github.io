# bundler

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `bundle`
> ข้อมูลเพิ่มเติม: <https://bundler.io/man/bundle.1.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr bundle`
