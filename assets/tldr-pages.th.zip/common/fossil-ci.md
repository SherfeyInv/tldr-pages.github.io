# fossil ci

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `fossil-commit`
> ข้อมูลเพิ่มเติม: <https://fossil-scm.org/home/help/commit>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr fossil-commit`
