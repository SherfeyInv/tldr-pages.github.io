# fossil ci

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `fossil commit`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr fossil commit`
