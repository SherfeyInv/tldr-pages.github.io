# chsh

> Cambia shell di login dell'utente.
> Maggiori informazioni: <https://manned.org/chsh>.

- Cambia shell:

`chsh -s {{percorso/dell/eseguibile_della_shell}} {{nome_utente}}`
