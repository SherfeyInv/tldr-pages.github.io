# gnmic sub

> Questo comando è un alias per `gnmic subscribe`.
> Maggiori informazioni: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Consulta la documentazione del comando originale:

`tldr gnmic subscribe`
