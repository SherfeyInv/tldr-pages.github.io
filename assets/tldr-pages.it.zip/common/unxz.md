# unxz

> Questo comando è un alias per `xz`.
> Maggiori informazioni: <https://manned.org/unxz>.

- Consulta la documentazione del comando originale:

`tldr xz`
