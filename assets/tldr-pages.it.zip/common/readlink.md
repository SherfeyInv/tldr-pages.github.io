# readlink

> Segue un collegamento simbolico e ne recupera le informazioni.
> Maggiori informazioni: <https://www.gnu.org/software/coreutils/readlink>.

- Restituisce il percorso originale a cui il collegamento simbolico fa riferimento:

`readlink {{nome_file}}`

- Ottiene il percorso assoluto di un file:

`readlink -f {{nome_file}}`
