# cmatrix

> Genera lettere che cadono, come in Matrix.
> Maggiori informazioni: <https://github.com/abishekvashok/cmatrix>.

- Attivare lo scorrimento asincrono:

`cmatrix -a`

- Rendi le lettere rosse:

`cmatrix -C {{red}}`

- Cambia colore a arcobaleno:

`cmatrix -r`

- Imposta il dilazione di aggiornamento a 100 centisecondi (10 secondi):

`cmatrix -u 100`
