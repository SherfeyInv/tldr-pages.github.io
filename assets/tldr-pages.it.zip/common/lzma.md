# lzma

> Questo comando è un alias per `xz`.

- Consulta la documentazione del comando originale:

`tldr xz`
