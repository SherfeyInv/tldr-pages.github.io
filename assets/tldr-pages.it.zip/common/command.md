# command

> Command forza la shell ad eseguire programmi ignorando qualsiasi funzione, builtin e alias con lo stesso nome.
> Maggiori informazioni: <https://manned.org/command>.

- Esegui il comando `ls` letteralmente, anche se esiste un alias `ls`:

`command {{ls}}`
