# lzcat

> Questo comando è un alias per `xz`.
> Maggiori informazioni: <https://manned.org/lzcat>.

- Consulta la documentazione del comando originale:

`tldr xz`
