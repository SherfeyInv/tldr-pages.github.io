# transmission

> Questo comando è un alias per `transmission-daemon`.
> Maggiori informazioni: <https://transmissionbt.com/>.

- Consulta la documentazione del comando originale:

`tldr transmission-daemon`
