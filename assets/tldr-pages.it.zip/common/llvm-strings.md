# llvm-strings

> Questo comando è un alias per `strings`.

- Consulta la documentazione del comando originale:

`tldr strings`
