# hello

> Stampa a schermo "Hello, world!", "hello, world" oppure del testo personalizzabile.
> Maggiori informazioni: <https://www.gnu.org/software/hello/>.

- Stampa a schermo "Hello, world!":

`hello`

- Stampa a schermo "hello, world", nel modo tradizionale:

`hello --traditional`

- Stampa a schermo un messaggio:

`hello --greeting="{{messaggio}}"`
