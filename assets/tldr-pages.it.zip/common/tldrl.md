# tldrl

> Questo comando è un alias per `tldr-lint`.

- Consulta la documentazione del comando originale:

`tldr tldr-lint`
