# pio init

> Questo comando è un alias per `pio project`.

- Consulta la documentazione del comando originale:

`tldr pio project`
