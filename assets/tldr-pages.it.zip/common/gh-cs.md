# gh cs

> Questo comando è un alias per `gh codespace`.

- Consulta la documentazione del comando originale:

`tldr gh codespace`
