# cd

> Cambia la directory corrente.
> Maggiori informazioni: <https://manned.org/cd>.

- Vai alla directory specificata:

`cd {{percorso/della/directory}}`

- Vai alla directory home dell'utente corrente:

`cd`

- Vai alla directory madre della corrente:

`cd ..`

- Vai alla directory precedentemente scelta:

`cd -`
