# clojure

> Questo comando è un alias per `clj`.

- Consulta la documentazione del comando originale:

`tldr clj`
