# mscore

> Questo comando è un alias per `musescore`.
> Maggiori informazioni: <https://musescore.org/handbook/command-line-options>.

- Consulta la documentazione del comando originale:

`tldr musescore`
