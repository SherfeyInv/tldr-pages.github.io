# fossil new

> Questo comando è un alias per  `fossil init`.

- Consulta la documentazione del comando originale:

`tldr fossil init`
