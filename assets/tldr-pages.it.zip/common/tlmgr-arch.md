# tlmgr arch

> Questo comando è un alias per `tlmgr platform`.

- Consulta la documentazione del comando originale:

`tldr tlmgr platform`
