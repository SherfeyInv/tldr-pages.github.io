# bundler

> Questo comando è un alias per `bundle`.
> Maggiori informazioni: <https://bundler.io/man/bundle.1.html>.

- Consulta la documentazione del comando originale:

`tldr bundle`
