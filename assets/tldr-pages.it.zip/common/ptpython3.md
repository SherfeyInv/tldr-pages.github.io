# ptpython3

> Questo comando è un alias per `ptpython`.

- Consulta la documentazione del comando originale:

`tldr ptpython`
