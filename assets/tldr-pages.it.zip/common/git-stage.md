# git stage

> Questo comando è un alias per `git add`.

- Consulta la documentazione del comando originale:

`tldr git add`
