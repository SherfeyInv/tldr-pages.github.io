# task

> Gestore della lista dei TODO.
> Maggiori informazioni: <https://taskwarrior.org/docs/>.

- Aggiungere un nuovo task:

`task add {{thing_to_do}}`

- Lista dei task:

`task list`

- Contrassegnare un task come completato:

`task {{task_id}} done`

- Modificare un task:

`task {{task_id}} modify {{new_thing_to_do}}`

- Eliminare un task:

`task {{task_id}} delete`
