# fossil ci

> Questo comando è un alias per  `fossil commit`.
> Maggiori informazioni: <https://fossil-scm.org/home/help/commit>.

- Consulta la documentazione del comando originale:

`tldr fossil commit`
