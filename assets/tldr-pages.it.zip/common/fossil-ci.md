# fossil ci

> Questo comando è un alias per  `fossil commit`.

- Consulta la documentazione del comando originale:

`tldr fossil commit`
