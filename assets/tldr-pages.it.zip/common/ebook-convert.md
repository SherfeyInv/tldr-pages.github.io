# ebook-convert

> Converti e-book in differenti formati, come PDF, EPUB, Mobi.
> Parte dello strumento Calibre per librerie e-book.
> Maggiori informazioni: <https://manual.calibre-ebook.com/generated/en/ebook-convert.html>.

- Converti un e-book in un altro formato:

`ebook-convert {{percorso/del/file_input}} {{file_output}}`
