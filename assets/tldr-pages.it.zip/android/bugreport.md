# bugreport

> Mostra un report dei bug del dispositivo Android.
> Questo comando può essere usato solamente addraverso la `adb shell`.
> Maggiori informazioni: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Mostra un report completo dei bug riscontrati nel dispositivo Android:

`bugreport`
