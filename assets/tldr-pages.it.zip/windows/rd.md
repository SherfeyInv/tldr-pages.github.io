# rd

> Questo comando è un alias per `rmdir`.

- Consulta la documentazione del comando originale:

`tldr rmdir`
