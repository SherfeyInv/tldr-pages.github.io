# rd

> Questo comando è un alias per `rmdir`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Consulta la documentazione del comando originale:

`tldr rmdir`
