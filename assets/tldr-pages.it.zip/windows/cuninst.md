# cuninst

> Questo comando è un alias per `choco uninstall`.

- Consulta la documentazione del comando originale:

`tldr choco uninstall`
