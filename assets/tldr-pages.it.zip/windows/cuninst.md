# cuninst

> Questo comando è un alias per `choco uninstall`.
> Maggiori informazioni: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Consulta la documentazione del comando originale:

`tldr choco uninstall`
