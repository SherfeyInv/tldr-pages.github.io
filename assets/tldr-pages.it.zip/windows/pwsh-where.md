# pwsh where

> Questo comando è un alias per `Where-Object`.

- Consulta la documentazione del comando originale:

`tldr Where-Object`
