# pwsh where

> Questo comando è un alias per `Where-Object`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Consulta la documentazione del comando originale:

`tldr Where-Object`
