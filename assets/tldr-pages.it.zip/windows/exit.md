# exit

> Esci dall'istanza CMD corrente o dal file batch corrente.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- Esci dall'istanza CMD corrente:

`exit`

- Esci dallo script [b]atch corrente:

`exit /b`

- Esci usando uno specifico codice d'uscita:

`exit {{2}}`
