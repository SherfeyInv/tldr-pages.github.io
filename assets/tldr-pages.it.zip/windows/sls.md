# sls

> Questo comando è un alias per `Select-String`.

- Consulta la documentazione del comando originale:

`tldr select-string`
