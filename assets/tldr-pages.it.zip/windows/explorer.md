# explorer

> Il file explorer di Windows.
> Maggiori informazioni: <https://ss64.com/nt/explorer.html>.

- Apri Windows Explorer:

`explorer`

- Apri Windows Explorer nella directory corrente:

`explorer .`

- Apri Windows Explorer in una directory specifica:

`explorer {{percorso\della\directory}}`
