# clist

> Questo comando è un alias per `choco list`.
> Maggiori informazioni: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Consulta la documentazione del comando originale:

`tldr choco list`
