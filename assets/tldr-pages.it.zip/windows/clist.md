# clist

> Questo comando è un alias per `choco list`.

- Consulta la documentazione del comando originale:

`tldr choco list`
