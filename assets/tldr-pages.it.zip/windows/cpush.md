# cpush

> Questo comando è un alias per `choco push`.

- Consulta la documentazione del comando originale:

`tldr choco push`
