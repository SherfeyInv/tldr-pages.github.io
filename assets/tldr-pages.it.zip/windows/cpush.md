# cpush

> Questo comando è un alias per `choco-push`.
> Maggiori informazioni: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Consulta la documentazione del comando originale:

`tldr choco-push`
