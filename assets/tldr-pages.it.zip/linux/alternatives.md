# alternatives

> Questo comando è un alias per `update-alternatives`.
> Maggiori informazioni: <https://manned.org/alternatives>.

- Consulta la documentazione del comando originale:

`tldr update-alternatives`
