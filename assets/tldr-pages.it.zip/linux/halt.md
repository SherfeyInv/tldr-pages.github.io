# halt

> Arresta, spegne o riavvia la macchina.
> Maggiori informazioni: <https://manned.org/halt.8>.

- Arresta la macchina:

`halt`

- Spegne la macchina:

`halt --poweroff`

- Riavvia la macchina:

`halt --reboot`
