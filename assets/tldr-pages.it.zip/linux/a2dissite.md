# a2dissite

> Disattiva un virtual host Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manned.org/a2dissite.8>.

- Disattiva un virtual host:

`sudo a2dissite {{virtual_host}}`

- Non mostrare messaggi informativi:

`sudo a2dissite --quiet {{virtual_host}}`
