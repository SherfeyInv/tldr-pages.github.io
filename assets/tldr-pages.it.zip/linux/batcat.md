# batcat

> Questo comando è un alias per `bat`.
> Maggiori informazioni: <https://github.com/sharkdp/bat>.

- Consulta la documentazione del comando originale:

`tldr bat`
