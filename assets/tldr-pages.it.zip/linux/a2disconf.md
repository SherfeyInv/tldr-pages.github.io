# a2disconf

> Disattiva un file di configurazione Apache su Sistemi Operativi basati su Debian.
> Maggiori informazioni: <https://manned.org/a2disconf.8>.

- Disattiva un file di configurazione:

`sudo a2disconf {{file_di_configurazione}}`

- Non mostrare messaggi informativi:

`sudo a2disconf --quiet {{file_di_configurazione}}`
