# a2ensite

> Attiva un virtual host Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manned.org/a2ensite.8>.

- Attiva un virtual host:

`sudo a2ensite {{virtual_host}}`

- Non mostrare messaggi informativi:

`sudo a2ensite --quiet {{virtual_host}}`
