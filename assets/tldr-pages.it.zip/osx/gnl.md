# gnl

> Questo comando è un alias per `-p linux nl`.

- Consulta la documentazione del comando originale:

`tldr -p linux nl`
