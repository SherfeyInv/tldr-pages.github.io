# gchown

> Questo comando è un alias per `-p linux chown`.

- Consulta la documentazione del comando originale:

`tldr -p linux chown`
