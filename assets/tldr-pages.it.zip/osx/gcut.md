# gcut

> Questo comando è un alias per `-p linux cut`.

- Consulta la documentazione del comando originale:

`tldr -p linux cut`
