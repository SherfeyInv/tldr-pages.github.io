# gpathchk

> Questo comando è un alias per `-p linux pathchk`.

- Consulta la documentazione del comando originale:

`tldr -p linux pathchk`
