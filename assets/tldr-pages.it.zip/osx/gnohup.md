# gnohup

> Questo comando è un alias per `-p linux nohup`.

- Consulta la documentazione del comando originale:

`tldr -p linux nohup`
