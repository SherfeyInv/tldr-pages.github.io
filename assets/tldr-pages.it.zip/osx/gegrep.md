# gegrep

> Questo comando è un alias per `-p linux egrep`.

- Consulta la documentazione del comando originale:

`tldr -p linux egrep`
