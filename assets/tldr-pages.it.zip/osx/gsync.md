# gsync

> Questo comando è un alias per `-p linux sync`.

- Consulta la documentazione del comando originale:

`tldr -p linux sync`
