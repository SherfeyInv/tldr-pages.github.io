# gsha1sum

> Questo comando è un alias per `-p linux sha1sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sha1sum`
