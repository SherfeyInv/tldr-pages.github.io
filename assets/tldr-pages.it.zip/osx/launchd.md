# launchd

> Questo comando è un alias per `launchctl`.
> Maggiori informazioni: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Consulta la documentazione del comando originale:

`tldr launchctl`
