# guname

> Questo comando è un alias per `-p linux uname`.

- Consulta la documentazione del comando originale:

`tldr -p linux uname`
