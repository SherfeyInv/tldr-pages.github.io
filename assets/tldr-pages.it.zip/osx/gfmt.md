# gfmt

> Questo comando è un alias per `-p linux fmt`.

- Consulta la documentazione del comando originale:

`tldr -p linux fmt`
