# gbase32

> Questo comando è un alias per `-p linux base32`.

- Consulta la documentazione del comando originale:

`tldr -p linux base32`
