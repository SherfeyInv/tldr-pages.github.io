# ggroups

> Questo comando è un alias per `-p linux groups`.

- Consulta la documentazione del comando originale:

`tldr -p linux groups`
