# gstty

> Questo comando è un alias per `-p linux stty`.

- Consulta la documentazione del comando originale:

`tldr -p linux stty`
