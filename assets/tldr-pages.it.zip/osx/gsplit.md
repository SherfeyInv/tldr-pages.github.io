# gsplit

> Questo comando è un alias per `-p linux split`.

- Consulta la documentazione del comando originale:

`tldr -p linux split`
