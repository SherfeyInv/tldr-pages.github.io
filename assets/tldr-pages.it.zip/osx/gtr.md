# gtr

> Questo comando è un alias per `-p linux tr`.

- Consulta la documentazione del comando originale:

`tldr -p linux tr`
