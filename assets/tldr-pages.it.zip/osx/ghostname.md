# ghostname

> Questo comando è un alias per `-p linux hostname`.

- Consulta la documentazione del comando originale:

`tldr -p linux hostname`
