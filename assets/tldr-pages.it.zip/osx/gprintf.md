# gprintf

> Questo comando è un alias per `-p linux printf`.

- Consulta la documentazione del comando originale:

`tldr -p linux printf`
