# gwc

> Questo comando è un alias per `-p linux wc`.

- Consulta la documentazione del comando originale:

`tldr -p linux wc`
