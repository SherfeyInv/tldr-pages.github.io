# gsha256sum

> Questo comando è un alias per `-p linux sha256sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sha256sum`
