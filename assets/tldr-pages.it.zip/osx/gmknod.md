# gmknod

> Questo comando è un alias per `-p linux mknod`.

- Consulta la documentazione del comando originale:

`tldr -p linux mknod`
