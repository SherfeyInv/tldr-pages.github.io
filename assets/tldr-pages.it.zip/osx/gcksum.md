# gcksum

> Questo comando è un alias per `-p linux cksum`.

- Consulta la documentazione del comando originale:

`tldr -p linux cksum`
