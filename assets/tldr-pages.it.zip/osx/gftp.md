# gftp

> Questo comando è un alias per `-p linux ftp`.

- Consulta la documentazione del comando originale:

`tldr -p linux ftp`
