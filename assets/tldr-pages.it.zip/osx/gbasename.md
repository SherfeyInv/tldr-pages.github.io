# gbasename

> Questo comando è un alias per `-p linux basename`.

- Consulta la documentazione del comando originale:

`tldr -p linux basename`
