# gvdir

> Questo comando è un alias per `-p linux vdir`.

- Consulta la documentazione del comando originale:

`tldr -p linux vdir`
