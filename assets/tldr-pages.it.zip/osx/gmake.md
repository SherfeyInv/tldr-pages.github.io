# gmake

> Questo comando è un alias per `-p linux make`.

- Consulta la documentazione del comando originale:

`tldr -p linux make`
