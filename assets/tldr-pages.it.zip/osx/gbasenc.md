# gbasenc

> Questo comando è un alias per `-p linux basenc`.

- Consulta la documentazione del comando originale:

`tldr -p linux basenc`
