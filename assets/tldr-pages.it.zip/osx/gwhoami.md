# gwhoami

> Questo comando è un alias per `-p linux whoami`.

- Consulta la documentazione del comando originale:

`tldr -p linux whoami`
