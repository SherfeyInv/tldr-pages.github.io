# gusers

> Questo comando è un alias per `-p linux users`.

- Consulta la documentazione del comando originale:

`tldr -p linux users`
