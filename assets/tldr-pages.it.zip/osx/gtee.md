# gtee

> Questo comando è un alias per `-p linux tee`.

- Consulta la documentazione del comando originale:

`tldr -p linux tee`
