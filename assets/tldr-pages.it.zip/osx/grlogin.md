# grlogin

> Questo comando è un alias per `-p linux rlogin`.

- Consulta la documentazione del comando originale:

`tldr -p linux rlogin`
