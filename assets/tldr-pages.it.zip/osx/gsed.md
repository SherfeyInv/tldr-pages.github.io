# gsed

> Questo comando è un alias per `-p linux sed`.

- Consulta la documentazione del comando originale:

`tldr -p linux sed`
