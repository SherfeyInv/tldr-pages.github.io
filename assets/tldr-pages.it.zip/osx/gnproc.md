# gnproc

> Questo comando è un alias per `-p linux nproc`.

- Consulta la documentazione del comando originale:

`tldr -p linux nproc`
