# gsha224sum

> Questo comando è un alias per `-p linux sha224sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sha224sum`
