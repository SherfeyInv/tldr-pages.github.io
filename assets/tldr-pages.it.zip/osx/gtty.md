# gtty

> Questo comando è un alias per `-p linux tty`.

- Consulta la documentazione del comando originale:

`tldr -p linux tty`
