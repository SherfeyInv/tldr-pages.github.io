# gpinky

> Questo comando è un alias per `-p linux pinky`.

- Consulta la documentazione del comando originale:

`tldr -p linux pinky`
