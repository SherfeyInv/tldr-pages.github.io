# gkill

> Questo comando è un alias per `-p linux kill`.

- Consulta la documentazione del comando originale:

`tldr -p linux kill`
