# gping6

> Questo comando è un alias per `-p linux ping6`.

- Consulta la documentazione del comando originale:

`tldr -p linux ping6`
