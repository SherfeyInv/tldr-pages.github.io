# grcp

> Questo comando è un alias per `-p linux rcp`.

- Consulta la documentazione del comando originale:

`tldr -p linux rcp`
