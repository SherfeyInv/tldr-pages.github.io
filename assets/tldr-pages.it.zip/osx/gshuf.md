# gshuf

> Questo comando è un alias per `-p linux shuf`.

- Consulta la documentazione del comando originale:

`tldr -p linux shuf`
