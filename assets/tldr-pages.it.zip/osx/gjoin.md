# gjoin

> Questo comando è un alias per `-p linux join`.

- Consulta la documentazione del comando originale:

`tldr -p linux join`
