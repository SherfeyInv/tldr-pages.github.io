# gecho

> Questo comando è un alias per `-p linux echo`.

- Consulta la documentazione del comando originale:

`tldr -p linux echo`
