# gpwd

> Questo comando è un alias per `-p linux pwd`.

- Consulta la documentazione del comando originale:

`tldr -p linux pwd`
