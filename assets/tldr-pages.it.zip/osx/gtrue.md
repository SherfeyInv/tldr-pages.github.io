# gtrue

> Questo comando è un alias per `-p linux true`.

- Consulta la documentazione del comando originale:

`tldr -p linux true`
