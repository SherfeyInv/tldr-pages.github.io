# glocate

> Questo comando è un alias per `-p linux locate`.

- Consulta la documentazione del comando originale:

`tldr -p linux locate`
