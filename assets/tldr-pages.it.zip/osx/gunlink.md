# gunlink

> Questo comando è un alias per `-p linux unlink`.

- Consulta la documentazione del comando originale:

`tldr -p linux unlink`
