# gtest

> Questo comando è un alias per `-p linux test`.

- Consulta la documentazione del comando originale:

`tldr -p linux test`
