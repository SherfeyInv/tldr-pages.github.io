# gindent

> Questo comando è un alias per `-p linux indent`.

- Consulta la documentazione del comando originale:

`tldr -p linux indent`
