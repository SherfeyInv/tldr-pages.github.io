# gshred

> Questo comando è un alias per `-p linux shred`.

- Consulta la documentazione del comando originale:

`tldr -p linux shred`
