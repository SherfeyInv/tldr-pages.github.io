# ginstall

> Questo comando è un alias per `-p linux install`.

- Consulta la documentazione del comando originale:

`tldr -p linux install`
