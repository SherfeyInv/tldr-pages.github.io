# gupdatedb

> Questo comando è un alias per `-p linux updatedb`.

- Consulta la documentazione del comando originale:

`tldr -p linux updatedb`
