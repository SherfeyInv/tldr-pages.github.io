# bugreportz

> تولید یک گزارش خطای اندروید فشرده شده.
> این دستور فقط از طریق `adb shell` قابل اجراست.
> اطلاعات بیشتر: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- تولید که گزارش خطای کامل از یک دستگاه اندرویدی :

`bugreportz`

- نمایش فرایند اجرای دستور `bugreportz` :

`bugreportz -p`

- نمایش راهنمایی :

`bugreportz -h`

- نمایش نسخه `bugreportz` :

`bugreportz -v`
