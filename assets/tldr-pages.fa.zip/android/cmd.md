# cmd

> مدیر سرویس اندروید.
> اطلاعات بیشتر: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- فهرست تمام سرویس های درحال اجرا :

`cmd -l`

- فراخوان یک سرویس :

`cmd {{service}}`

- فراخوان یک سرویس با مقادیر ورودی :

`cmd {{service}} {{argument1 argument2 ...}}`
