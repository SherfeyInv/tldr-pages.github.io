# unclutter

> مخفی کردن نشان ماوس.
> اطلاعات بیشتر: <https://manned.org/unclutter.1x>.

- مخفی کردن نشان ماوس بعد از 3 ثانیه:

`unclutter -idle {{3}}`
