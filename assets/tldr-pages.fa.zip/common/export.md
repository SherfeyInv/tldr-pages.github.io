# export

> دستور تغییر متغییرهای محلی سیستم موجود برای پروسه های جدید.
> اطلاعات بیشتر: <https://manned.org/export.1posix>.

- ایجاد و تعیین مقدار یک متغییر جدید:

`export {{VARIABLE}}={{value}}`

- افزودن یک مسیر به متغییر $PATH:

`export PATH=$PATH:{{path/to/append}}`
