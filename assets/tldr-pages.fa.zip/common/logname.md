# logname

> نمایش نام کاربر.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/logname>.

- نمایش نام کاربر لاگین شده:

`logname`
