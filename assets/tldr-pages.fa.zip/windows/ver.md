# ver

> نمایش شماره نسخه ویندوز یا داس.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- نمایش شماره نسخه:

`ver`
