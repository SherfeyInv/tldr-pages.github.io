# where

> نمایش محل فایل باینری یا اجرایی یک دستور در لینوکس.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/where>.

- نمایش محل فایل اجرایی یک دستور:

`where {{command}}`
