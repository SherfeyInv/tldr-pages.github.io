# type

> نمایش محتویات فایل.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/type>.

- نمایش محتویات فایل مشخص شده:

`type {{path/to/file}}`
